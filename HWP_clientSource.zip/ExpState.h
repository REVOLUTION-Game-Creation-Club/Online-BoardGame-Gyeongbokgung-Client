#ifndef __ExpState_h__
#define __ExpState_h__
#include "ICharacterState.h"
#include "Character.h"
#include "DrawManager.h"

class CExpState : public ICharacterState
{
private:
	CCharacter*				m_character;
	int						m_count;
	int						m_effectCount;

	void					drawExpCharacter();
	void					drawExpEffect();
public:
							CExpState(CCharacter* _character);
	virtual					~CExpState();
	void					stateStart();
	void					stateEnd();
	void					draw(DWORD _timeDelta);
};

#endif