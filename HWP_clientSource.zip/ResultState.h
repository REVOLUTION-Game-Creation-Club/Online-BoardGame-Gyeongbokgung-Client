#ifndef __ResultState_h__
#define __ResultState_h__
#include "IGameState.h"
#include "GameManager.h"

class CResultState : public IGameState
{
private:
	CGameManager*				m_gameManager;
public:
	CResultState(CGameManager* _gameManager);
	virtual						~CResultState();

	bool						initialize();
	void						release();

	void						onUpdate();
	void						onKeyboard(WPARAM _wParam);
	void						processMouseMove();
	void						onMouseLClick();
	CPrintObject*				m_userID[4];
	int							m_userNum;
	void setReturnRoomFlag( BOOL bReturnRoom );

private :
	DWORD	m_dwInitTime;
	BOOL	m_bReturnRoom;
	void processNetworkPacket();
};

#endif