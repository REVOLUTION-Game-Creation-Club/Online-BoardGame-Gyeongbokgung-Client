#ifndef _CCOUserData_H_
#define _CCOUserData_H_

#include "../RSDefine.h"
#include "../RSProtocol.h" // for DTSNAKE
#include "../RGProtocol.h" // for DTSNAKE

class CCOUserData
{
public:
/*	DTROOM			m_dtRoom;*/
	DTMAP			m_dtMap;

	DTUSER			m_dtUser[5];


	CCOUserData(void);
	~CCOUserData(void);

};

#endif