#pragma once

#include "CUIControl.h"
#include <string>
#include <vector>

using namespace std;

class CUIDialogbox : public CUIControl
{
protected:	
	vector<string>	m_stringList;
	int				m_viewRange;
	int				m_lineSpace;

	int m_temp[4];

	int m_fontPos_x;
	int m_fontPos_y;	

	float m_fontColor_r, m_fontColor_g, m_fontColor_b, m_fontColor_a;
	int m_fontSize;
	int m_maxString;
	int m_stringLength;

	CUIDialogbox(void);
public:
	int m_ListSize;

	virtual void release() {};
	virtual void insertString(string _sentence);
	virtual void insertString(char* _sentence);
	virtual string getString(int _which = 0);
	virtual void eraseString(int _which);	
	virtual void refreshString(int _where, string _sentence);
	virtual void refreshString(int _where, char* _sentence);

	void setRange(int _range);
	void setLineSpace(int _space);
	void setStringLength(int _Length);

	virtual void writeString() {}
	virtual void setFontSize(int _size) { _size = 0;}
	virtual void setFontPosition(int _x , int _y ) { _x =0 ; _y = 0;}
	virtual void setFontColor(float _r, float _g, float _b, float _a) { _r=0; _g=0; _b=0; _a=0;}

	void setMaxString(int _max);

	void setValue(int _x, int _y);
	void setValue(int _x, int _y, int _width, int _height);
	void setValue(int _x, int _y, int _width, int _height, int _texX, int _texY, char* _fileName);

	string operator [] (int _which);

	CUIDialogbox(string _name);
	CUIDialogbox(string _name, int _x, int _y, int _width, int _height);
	CUIDialogbox(string _name, int _x, int _y, int _width, int _height, int _texX, int _texY, char* _fileName);

	virtual ~CUIDialogbox(void);




	void reset();





	//{{ bakky
	// _sentence : ������ ���ڿ�
	// _nLIneCount : �� ������ �ִ� ����Ʈ��
	void insertString( char* _sentence, int _nLineCount );
	void changeString( char* _sentence, int _nLineCount );
	//}}
};
