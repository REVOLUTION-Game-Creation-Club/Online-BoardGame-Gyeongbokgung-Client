#ifndef __FightState_h__
#define __FightState_h__
#include "ICharacterState.h"
#include "item.h"

#define FIGHT_DELAY 10
#define FIGHT_SPRITE_SPEED 5

class CCharacter;

class CFightState : public ICharacterState
{
private:
	int	m_nFightCharCount;
	CCharacter*				m_character;
	CCharacter*				m_fightedCharacter0;
	CCharacter*				m_fightedCharacter1;
	CCharacter*				m_fightedCharacter;
	int						m_count;
	bool					m_fightResult;
	ITEM_KIND				m_item;

	//{{ bakky
	DWORD	m_dwStartTime;
	//}}
public:
	CFightState(CCharacter* _character);
	virtual					~CFightState();
	void					stateStart();
	void					stateEnd();
	void					draw(DWORD _timeDelta);	
	void					drawFightCharacter();
	void					setFightedCharacter(CCharacter* _fightedCharacter);
	void					setItem(ITEM_KIND _item){m_item = _item;}
};

#endif
