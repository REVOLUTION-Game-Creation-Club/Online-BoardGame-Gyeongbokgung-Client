#include "stdafx.h"
#include "TextureManager.h"

CTextureManager* CTextureManager::selfInstance = 0;

CTextureManager::CTextureManager()
{
}

CTextureManager::~CTextureManager()
{
}

CTextureManager* CTextureManager::getInstance()
{
	if( selfInstance == 0 )
		selfInstance = new CTextureManager();

	return selfInstance;
}

void CTextureManager::release()
{
	if( selfInstance != NULL )
	{
		if( !m_textureList.empty() )
		{
			map<string, CTexture*>::iterator iter;

			for( iter=m_textureList.begin() ; iter != m_textureList.end() ; iter++ )
			{
				delete iter->second;
			}

			m_textureList.clear();
		}

		delete selfInstance;
		selfInstance = NULL;
	}
}

void CTextureManager::createTexture(IDirect3DDevice9* _device, string _name)
{

	// ���ǹ� �߰�.
	//{{ bakky
	if( !m_textureList[_name] )
	{
		CTexture* texture = new CTexture(_device);
		texture->createTexture(_name);

		m_textureList[_name] = texture;
	}
	//}}
}
CTexture* CTextureManager::getTexture(string _name)
{
	return m_textureList[_name];
}

//{{ bakky
void	CTextureManager::deleteTexture( string& _name )
{
	if( m_textureList[_name] )
	{
		m_textureList[_name]->releaseTexture();
		delete m_textureList[_name];
		m_textureList.erase( _name );
	}
}
//}}