//-----------------------------------------------------------------
//	Online Snake Protocol
//				
//	Copy right all reserved by Revolution Online Team
//														2002/07/28
//-----------------------------------------------------------------


#ifndef _RSProtocol_H
#define _RSProtocol_H

#include "RSStruct.h"

typedef struct _LOGINONE {
	char	id[16];			//[16]	User Identification
	char	password[16];	//[16]	User Password
} LOGINONE;

typedef struct _LOGINTWO {
	BYTE	errcode;		//[1]	Acknowledgement Error Code
	BYTE	level;			//[1]
	USHORT	win;			//[2]
	USHORT	draw;			//[2]
	USHORT	lose;			//[2]
	USHORT	experience;		//[2]
	char	nickname[16];	//[16]
	char    ip[16];
} LOGINTWO;

//-- USERINFO -----------------------------------------------------
typedef struct _LIST_OF_USERINFO{

	BYTE	level;
	char	id[16];
	char	ipaddr[16];
    char	nickanme[20];
	USHORT	win;
	USHORT  draw;
	USHORT	lose;
	USHORT	experience;
}	LIST_OF_USERINFO;				//����� ������ �ִ� ������

//-- USERINFO_VARIABLE ------------------------------------------
typedef struct _LIST_OF_USERINFO_V{
	BYTE	user_index;			// ������ ���� ���̵�
	BYTE	user_char;
	BYTE	user_color;
	BYTE	user_state;
	BYTE	user_ready;
}	LIST_OF_USERINFO_V;

//-- ROOMINFO ----------------------------------------------------
typedef struct _LIST_OF_ROOMINFO{ 
	BYTE	room_map_no;
	char	room_name[20];
	char	room_major_id[16];
}	LIST_OF_ROOMINFO;			// ������ ������ �ִ� ������ 

typedef struct  _MYINFO {
	LOGINONE	login;
	LOGINTWO    login2;
} MYINFO;


//-- WAIT_ROOM_LIST -------------------------------------------
typedef struct _LIST_OF_WAIT_ROOM {
	BYTE	grade;				//[1]	Room Identification
	BYTE	avr_user_num;		//[1]
	BYTE	curr_user_num;		//[1]
	char	name[20];			//[20]	Room Name
}	LIST_OF_WAIT_ROOM;


//-- ROOM_LIST ------------------------------------------------
typedef struct _LIST_OF_ROOM{
	char	name[20];			//[20]	Room Name
	USHORT	no;					//[2]	Room Identification
	BYTE	state;				//[1]	Value : 0(wait) 1(playing)
	BYTE	user_num;			//[1]	User number in room
}	LIST_OF_ROOM;

//-- USER_LIST ------------------------------------------------
typedef struct _LIST_OF_USER{
	char	nickname[20];		//[20]	User Nickname
	BYTE	state;				//[1]	Value : 0(wait) 1(playing)
	BYTE	level;				//[1]	User Level
}	LIST_OF_USER;

//-- ROOM_USER_LIST -------------------------------------------
typedef struct _LIST_OF_ROOM_USER{
	char	id[16];				//[16]	User Identification
	char	ipaddr[16];				//[16]	User IP Address
}	LIST_OF_ROOM_USER;


/////////////////////////////////////////////
// SPACKET data structures and is defined
/////////////////////////////////////////////

typedef struct _SNAKE_PACKET {
	// HEADER
	union {
		char buffer[14] ;
        struct {
			char	pr_name[8];			//[8]	Project Name	
			BYTE	version;			//[1]	Version
			BYTE	type;				//[1]	Packet Type
			USHORT	key;				//[2]	Program Unique Key
			USHORT	length;				//[2]	Data Length
		} HEAD ;						//Size	[14]
	} HEADER;
	// DATA

	union {
	//-- Receive Buffer --------------------------------------------------
	
		// Use this buffer to Recv stream buffer 
		char	buff[1024];		


	//-- ID_DUP_CHK ------------------------------------------------------

		// To check user identification duplicating
		struct {
			char	id[16];			//[16]	Connected User Identification
		}	ID_DUP_CHK_REQ;

		// For ID_DUP_CHK Acknowledgement
		struct {
			BYTE	errcode;		//[1]	Acknowledgement Error Code
		}	ID_DUP_CHK_ACK;


	//-- USER_REG --------------------------------------------------------
		
		// Request User Registration
		struct {
			char	id[16];			//[16]	User Identification
			char	password[16];	//[16]	User Password
			char	name[16];		//[16]	User Name
			char	nickname[20];	//[20]	User Nick Name
			char	e_mail[31];		//[31]	User E-Mail
			char	intro[501];		//[501] User Introduction
		}	USER_REG_REQ;			//Size	[601]

		// For USER_REG_REQ Acknowledgement
		struct {
			BYTE	errcode;		//[1]	Acknowledgement Error Code
		}	USER_REG_ACK;


	//-- LOG_AUTH --------------------------------------------------
		
		// Request Login Authentication
		struct {
			char	id[16];			//[16]	User Identification
			char	password[16];	//[16]	User Password
		}	LOG_AUTH_REQ;			//Size	[32]

		// For LOG_AUTH_REQ Acknowledgement
		struct { 
			BYTE	errcode;		//[1]	Acknowledgement Error Code
			BYTE	level;			//[1]
			USHORT	win;			//[2]
			USHORT	draw;			//[2]
			USHORT	lose;			//[2]
			USHORT	experience;		//[2]
			char	nickname[16];	//[16]
			char    ip[16];
		}	LOG_AUTH_ACK;			//Size	[26]


	//-- WAIT_ROOM_LIST ----------------------------------------------

		// Request Waiting Room List Information
		struct {
			BYTE	grade_class;	//[1]	Value : 0(first) 1(middle) 2(high)
		}	WAIT_ROOM_LIST_REQ;

		// For WAIT_ROOM_LIST Acknowledgement
		struct {
			BYTE	errcode;		//[1]	Acknowledgement Error Code
			BYTE	count;			//[1]	WAIT_ROOM_LIST count
			LIST_OF_WAIT_ROOM list[336];	//	Wait room list array
		}	WAIT_ROOM_LIST_ACK;

	//-- ENTER_WAIT_ROOM ---------------------------------------------
		
		// Request Enter Wait Room
		struct {
			BYTE	grade;			//[1]	Range : 0 ~ 29
			char	id[16];			//[16]	User Identification
		}	ENTER_WAIT_ROOM_REQ;

		// For ENTER_WAIT_ROOM_REQ Acknowledgement
		struct {
			BYTE	errcode;		//[1]	Acknowledgement Error Code
		}	ENTER_WAIT_ROOM_ACK;

	//-- EXIT_WAIT_ROOM ---------------------------------------------		

		// Request Exit Wait Room 
		struct {
			char    id[16];
		}	EXIT_WAIT_ROOM_REQ;

		struct {
			BYTE	errcode;		//[1]	Acknowledgement Error Code
		}	EXIT_WAIT_ROOM_ACK;

	//-- ROOM_LIST ---------------------------------------------

		// Request Room List 
		struct {
			BYTE	grade;			//[1]	Range : 0 ~ 29
			BYTE	state;			//[1]	Value : 0(all) 1(wait) 2(playing)
		}	ROOM_LIST_REQ;

		// For ROOM_LIST_REQ Acknowledgement
		struct {
			BYTE	errcode;		//[1]	Acknowledgement Error Code
			BYTE	order;			//[1]	Packet Order
			BYTE	count;			//[1]	ROOM_LIST count
			LIST_OF_ROOM	list[41];	//		Room list array
		}	ROOM_LIST_ACK;


	//-- USER_LIST ---------------------------------------------

		// Request User List 
		struct {
			BYTE	grade;			//[1]	Range : 0 ~ 29	
		}	USER_LIST_REQ;

		// For USER_LIST_REQ Acknowledgement
		struct {
			BYTE	errcode;		//[1]	Acknowledgement Error Code
			BYTE	order;			//[1]	Packet Order
			BYTE	count;			//[1]	USER_LIST count
			LIST_OF_USER	list[41];		//		User list array
		}	USER_LIST_ACK;


	//-- ENTER_ROOM --------------------------------------------		

		// Request Enter Room
		struct {
			USHORT	no;				//[2]	Room Identification
			char	id[16];			//[16]	User Identification
		}	ENTER_ROOM_REQ;

		// For ENTER_ROOM_REQ Acknowledgement
		struct {
			BYTE	errcode;		//[1]	Acknowledgement Error Code
			char	roommajorip[16];
		}	ENTER_ROOM_ACK;


	//-- MAKE_ROOM ---------------------------------------------		

		// Request Make Room 
		struct {
			char	id[16];			//[16]	User Identification
			char	name[20];		//[20]	Room Name
		}	MAKE_ROOM_REQ;

		// For MAKE_ROOM_REQ Acknowledgement
		struct {
			BYTE	errcode;		//[1]	Acknowledgement Error Code
			char	roommajorip[16];
		}	MAKE_ROOM_ACK;

	//--BACK TO THE -------------------------------------------	
		struct {
			char	id[16];
        }	BACK_TOCHANNEL_REQ;

		struct {
			BYTE	errcode;
        }	BACK_TOCHANNEL_ACK;

		struct {
			char	id[16];
        }	BACK_TOWAITROOM_REQ;

		struct {
			BYTE	errocde;
        }	BACK_TOWAITROOM_ACK;

		struct {
			char	id[16];
			BYTE	byState;
		}	ROOM_STATE_NOFITY;
		

//-- ���� �غ�� ��Ŷ --------------------------------------
		struct {
			BYTE	byIndex;
			DTUSER	dtUser;
		}	GR_MY_NOTIFY;

		struct {
			BYTE	byMapKind;
		}	GR_MAP_REQ;	

		struct {
			BYTE	byMapKind;
			char	name[20];		//[20]	Room Name
		}	GR_MAP_ACK;	

		struct {
			DTUSER	dtUser[4];
		}	GR_USER_NOTIFY;

		struct {
			BYTE	byFlag;
		}	GR_GAME_START_NOTIFY;
	
		struct {
			char	strChat[128];
		}	GR_CHAT_REQ;

		struct {
			char	strChat[128];
		}	GR_CHAT_ACK;

		struct {
			BYTE	byKey;
		}	GR_INFO_REQ;	// by TA
		

//-- ���� �� ��Ŷ --------------------------------------

		struct {
			BYTE		nID;
			SOCKADDR_IN	addrHost;
		}	GP_CHANGE_HOST;

		struct {
			BYTE	id;
			POINT	HeadPos;
			BYTE	HeadDir;
		}	GP_MOVE_REQ;
		
		struct {
			BYTE	id;
			BYTE	byReturnCode;
		}	GP_MOVE_ACK;

		struct {
			BYTE	byMapArray[18][18];
		}	GP_MAP_NOTIFY;

		struct {
			BYTE	id;
			BYTE	byAttackKind;
		}	GP_ATTACK_REQ;

		struct {
			DTSNAKE	dtSnake[4];
		}	GP_DTSNAKE_NOTIFY;	// DTSANKE -> Data for Snake

		struct {
			BYTE	id;
		}	GP_EXIT_REQ;

		struct {
			BYTE	id;
		}	GP_EXIT_ACK;


		struct {
			BYTE	id;
		}	GP_TIMEOVER_NOTIFY;

		struct {
			BYTE	byColor;
			char	strChat[128];
		}	GP_CHAT_REQ;

		struct {
			BYTE	byColor;
			char	strChat[128];
		}	GP_CHAT_ACK;

		struct {
			BYTE grade;
			char id[16];
			char message[60];
		}	IP_CHATTING_REQ;

		struct {
			BYTE errcode;
			char id[16];
			char message[60];
		}	IP_CHATTING_ACK;

		struct {
			DTUSER dtUser[4];
		}	GP_SEND_SCORE;

	} DATA;
} SNAKE_PACKET;

typedef struct _DATAUNIT
{
	SNAKE_PACKET *pPacket;
	int packetlen;
	SOCKADDR_IN addr;
	int addrlen;

	struct _DATAUNIT *pNext;

} DATAUNIT;

#endif
