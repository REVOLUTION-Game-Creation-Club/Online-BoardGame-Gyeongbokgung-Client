#include "stdafx.h"
#include "EndState.h"
#include "DrawManager.h"
#include "ui/CUIManager.h"
#include "../RevSound/SoundManager.h"

CEndState::CEndState(CGameManager* _gameManager)
{
	this->m_gameManager = _gameManager;
}
CEndState::~CEndState()
{

}
bool CEndState::initialize()
{
	CUIManager& manager = CUIManager::getInstance();
	manager.makeContainer("endContainer", 0, 0, 1024, 768, 0, 0, "image/endscreen.bmp" );
	manager.getUIDraw(0)->setFileName("image/endscreen.bmp");
	CDrawManager::getInstance()->insertObject(DRAW_OBJECT_INTERFACE, (IDrawObject*)manager.getUIDraw(0));
	//getSoundManager()->setBgmGroup(2);
	getSoundManager()->play("����Ÿ��Ʋ");
	//getSoundManager()->nextBgmPlay();
	return true;
}
void CEndState::release()
{
	CUIManager& manager = CUIManager::getInstance();
	CDrawManager::getInstance()->eraseObject(DRAW_OBJECT_INTERFACE,manager.getUIDraw(0)->getOrder());
	CDrawManager::getInstance()->eraseList();
}
void CEndState::onUpdate()
{

}
void CEndState::onKeyboard(WPARAM _wParam)
{

}
void CEndState::processMouseMove()
{

}
