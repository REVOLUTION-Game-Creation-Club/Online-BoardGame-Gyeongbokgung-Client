#ifndef _TZQueue_H_
#define _TZQueue_H_

#include <windows.h>
#include "../RSProtocol.h"

class CTZQueue
{
private:
	DATAUNIT	*m_pHead;
	DATAUNIT	*m_pTail;
	CRITICAL_SECTION  m_Critical;

	int			m_count;

public:

	CTZQueue(void);
	~CTZQueue(void);
	
	void InitializeCS(void);
	void DeleteCS(void);

	DATAUNIT *GetDataUnit(int packetlen);			// Allocate a DATAUNIT
	void FreeDataUnit(DATAUNIT *freeDataUnit);		// Free the DATAUINT
	void DataUnitHeaderInit(DATAUNIT *initDataUint);
	void EnqueueDataUnit(DATAUNIT *addtDataUnit);	// Enqueue the DATAUINT
	DATAUNIT *DequeueDataUnit(void);				// Remove the DATAUINT
	int getQueueSize( void ) { return m_count; }
	void DequeueAll( void );
};

#endif