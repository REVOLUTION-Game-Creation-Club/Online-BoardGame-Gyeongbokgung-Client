#include "stdafx.h"
#include "Clistener.h"

#include <iostream>
using namespace std;

Clistener::Clistener(void)
{
	m_eventedControl = "";
}

Clistener::~Clistener(void)
{
}

void Clistener::setEvented(string _evented)
{	
	m_eventedControl = _evented;
}

string Clistener::getEvented()
{
	return m_eventedControl;
}

void Clistener::setChanged(string _changed)
{	
	m_changedControl = _changed;
}

string Clistener::getChanged()
{
	return m_changedControl;
}