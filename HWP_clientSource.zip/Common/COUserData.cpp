#include <windows.h>
#include "COUserData.h"


CCOUserData::CCOUserData(void)
{
	memset(this, 0, sizeof(*this));
}

CCOUserData::~CCOUserData(void)
{

}

/************************************************************************/
/* 050522(��) ��ŷ ���� A - ���
/************************************************************************/
/*int CCOUserData::GetGameScore(int index)
{
	int totalScore = 0;

	//Win or Defeat or Draw Score
	if (m_dtSnake[index].byUserState == GUS_WIN)
	{
		totalScore += 100;
		m_dtUser[index].uScore += 100;
	}
	else if (m_dtSnake[index].byUserState == GUS_DRAW)
	{
		totalScore += 50;
		m_dtUser[index].uScore += 50;
	}
	else if (m_dtSnake[index].byUserState == GUS_LOSE)
	{
		totalScore += 30;
		m_dtUser[index].uScore += 30;
	}

	return totalScore;
}*/

void CCOUserData::WaitRoomInit(void)
{


}

void CCOUserData::GameRoomInit(HINSTANCE hInstance)
{
	
/*
	// by TA
	// teleadam ���¿� 1 155.230.17.1
	char chTemp[255];
	ZeroMemory(chTemp, 255);
	int nMajor;

	fstream fin;
	fin.open( "config.txt", ios::in );
	fin >> m_dtMyUser.strID >> m_dtMyUser.strName >> nMajor >> chTemp;
	if(nMajor)
		m_dtMyUser.byMajor = 1;
	m_dtRoom.ipaddrMajor.sin_addr.s_addr	= inet_addr(chTemp);
	
	// ���� ���� �ʱ�ȭ
	m_dtRoom.ipaddrMajor.sin_family			= AF_INET;
	m_dtRoom.ipaddrMajor.sin_port			= htons(VMPORT);
	
	strcpy(m_dtRoom.byRoomName, "��ϴ��б� �������");

	m_dtMyUser.byUserState = GRS_NOTREADY;
	memset(m_dtUser,	0, sizeof(DTUSER)*4);*/

}

void CCOUserData::PlayGameInit(void)
{
	for(int i=0; i<4; i++)
	{
		m_dtSnake[i].byInputInverse = 0;		// Ű�ݴ� 
		m_dtSnake[i].byHidden = 0;			// ��������
		m_dtSnake[i].byShield = 0;			// ĳ���͹��� 
		m_dtSnake[i].byMoveSpeed = 2;		// �̵� �ӵ�
		m_dtSnake[i].byAttackSpeed = 2;		// ���� �ӵ�
		m_dtSnake[i].byPower = 0;			// �Ŀ���
		ZeroMemory(m_dtSnake[i].bySungu, sizeof(BYTE)*7);
		m_dtSnake[i].bySnakeState = 0;		// ���� ������ũ ����
		m_dtSnake[i].byUserState = 1;		// ���� ���̸� ����
	}
}


