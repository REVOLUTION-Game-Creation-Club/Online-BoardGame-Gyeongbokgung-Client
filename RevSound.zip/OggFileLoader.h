#ifndef __OGG_FILE_LOADER_H__
#define __OGG_FILE_LOADER_H__

#include "SoundFileLoader.h"

#include "vorbis/codec.h"
#include "vorbis/vorbisfile.h"

namespace rev
{

class COggFileLoader : public CSoundFileLoader
{
public:
	COggFileLoader(void);
	virtual ~COggFileLoader(void);

public :
	void	initialize();
	bool	close();

	bool	open( TCHAR* szFileName );
	bool	read( BYTE*	pDestBuffer, DWORD dwSizeToRead, DWORD* pdwSizeRead );
	DWORD	getSize();
	bool	reset();
	WAVEFORMATEX* getFormat();
	bool	isEof();
	void	destroy();

private :
	bool GetStreamInfo();

private:
	FILE*			m_file;
	WAVEFORMATEX	m_WaveFormatEx;

	bool			m_bOpen;

	BYTE*			m_pBufferPtr;
	BYTE*			m_pBuffer;
	DWORD			m_nBufferSize;
	DWORD			m_nNumSamples;

	bool			m_bEOF;

	OggVorbis_File	m_VorbisFile;
	vorbis_info*	m_pVorbisInfo;
};

}

#endif	//__OGG_FILE_LOADER_H__