#include "StdAfx.h"
#include "WaveFileLoader.h"

namespace rev
{

CWaveFileLoader::CWaveFileLoader(void)
{
	initialize();
}

CWaveFileLoader::CWaveFileLoader( TCHAR* szFileName )
{
	initialize();

	m_strName	= tstring( szFileName );
}

CWaveFileLoader::~CWaveFileLoader(void)
{
	close();
}



void	
CWaveFileLoader::initialize()
{
	ZeroMemory( &m_destFormat, sizeof( WAVEFORMATEX ) );
	ZeroMemory( &m_ck, sizeof( MMCKINFO ) );
	ZeroMemory( &m_ckRiff, sizeof( MMCKINFO ) );
	m_hmmio		= NULL;
	m_dwSize	= 0;
	m_bEof		= false;	

	m_pwfx		= NULL;
}

bool	
CWaveFileLoader::close()
{
	mmioClose( m_hmmio, 0 );
	m_hmmio		= NULL;
	m_dwSize	= 0;
	m_bEof		= false;

	return true;
}


bool	
CWaveFileLoader::open( TCHAR* szFileName )
{
	m_strName	= tstring( szFileName );

	m_hmmio	= mmioOpen( szFileName, NULL, MMIO_ALLOCBUF | MMIO_READ );

	if( !m_hmmio )
	{
		debug( "mmioOpen failed\n" );
		return false;
	}

	return openMMIO();
}

bool	
CWaveFileLoader::open( BYTE* pData, DWORD dwDataSize )
{
	MMIOINFO	mmioInfo;
	ZeroMemory( &mmioInfo, sizeof( MMIOINFO ) );
	mmioInfo.fccIOProc	= FOURCC_MEM;
	mmioInfo.cchBuffer	= dwDataSize;
	mmioInfo.pchBuffer	= (HPSTR)pData;

	m_hmmio	= mmioOpen( NULL, &mmioInfo, MMIO_READ );

	//m_nWaveCount++;

	return openMMIO();
}
bool	
CWaveFileLoader::reset()
{
	m_bEof = false;

	if( m_hmmio == NULL )
		return false;

	if( -1 == mmioSeek( m_hmmio, m_ckRiff.dwDataOffset + sizeof( FOURCC ), SEEK_SET ) )
	{
		debug( "mmioSeek failed\n" );
		return false;
	}

	m_ck.ckid = mmioFOURCC( 'd', 'a', 't', 'a' );
	if( 0 != mmioDescend( m_hmmio, &m_ck, &m_ckRiff, MMIO_FINDCHUNK ) )
	{
		debug( "mmioDescend failed\n" );
		return false;
	}

	return true;
}

void	
CWaveFileLoader::destroy()
{

}

bool	
CWaveFileLoader::openMMIO()
{
	if( !readMMIO() )
	{
		mmioClose( m_hmmio, 0 );
		debug( "readmmio fail\n" );
		return false;
	}

	if( !reset() )
	{
		mmioClose( m_hmmio, 0 );
		debug( "reset fail\n" );
		return false;
	}

	m_dwSize	= m_ck.cksize;

	return true;
}

bool	
CWaveFileLoader::readMMIO()
{
	MMCKINFO		ckIn;
	PCMWAVEFORMAT	pcmWaveFormat;

	if( m_pwfx )
	{
		delete [] m_pwfx;
		m_pwfx = NULL;
	}

	if( mmioSeek( m_hmmio, 0, SEEK_SET ) == -1 )
		return false;

	if( ( 0 != mmioDescend( m_hmmio, &m_ckRiff, NULL, 0 ) ) )
	{
		debug( "mmioDescend failed\n" );
		return false;
	}

	if( ( m_ckRiff.ckid != FOURCC_RIFF) || ( m_ckRiff.fccType != mmioFOURCC( 'W', 'A', 'V', 'E' ) ) )
	{
		debug( "mmioFOURCC failed\n" );
		return false;
	}

	ckIn.ckid	= mmioFOURCC( 'f', 'm', 't', ' ' );
	if( 0 != mmioDescend( m_hmmio, &ckIn, &m_ckRiff, MMIO_FINDCHUNK ) )
	{
		debug( "mmioDescend failed\n" );
		return false;
	}

	if( ckIn.cksize < sizeof( PCMWAVEFORMAT ) )
	{
		debug( "sizeof( PCMWAVEFORMAT ) failed\n" );
		return false;
	}

	if( mmioRead( m_hmmio, (HPSTR)&pcmWaveFormat, sizeof( PCMWAVEFORMAT ) ) != sizeof( PCMWAVEFORMAT ) )
	{
		debug( "mmioRead failed\n" );
		return false;
	}

	if( pcmWaveFormat.wf.wFormatTag == WAVE_FORMAT_PCM )
	{
		memcpy( &m_destFormat, &pcmWaveFormat, sizeof( PCMWAVEFORMAT ) );

		m_destFormat.cbSize = 0;
	}
	else
	{
		// PCM �̿��� �ٸ� ����
		debug( "PCM �̿��� �ٸ� ����\n" ); 
		return false;
	}

	if( 0 != mmioAscend( m_hmmio, &ckIn, 0 ) )
	{
		if( m_pwfx )
		{
			delete [] m_pwfx;
			m_pwfx = NULL;
		}

		debug( "mmioAscend failed\n" );
		return false;
	}

	return true;
}

bool	
CWaveFileLoader::read( BYTE*	pDestBuffer, DWORD dwSizeToRead, DWORD* pdwSizeRead )
{
	MMIOINFO	mmioinfoIn;

	if( m_hmmio == NULL )
		return false;

	if( pDestBuffer == NULL || pdwSizeRead == NULL )
		return false;

	if( pdwSizeRead != NULL )
		*pdwSizeRead = 0;

	if( 0 != mmioGetInfo( m_hmmio, &mmioinfoIn, 0 ) )
	{
		debug( "mmioGetInfo failed\n" );
		return false;
	}

	DWORD	dwDataIn	= 0;
	BYTE*	pWaveBuffer = NULL;
	DWORD	dwStreamRead= 0;

	pWaveBuffer = pDestBuffer;
	dwDataIn = dwSizeToRead;

	if( dwDataIn > m_ck.cksize )
		dwDataIn = m_ck.cksize;
	m_ck.cksize	-= dwDataIn;

	DWORD dwRead = 0;
	DWORD dwCopySize;

	while( dwRead < dwDataIn )
	{
		if( 0 != mmioAdvance( m_hmmio, &mmioinfoIn, MMIO_READ ) )
		{
			debug( "mmioAdvance failed\n" );
			return false;
		}

		if( mmioinfoIn.pchNext == mmioinfoIn.pchEndRead )
		{
			debug( "mmioinfoIn.pchNext failed\n" );
			return false;
		}

		dwCopySize = DWORD( mmioinfoIn.pchEndRead - mmioinfoIn.pchNext );
		dwCopySize = ( dwCopySize > dwDataIn - dwRead ) ? dwDataIn - dwRead : dwCopySize;

		memcpy( pWaveBuffer + dwRead, mmioinfoIn.pchNext, dwCopySize );

		dwRead += dwCopySize;
		mmioinfoIn.pchNext += dwCopySize;
	}

	if( 0 != mmioSetInfo( m_hmmio, &mmioinfoIn, 0 ) )
	{
		debug( "mmioSetInfo failed\n" );
		return false;
	}

	if( pdwSizeRead != NULL )
		*pdwSizeRead = dwDataIn;

	if( m_ck.cksize == 0 )
		m_bEof = true;

	return true;
}

}