#include "stdafx.h"
#include "SufferState.h"
#include "Map.h"
#include "GameManager.h"
#include "PlayState.h"
#include "MessageManager.h"
#include "UserManager.h"
#include "DrawManager.h"

CSufferState::CSufferState(CCharacter* _character)
{
	this->m_character	= _character;
	m_count				= 0;
	m_effectCount		= 0;
}

CSufferState::~CSufferState()
{

}

void CSufferState::stateStart()
{
}

void CSufferState::stateEnd()
{
}

void CSufferState::draw(DWORD _timeDelta)
{
	UNREFERENCED_PARAMETER(_timeDelta);
	if(m_character->isTurnOutFlag() == true)
		drawSufferEffect();

	else if( m_count < SPRITE_NUM_DELAY*SPRITE_NUM_SUFFER )
		m_count++;
	else
	{
		// ����ź ���� �ִϸ��̼� �Ŀ� TURN_OUT �޼����� ������.
		if(m_character->isTurnOutFlag() == true)
		{
			//if(CUserManager::getInstance()->getMyUser()->isMajor())
			{
				Packet packet(REQ_TURN_OUT);
				packet << CUserManager::getInstance()->getMyUserId();
				CMessageManager::getInstance()->sendMessageToClientServer(packet);
			}
			m_character->setTurnOutFlag(false);
		}
		m_count = 0;
		m_effectCount= 0;
	}

	drawSufferCharacter();
	m_character->drawOption();
}

void CSufferState::drawSufferCharacter()
{
	CPlayState* playState = (CPlayState*)CGameManager::getInstance()->getState(GAME_STATE_PLAY);

	m_character->setSpriteType(SPRITE_TYPE_WAIT);
	m_character->setScrollAvailable(true);

	int num = m_count/SPRITE_NUM_DELAY%SPRITE_NUM_WAIT;
	m_character->setSpriteNo(num);

	POINT position;
	position.x = m_character->getCenterPoint().x - 75 - playState->getMap()->getScreenPoint().x;
	position.y = m_character->getCenterPoint().y - 125 - playState->getMap()->getScreenPoint().y;
	m_character->setPosition(position);

	m_character->BitBlt();
}

void CSufferState::drawSufferEffect()
{
	CPlayState* playState = (CPlayState*)CGameManager::getInstance()->getState(GAME_STATE_PLAY);

	if(m_count == 0)
	{
		playState->getEffect()->setVisible(true);
		CDrawManager::getInstance()->makeCharacterTopLayer(playState->getEffect()->getOrder());

		m_count++;
	}
	else if(m_count < SPRITE_NUM_DELAY*5)
	{
		POINT position;
		position.x = m_character->getCenterPoint().x - 120 - playState->getMap()->getScreenPoint().x;
		position.y = m_character->getCenterPoint().y - 150 - playState->getMap()->getScreenPoint().y;

		playState->getEffect()->setPosition(position);
		playState->getEffect()->setSpriteType(0); // ������
		playState->getEffect()->setSpriteNo(m_count/SPRITE_NUM_DELAY%5);

		m_count++;
	}
	else
	{
		playState->getEffect()->setVisible(false);
		m_count++;
	}
}