#ifndef __MainFrame_h__
#define __MainFrame_h__

namespace MainFrame
{
	LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
	int MessageLoop();
}

#endif