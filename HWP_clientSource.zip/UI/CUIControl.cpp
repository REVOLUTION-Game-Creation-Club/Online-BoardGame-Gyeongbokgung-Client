#include "stdafx.h"
#include "CUIControl.h"

#include <iostream>

CUIControl::CUIControl(void)
{
	m_listener = NULL;
	m_state = 0;
	m_imageFlag = REV_NORMAL;

	height = 0;
	width = 0;
	x = 0;
	y = 0;
	tex_x = 0;
	tex_y = 0;

	focus = false;
	visible = true;

	mouseClicked_x = 0;
	mouseClicked_y = 0;

	tex_x_normal = 0;
	tex_x_rollover = 0;
	tex_x_pressed = 0;
	tex_x_inactive = 0;

	m_bEnable = TRUE;
}

CUIControl::~CUIControl(void)
{
}

void CUIControl::addListener(Clistener* _listener)
{
	m_listener = _listener;
}

void CUIControl::activeControl(int _state)
{
	if( m_listener != NULL )
	{
		m_listener->setEvented(name);
	}
	else
	{
		//�����Ͱ� ���� ���
	}
}

void  CUIControl::deactivate()
{
	if( m_imageFlag & REV_NORMAL )
	{
		//tex_x = width * 0;
		tex_x = tex_x_normal;
	}
}

string CUIControl::getFileNavi()
{
	return m_fileName;
}

void CUIControl::setFileNavi(string _file)
{
	m_fileName = _file;
}

void CUIControl::deleteListener()
{
	m_listener = NULL;
}

void CUIControl::setValue(int _x, int _y)
{
	x = _x;
	y = _y;
}

void CUIControl::setValue(int _x, int _y, int _width, int _height)
{
	x = _x;
	y = _y;
	width = _width;
	height = _height;

}

void CUIControl::setValue(int _x, int _y, int _width, int _height, int _texX, int _texY, string _fileName)
{
 	x = _x;
	y = _y;
	width = _width;
	height = _height;
	tex_x = _texX;
	tex_y = _texY;
	m_fileName = _fileName;

	tex_x_normal = _texX;
	tex_x_rollover = tex_x + width * 1;
	tex_x_pressed = tex_x + width * 2;
	tex_x_inactive = tex_x + width * 3;
}

void CUIControl::setValue(int _texX, int _texY, string _fileName)
{
	tex_x = _texX;
	tex_y = _texY;
	m_fileName = _fileName;

	tex_x_normal = _texX;
	tex_x_rollover = tex_x + width * 1;
	tex_x_pressed = tex_x + width * 2;
	tex_x_inactive = tex_x + width * 3;
}

void CUIControl::moveControl(int _xterm, int _yterm )
{
	x += _xterm;
	y += _yterm;
}

void CUIControl::setImageFlag(int _flag )
{
	m_imageFlag = _flag;
}

void CUIControl::setImageState(int _flag)
{
	if( m_imageFlag & _flag)
	{
		if( _flag & REV_NORMAL )
		{
			tex_x = tex_x_normal;
		}
		else if( _flag & REV_ROLLOVER )
		{
			tex_x = tex_x_rollover;
		}
		else if( _flag & REV_PRESSED )
		{
			tex_x = tex_x_pressed;
		}
		else if( _flag & REV_INACTIVE )
		{
			tex_x = tex_x_inactive;
		}
	}	
}