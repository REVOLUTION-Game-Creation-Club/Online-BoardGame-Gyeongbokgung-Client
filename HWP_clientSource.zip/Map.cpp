#include "stdafx.h"
#include "Map.h"
#include "UserManager.h"
#include "GameManager.h"
#include "DrawObject.h"
#include "Item.h"
#include <stdio.h>

CMap::CMap() :CDrawObject(0,0, 2048, 2048,"image/worldmap.bmp")
{
	m_screenPoint.x = 0;
	m_screenPoint.y = 0;
	m_scrollPoint.x = 0;
	m_scrollPoint.y = 0;
	loadTile();
}

CMap::~CMap()
{
	m_listTile.clear();
}

bool CMap::initialize(IDirect3DDevice9* const _device)
{
	CDrawObject::initialize(_device);
	return true;
}

void CMap::draw(DWORD _timeDelta)
{
	UNREFERENCED_PARAMETER(_timeDelta);
	drawBackGround();
	drawTile();
}
bool CMap::loadTile()
{
	FILE *file;
	TileInfo	tile;
	int index, subIndex, id, point, type, x, y, item, prevTile, nextTile, gotoTile;

	if((file = fopen("Map/tilelist00.txt","r")) == NULL)
		return false;

	while(true)
	{
		fscanf_s(file,"%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\n",&index, &subIndex, &id, &point, &type, &x, &y, &item, &prevTile, &nextTile, &gotoTile);
		tile.m_index = index;
		tile.m_subIndex = subIndex;
		tile.m_id = id;
		tile.m_point = point;
		tile.m_type = type;
		tile.m_x = x*50;
		tile.m_y = y*50;
		tile.m_item = (ITEM_KIND)item;
		tile.m_prevTile = prevTile;
		tile.m_nextTile = nextTile;
		tile.m_gotoTile = gotoTile;
		m_listTile.push_back(tile);

		if(feof(file))
			break;
	}

	fclose(file);

	return true;
}

void CMap::setScreenPointAtCharacter(CCharacter* _character)
{
	POINT pos = _character->getCenterPoint();

	if(pos.x <= (BGVIEW_WIDTH/2))
	{
		m_screenPoint.x = 0;
	}
	else if(pos.x <= (BG_WIDTH - (BGVIEW_WIDTH/2)))
	{
		m_screenPoint.x = pos.x - BGVIEW_WIDTH/2;
	}
	else
	{
		m_screenPoint.x = BG_WIDTH - BGVIEW_WIDTH;
	}

	if(pos.y <= (BGVIEW_HEIGHT/2))
	{
		m_screenPoint.y = 0;
	}
	else if(pos.y <= (BG_HEIGHT - (BGVIEW_HEIGHT/2)))
	{
		m_screenPoint.y = pos.y - BGVIEW_HEIGHT/2;
	}

	else
	{
		m_screenPoint.y = BG_HEIGHT - BGVIEW_HEIGHT;
	}
}

void CMap::drawBackGround()
{
	setPosition(0,0);

	RECT textureRect;

	textureRect.left = m_screenPoint.x;
	textureRect.right = textureRect.left + BGVIEW_WIDTH;
	textureRect.top	= m_screenPoint.y;
	textureRect.bottom	= textureRect.top + BGVIEW_HEIGHT;

	setTextureRect(textureRect);

	BitBlt();
}

void CMap::drawTile()
{
	RECT textureRect;
	POINT pos;

	for(int i = 0; i < (int)m_listTile.size(); i++)
	{
		pos.x = m_listTile[i].m_x - 25 - m_screenPoint.x;
		pos.y = m_listTile[i].m_y - 25 - m_screenPoint.y;
		setPosition(pos);

		if(m_listTile[i].m_point == 0)
		{
			textureRect.left = 0;
			textureRect.right = textureRect.left+ 50;
			textureRect.top = 1550;
			textureRect.bottom = textureRect.top + 50;
			setTextureRect(textureRect);
			BitBlt();
		}
		else
		{
			textureRect.left = 50*(m_listTile[i].m_type+1);
			textureRect.right = textureRect.left+ 50;
			textureRect.top = 1550;
			textureRect.bottom = textureRect.top + 50;
			setTextureRect(textureRect);
			BitBlt();
		}


		for(int j = 1; j < 8; j++)
		{
			if(m_listTile[i].m_item == j)
			{
				textureRect.left = 50*(j-1);
				textureRect.right = textureRect.left+ 50;
				textureRect.top = 1500;
				textureRect.bottom = textureRect.top + 50;
				setTextureRect(textureRect);
				BitBlt();
			}
		}

		if(m_listTile[i].m_select == 1)
		{
			textureRect.left = 0;
			textureRect.right = textureRect.left+ 50;
			textureRect.top = 1600;
			textureRect.bottom = textureRect.top + 50;
			setTextureRect(textureRect);
			BitBlt();
		}

		if(m_listTile[i].m_waterball == 1)
		{
			textureRect.left = 50;
			textureRect.right = textureRect.left+ 50;
			textureRect.top = 1600;
			textureRect.bottom = textureRect.top + 50;
			setTextureRect(textureRect);
			BitBlt();
		}

		// ����, �� Ÿ�� �̹��� ����
		if(m_listTile[i].m_point == 1)
		{
			BitBlt(pos.x,pos.y,50,50,300,1550);
		}
	}
}


// ĳ������ Ÿ�� �ε����� �Ѱ��ָ� ����ź ��ġ ���� Ÿ���ε����� �迭�� �Ѱ��ش�.
// ��ġ������ Ÿ���� ����
void	CMap::getCanWaterBallTiles( int nCharTileIndex, vector<int>& vecWaterBallTile )
{
	struct  SHORTPATH
	{
		int tile;
		int count;
		BOOL bEnter;
		int leaveTile;

		SHORTPATH():leaveTile(-1){}
	};

	vector<SHORTPATH>	stackTile;

	int nTileIndex = nCharTileIndex;

	// next
	for( int i=0 ; i<WATER_BALL_RANGE ; )
	{
		int nNextTile = m_listTile[ nTileIndex ].m_nextTile;

		// �����̳� ���̸� ����
		if( nNextTile == START_POINT || nNextTile == END_POINT )
			break;

		// ���� ���� Ÿ���̸�
		if( m_listTile[ nNextTile ].m_point == 0 )
		{
			nTileIndex = nNextTile;
			continue;
		}

		// �������̸� stack�� ����
		if( m_listTile[ nNextTile ].m_type != 0 )
		{
			SHORTPATH sp;
			
			sp.bEnter = TRUE;
			sp.tile = nNextTile;
			sp.count= WATER_BALL_RANGE - i - 1;

			stackTile.push_back( sp );
		}

		if( -1 != isLeaveShortPath( nNextTile ) )
		{
			SHORTPATH sp;

			sp.bEnter = FALSE;
			sp.tile = nNextTile;
			sp.count= WATER_BALL_RANGE - i - 1;
			sp.leaveTile = isLeaveShortPath( nNextTile );

			stackTile.push_back( sp );
		}

		vecWaterBallTile.push_back( nNextTile );

		//nTileIndex = m_listTile[ nNextTile ].m_nextTile;
		nTileIndex = nNextTile;
		i++;
	}//for

	nTileIndex = nCharTileIndex;
	// prev
	for( int i=0 ; i<WATER_BALL_RANGE ; )
	{
		int nPrevTile = m_listTile[ nTileIndex ].m_prevTile;

		// �����̳� ���̸� ����
		if( nPrevTile == START_POINT || nPrevTile == END_POINT )
			break;

		// ���� ���� Ÿ���̸�
		if( m_listTile[ nPrevTile ].m_point == 0 )
		{
			nTileIndex = nPrevTile;
			continue;
		}

		// �������̸� stack�� ����
		if( m_listTile[ nPrevTile ].m_type != 0 )
		{
			SHORTPATH sp;

			sp.bEnter = TRUE;
			sp.tile = nPrevTile;
			sp.count= WATER_BALL_RANGE - i - 1;

			stackTile.push_back( sp );
		}

		if( -1 != isLeaveShortPath( nPrevTile ) )
		{
			SHORTPATH sp;

			sp.bEnter = FALSE;
			sp.tile = nPrevTile;
			sp.count= WATER_BALL_RANGE - i - 1;
			sp.leaveTile = isLeaveShortPath( nPrevTile );

			stackTile.push_back( sp );
		}

		vecWaterBallTile.push_back( nPrevTile );

		//nTileIndex = m_listTile[ nPrevTile ].m_prevTile;
		nTileIndex = nPrevTile;
		i++;
	}//for

	// ������...
	for( int i=0 ; i<(int)stackTile.size() ; i++ )
	{
		nTileIndex = stackTile[i].tile;
		BOOL bEnter = stackTile[i].bEnter;

		// ������ �Ա�
		if( bEnter )
		{
			// next
			for( int k=0 ; k<stackTile[i].count ; )
			{
				int nNextTile;
				if( k == 0 )
					nNextTile = m_listTile[ nTileIndex ].m_gotoTile;
				else
					nNextTile = m_listTile[ nTileIndex ].m_nextTile;

				// �����̳� ���̸� ����
				if( nNextTile == START_POINT || nNextTile == END_POINT )
					break;

				// ���� ���� Ÿ���̸�
				if( m_listTile[ nNextTile ].m_point == 0 )
				{
					nTileIndex = nNextTile;
					continue;
				}

				// �������̸� stack�� ����
				if( m_listTile[ nNextTile ].m_type != 0 )
				{
					SHORTPATH sp;

					sp.tile = nNextTile;
					sp.count= WATER_BALL_RANGE - k - 1;

					stackTile.push_back( sp );
				}

				vecWaterBallTile.push_back( nNextTile );

				//nTileIndex = m_listTile[ nNextTile ].m_nextTile;
				nTileIndex = nNextTile;
				k++;

			}//for
		}//if
		// ������ �ⱸ
		else
		{
			// prev
			for( int i=0 ; i<stackTile[i].count ; )
			{
				int nPrevTile ;
				if( i == 0 )
					nPrevTile = stackTile[i].leaveTile;
				else
					nPrevTile = m_listTile[ nTileIndex ].m_prevTile;

				// �����̳� ���̸� ����
				if( nPrevTile == START_POINT || nPrevTile == END_POINT )
					break;

				// ���� ���� Ÿ���̸�
				if( m_listTile[ nPrevTile ].m_point == 0 )
				{
					nTileIndex = nPrevTile;
					continue;
				}

				// �������̸� stack�� ����
				if( m_listTile[ nPrevTile ].m_type != 0 )
				{
					SHORTPATH sp;

					sp.tile = nPrevTile;
					sp.count= WATER_BALL_RANGE - i - 1;

					stackTile.push_back( sp );
				}

				vecWaterBallTile.push_back( nPrevTile );

				//nTileIndex = m_listTile[ nPrevTile ].m_prevTile;
				nTileIndex = nPrevTile;
				i++;
			}//for
		}// else
	}//for
}

int CMap::isLeaveShortPath( int nTileIndex )
{
	// ���� ������ Ÿ�� �ε������� ������ �ִ´�.
	//	30
	//	55
	//	91
	//	98
	const static int LEAVE_SHORT_PATH_TILE_INDEX[] = { 30, 55, 91, 98 };
	const static int LEAVE_SHORT_PATH_TILE_PREV_INDEX[] = { 99, 100, 101, 97 };

	for( int i=0 ; i<4 ; i++ )
	{
		if( LEAVE_SHORT_PATH_TILE_INDEX[i] == nTileIndex )
			return LEAVE_SHORT_PATH_TILE_PREV_INDEX[i];
	}

	return -1;
}

void	CMap::setTileFromId( int _tileId, TileInfo& tileInfo )
{
	// �˻��� �ؼ� tile id�� ���� ���� copy
	for( int i=0 ; i<this->m_listTile.size(); i++ )
	{
		if( m_listTile[i].m_id == _tileId )
		{
			memcpy( &m_listTile, &tileInfo, sizeof( TileInfo ) );
		}
	}
}