#ifndef __SOUND_FILE_MANAGER_H__
#define __SOUND_FILE_MANAGER_H__

#ifdef _UNICODE
typedef std::wstring	tstring;
#else
typedef std::string		tstring;
#endif


using namespace std;

namespace rev
{

typedef struct _BgmNode
{
	tstring			strFilePath;
	unsigned int	group;
} BGMNODE;



// ���� ��� ����
// ������� ȿ�������� �����
class CSoundFileManager
{

protected :
	vector<BGMNODE>*		m_pBgmList;
	int						m_nGroupCount;
	vector<tstring>			m_vecEffect;

	unsigned int	m_nBgmCurrentGroup;
	int				m_nBgmCurrentPos;
	int				m_nEffectCurrentPos;

	int	getIntFromBuffer( TCHAR* buf );

public:
	CSoundFileManager(void);
	~CSoundFileManager(void);

	bool	initialize();
	bool	destroy();

	bool	loadSoundList( TCHAR* _szFileName );

	void	setBgmGroup( unsigned int _group );
	tstring*	currentBgm();
	tstring*	nextBgm();

	bool	isEmpty();
	tstring*	nextEffect();
	tstring*	findBgm( tstring& strName );

};

}

#endif	//__SOUND_FILE_MANAGER_H__