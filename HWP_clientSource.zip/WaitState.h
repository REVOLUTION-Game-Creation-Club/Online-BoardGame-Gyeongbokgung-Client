#ifndef __WaitState_h__
#define __WaitState_h__
#include "ICharacterState.h"
#include "Character.h"

class CWaitState : public ICharacterState
{
private:
	CCharacter*				m_character;
	int						m_count;
public:
							CWaitState(CCharacter* _character);
	virtual					~CWaitState();
	void					stateStart();
	void					stateEnd();
	void					draw(DWORD _timeDelta);
	void					drawWaitCharacter();
};

#endif