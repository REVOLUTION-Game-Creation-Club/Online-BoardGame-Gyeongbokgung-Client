#ifndef __SufferState_h__
#define __SufferState_h__
#include "ICharacterState.h"
#include "Character.h"

class CSufferState : public ICharacterState
{
private:
	CCharacter*				m_character;
	int						m_count;
	int						m_effectCount;
public:
	CSufferState(CCharacter* _character);
	virtual					~CSufferState();
	void					stateStart();
	void					stateEnd();
	void					draw(DWORD _timeDelta);
	void					drawSufferCharacter();
	void					drawSufferEffect();
};

#endif