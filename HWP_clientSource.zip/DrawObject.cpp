#include "stdafx.h"
#include "DrawObject.h"
#include "MainFrame.h"
#include "DrawManager.h"
// SpriteObject�� �ʱ�ȭ�Ѵ�.
// device, �׸� ���ϸ�, ȭ�鿡 ��µ� �»���ǥ, Ÿ���� ����, ����, Ÿ��(row), �ѹ�

CDrawObject::CDrawObject()
{
	m_position.x			= 0;
	m_position.y			= 0;
	m_position.z			= 0;
	m_width					= 0;
	m_height				= 0;

	m_textureRect.top		= 0.0l;
	m_textureRect.bottom	= (LONG)0;
	m_textureRect.left		= 0.0l;
	m_textureRect.right		= (LONG)0;

	m_visible				= true;

	m_sprite = NULL;
}
CDrawObject::CDrawObject(int _x, int _y, int _w, int _h, string _fileName)
{
	m_position.x			= _x;
	m_position.y			= _y;
	m_position.z			= 0;
	m_width					= _w;
	m_height				= _h;

	m_textureRect.top		= (LONG)0;
	m_textureRect.bottom	= (LONG)m_height;
	m_textureRect.left		= (LONG)0;
	m_textureRect.right		= (LONG)m_width;

	m_fileName				= _fileName;

	m_visible				= true;

	m_sprite				= NULL;
}

CDrawObject::~CDrawObject()
{
}

bool CDrawObject::initialize(IDirect3DDevice9* const _device)
{
	m_device = _device;

	D3DXCreateSprite(m_device, &m_sprite);
	CTextureManager::getInstance()->createTexture(m_device,m_fileName);
	return true;
}

void CDrawObject::release()
{
	if(m_fileName == "")
		return;

	//{{ bakky : texture�� release�� ���༭ delete ������.
	//CTextureManager::getInstance()->getTexture(m_fileName)->releaseTexture();
	CTextureManager::getInstance()->deleteTexture(m_fileName);
	//}}

	if(m_sprite != NULL)
	{
		m_sprite->Release();
		m_sprite = NULL;
	}
}

void CDrawObject::setPosition(int _x, int _y)
{ 
	m_position.x = _x; 
	m_position.y = _y; 
	m_position.z = 0;
}

void CDrawObject::setPosition(POINT _point)
{ 
	m_position.x = _point.x; 
	m_position.y = _point.y; 
	m_position.z = 0;
}
void CDrawObject::setTextureRect(int _x, int _y)
{
	m_textureRect.top = (LONG)_y;
	m_textureRect.bottom = (LONG)(_y+m_height);
	m_textureRect.left = (LONG)_x;
	m_textureRect.right = (LONG)(_x+m_width);
}

void CDrawObject::setTextureRect(RECT _textureRect)
{
	m_textureRect = _textureRect;
}

POINT CDrawObject::getPosition()
{ 
	POINT point;
	point.x = m_position.x;
	point.y = m_position.y; 
	return point;	
}
void CDrawObject::draw(DWORD _timeDelta)
{
	BitBlt();
}

void CDrawObject::BitBlt()
{
	if(m_visible == false)
		return;

	if(m_fileName == "")
		return;
	m_sprite->Begin( D3DXSPRITE_ALPHABLEND );
	m_sprite->Draw( CTextureManager::getInstance()->getTexture(m_fileName)->getTexture(), &m_textureRect, NULL, &m_position, 0xFFFFFFFF);
	m_sprite->End();
}


void CDrawObject::BitBlt(int x,int y, int width,int height, int texX, int texY)
{
	setPosition(x, y);
	setSize(width, height);
	RECT rect = {texX,texY,texX+width,texY+height};
	setTextureRect(rect);
	BitBlt();
}