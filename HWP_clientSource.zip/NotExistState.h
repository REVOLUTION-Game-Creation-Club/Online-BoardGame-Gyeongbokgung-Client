#ifndef __NotExistState_h__
#define __NotExistState_h__
#include "ICharacterState.h"
#include "Character.h"

class CNotExistState : public ICharacterState
{
private:
	CCharacter*				m_character;
public:
	CNotExistState(CCharacter* _character);
	virtual					~CNotExistState();
	void					stateStart(){};
	void					stateEnd(){};
	void					draw(DWORD _timeDelta);
};

#endif