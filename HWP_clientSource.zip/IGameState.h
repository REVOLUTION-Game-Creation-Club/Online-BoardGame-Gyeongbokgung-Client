#ifndef __GameState__h_
#define __GameState__h_

class IGameState{
public:
	virtual bool	initialize() = 0;
	virtual void	release() = 0;

	virtual void	onKeyboard(WPARAM _wParam) = 0;
	virtual void	processMouseMove() = 0;
	virtual void	onUpdate() = 0;

	virtual ~IGameState()	{}
};
#endif