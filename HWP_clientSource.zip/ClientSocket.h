#pragma once

#ifndef _WINSOCKAPI_
#define _WINSOCKAPI_
#endif

#define MAX_ACCEPT 1024


#include "Packet.h"
#include "GameProtocol.h"
#include <stdio.h>
#include <winsock2.h>
#include <process.h>
#include <queue>
#include <list>
#include <fstream>
#include <map>

using namespace std;

typedef	void (*CallbackRoutine)(Packet& packet);

//{{ bakky
const int MAX_BUFFER_SIZE  = PACKETSIZE * 5;
//}}

struct newSocket
{
	SOCKET socket;
	int categori;
};

class CClientSocket
{
private:

	//{{ �� �߰�
	char	m_recvBuffer[ MAX_BUFFER_SIZE ];
	int		m_nWritePosToBuffer;
	fstream	m_fileLog;
	map<int, char*>	m_protocolMap;

	void	makeProtocolMap();
	//}}

	bool m_threadRun;

	SOCKET m_socket;
	SOCKADDR_IN m_addr;
	int m_addrSize;

	Packet m_packet;
	queue<Packet> m_packetQueue;

	fd_set m_fdread;
	newSocket m_newSocket;
	list<newSocket> m_socketList;
	list<newSocket>::iterator m_socketList_Iter;

	CallbackRoutine	callbackFunc;

	HANDLE m_hThread;
	CRITICAL_SECTION m_criticalSection;

	TIMEVAL m_timeout;

public:
	CClientSocket(CallbackRoutine callback);
	~CClientSocket(void);

	bool connectServer(char* _hostAddr, int target);

	void sendPacket(Packet& _packet, int target);
	void recvPacket();
	static unsigned __stdcall ServerRecvThread(void *arg);

	bool processPacket();
	
	void closeSocket();

	char* getHostByName();
};