#ifndef	__TextureManager_h_
#define __TextureManager_h_
#include <map>
#include "Texture.h"
using namespace std;

class CTextureManager
{
private:
	map<string, CTexture*>		m_textureList;
	static	CTextureManager*		selfInstance;
public:
	CTextureManager();
	~CTextureManager();
	static CTextureManager*		getInstance();
	void						release();

	void							createTexture(IDirect3DDevice9* _device, string _name);
	CTexture*						getTexture(string _name);

	//{{ bakky
	void	deleteTexture( string& _name );
	//}}
};
#endif