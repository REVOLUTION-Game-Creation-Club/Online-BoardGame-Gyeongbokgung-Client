#ifndef __CCharacter_h__
#define __CCharacter_h__
#include "SpriteObject.h"
#include "Item.h"
#include "ICharacterState.h"


const int SPRITE_MAX_NUM		= 6;
const int SPRITE_MAX_TYPE		= 10;
const int SPRITE_WIDTH			= 150;
const int SPRITE_HEIGHT			= 150;

const int SPRITE_TYPE_WAIT		= 0;
const int SPRITE_TYPE_WALK1		= 1;
const int SPRITE_TYPE_WALK2		= 2;
const int SPRITE_TYPE_WALK3		= 3;
const int SPRITE_TYPE_WALK4		= 4;
const int SPRITE_TYPE_LEVEL		= 5;
const int SPRITE_TYPE_EXP		= 6;
const int SPRITE_TYPE_FROG		= 7;
const int SPRITE_TYPE_REST		= 8;
const int SPRITE_TYPE_FIGHT		= 9;
const int SPRITE_TYPE_ATTACK	= 10;
const int SPRITE_TYPE_SUFFER	= 11;

const int SPRITE_NUM_WAIT		= 6;
const int SPRITE_NUM_WALK		= 4;
const int SPRITE_NUM_LEVEL		= 12;
const int SPRITE_NUM_EXP		= 8;
const int SPRITE_NUM_FROG		= 6;
const int SPRITE_NUM_REST		= 4;
const int SPRITE_NUM_FIGHT		= 4;
const int SPRITE_NUM_THUNDER	= 6;

const int SPRITE_NUM_ATTACK		= 4;
const int SPRITE_NUM_SUFFER		= 6;
const int SPRITE_NUM_EFFECT		= 5;

const int SPRITE_NUM_DELAY		= 25;
//const int SPRITE_MOVE_DELAY	= 50; // �̵��ӵ� ����
const int SPRITE_MOVE_DELAY		= 25;

const int MAX_LEVEL_NUM			= 200;
enum CHARACTER_TEAM { CHARACTER_TEAM_RED = 0, CHARACTER_TEAM_YELLOW = 1, CHARACTER_TEAM_VIOLET = 2, CHARACTER_TEAM_BLUE = 3, CHARACTER_TEAM_NO};
enum CHARACTER_KIND { CHARACTER_KIND_BOY = 0,CHARACTER_KIND_GIRL = 1, CHARACTER_KIND_GIANT = 2, CHARACTER_KIND_NO };
enum CHARACTER_STATE { CHARACTER_STATE_WAIT = 0, CHARACTER_STATE_WALK, CHARACTER_STATE_REST, CHARACTER_STATE_FIGHT, 
						CHARACTER_STATE_EXP, CHARACTER_STATE_LEVEL, CHARACTER_STATE_THUNDER,
						CHARACTER_STATE_FROG, CHARACTER_STATE_MAGNETIC, CHARACTER_STATE_WATERBALL, CHARACTER_STATE_SUFFER,
						CHARACTER_STATE_NOTEXIST};

class CCharacter:public CSpriteObject{
private:
	int						m_userId;
	int						m_id;
	int						m_level;
	int						m_experience;
	bool					m_carryCharacter;			// ���� �������� ����
	CHARACTER_KIND			m_carryCharacterKind;		// ���� ĳ������ ����
	bool					m_carriedCharacter;			// ���� �������� ����
	bool					m_waterSuffer;				// ����ź�� ���� ���� ����?

	CHARACTER_TEAM			m_team;
	CHARACTER_KIND			m_kind;
	ITEM_KIND				m_itemKind;					// ��� ȿ���� ���� ������
	ITEM_KIND				m_itemSlot;					// �����ϴ� ������
	int						m_tileIndex;
	int						m_tileId;
	int						m_walkCount;
	POINT					m_centerPoint;
	POINT					m_targetPoint;

	bool					m_frog;						// ������ ���� ���� -1*�̵���
	bool					m_inline;					// ���� + 2
	bool					m_sufferFlag;				// ���� ������ �� üũ, 2�ο��� �� �ڵ� ĳ���� ��ȯ�Ŀ� ����
	bool					m_frogOnce;
	bool					m_waterOnce;
	bool					m_thunderOnce;
	bool					m_scrollAvailable;
	bool					m_startFlag;
	bool					m_complete;
	bool					m_itemGetFlag;				// �������� RestState���� �ѹ��� �Ա����� �÷���...
	bool					m_jinsengFlag;				// �������� ����ߴ��� ����...true�̸� Walk����Exp,level�� ��ȯ�� ����... RestState�� ��ȯ
	bool					m_turnOutFlag;				// �Ͼƿ��� �ѹ��� ������ ���� �÷���...
	int						m_sufferCount;				// �󸶳� ���� ���¿���?
	bool					m_thunderFlag;

	// ��ŵó�� 12.01 ����
	bool					m_shortPathFlag;			// ������ �̿� ���� ���� 
	int						m_shortPathCount;
	ICharacterState*		m_waitState;
	ICharacterState*		m_walkState;
	ICharacterState*		m_restState;
	ICharacterState*		m_fightState;
	ICharacterState*		m_expState;
	ICharacterState*		m_levelState;
	ICharacterState*		m_ThunderState;
	ICharacterState*		m_frogState;
	ICharacterState*		m_magneticState;
	ICharacterState*		m_waterBallState;
	ICharacterState*		m_sufferState;
	ICharacterState*		m_notExistState;
	ICharacterState*		m_nowState;
	CHARACTER_STATE			m_characterState;

	//{{ bakky : �ڽ��� ĳ���� �̸� �ϴܿ� �̰��� �׸���.
	void	drawMyCircle( DWORD _timeDelta );
	//}}

public:
							CCharacter(int _userId, int _id, CHARACTER_TEAM _team, CHARACTER_KIND _kind);
	virtual					~CCharacter();

	void					setThunderFlag(bool _thunder){m_thunderFlag = _thunder;}
	bool					isThunderFlag(){return m_thunderFlag;}

	void					draw(DWORD _timeDelta);

	void					initCenterPoint();

	void					setUserId(int _userId){ m_userId = _userId;}
	int						getUserId(){return m_userId;}

	void					setId(int _id){ m_id = _id;}
	int						getId(){return m_id;}

	void					setLevel(int _level){ m_level = _level;}
	int						getLevel(){return m_level;}

	void					setExperience(int _experience){ m_experience = _experience;}
	int						getExperience(){return m_experience;}
	bool					addExperience(int _exp);

	void					setCarryCharacter(bool _carryCharacter){ m_carryCharacter = _carryCharacter;}
	bool					isCarryCharacter(){return m_carryCharacter;}

	void					setCarryCharacterKind(CHARACTER_KIND _carryCharacterKind){ m_carryCharacterKind = _carryCharacterKind;}
	CHARACTER_KIND			getCarryCharacterKind(){return m_carryCharacterKind;}

	void					setCarriedCharacter(bool _carriedCharacter){ m_carriedCharacter = _carriedCharacter;}
	bool					isCarriedCharacter(){return m_carriedCharacter;}

	void					setTeam(CHARACTER_TEAM _team){m_team =  _team;}
	CHARACTER_TEAM			getTeam(){return m_team;}

	void					setKind(CHARACTER_KIND _kind){m_kind = _kind;}
	CHARACTER_KIND			getKind(){return m_kind;}

	void					setCharacterState(CHARACTER_STATE _state);
	CHARACTER_STATE			getCharacterState(){return m_characterState;}

	ICharacterState*		getState(CHARACTER_STATE _state);

	void					setItemKind(ITEM_KIND _itemKind);
	ITEM_KIND				getItemKind(){return m_itemKind;}

	void					setItemSlot(ITEM_KIND _itemSlot){ m_itemSlot = _itemSlot;}
	ITEM_KIND				getItemSlot(){return m_itemSlot;}

	void					setTileIndex(int _tileIndex){ m_tileIndex = _tileIndex;}
	int						getTileIndex(){return m_tileIndex;}

	void					setTileId(int _tileId){ m_tileId = _tileId;}
	int						getTileId(){return m_tileId;}

	void					setWalkCount(int _walkCount){ m_walkCount = _walkCount;}
	int						getWalkCount(){return m_walkCount;}

	void					setFrog(bool _frog){ m_frog = _frog;}
	bool					isFrog(){return m_frog;}

	void					setInline(bool _inline1){ m_inline = _inline1;}
	bool					isInline(){return m_inline;}

	void					setFrogOnce(bool _frogOnce){ m_frogOnce = _frogOnce;}
	bool					isFrogOnce(){return m_frogOnce;}

	void					setWaterOnce(bool _waterOnce){ m_waterOnce = _waterOnce;}
	bool					isWaterOnce(){return m_waterOnce;}

	void					setWaterSuffer(bool _waterSuffer){ m_waterSuffer = _waterSuffer;}
	bool					isWaterSuffer(){return m_waterSuffer;}

	void					setScrollAvailable(bool _scrollAvailable){ m_scrollAvailable = _scrollAvailable;}
	bool					isScrollAvailable(){return m_scrollAvailable;}

	void					setStartFlag(bool _startFlag){ m_startFlag = _startFlag;}
	bool					isStartFlag(){return m_startFlag;}

	void					setComplete(bool _complete){ m_complete = _complete;}
	bool					isComplete(){return m_complete;}

	void					setTurnOutFlag(bool _turnOutFlag){ m_turnOutFlag = _turnOutFlag;}
	bool					isTurnOutFlag(){return m_turnOutFlag;}

	void					setItemGetFlag(bool _itemGetFlag){ m_itemGetFlag = _itemGetFlag;}
	bool					isItemGetFlag(){return m_itemGetFlag;}

	void					setJinsengFlag(bool _jinsengFlag){ m_jinsengFlag = _jinsengFlag;}
	bool					isJinsengFlag(){return m_jinsengFlag;}

	void					setCenterPoint(POINT _centerPoint){ m_centerPoint = _centerPoint;}
	void					setCenterPoint(int _x, int _y){ m_centerPoint.x = _x; m_centerPoint.y = _y;}
	POINT					getCenterPoint(){return m_centerPoint;}

	void					setTargetPoint(POINT _targetPoint){ m_targetPoint = _targetPoint;}
	void					setTargetPoint(int _x, int _y){ m_targetPoint.x = _x; m_targetPoint.y = _y;}
	POINT					getTargetPoint(){return m_targetPoint;}

	void					goback();
	void					clickItem();

	void					setSufferCount(int _sufferCount){ m_sufferCount = _sufferCount;}
	int						getSufferCount(){ return m_sufferCount;}
	
	// ĳ������ �ɼ��� �׸���.
	void					drawOption();
	bool					getItem(int item);

	bool					ThunderAvailable();

	void					turnout();

	bool						skipOnShortPath();
	void						setShorPathCountZero(){m_shortPathCount = 0;}

	void						setShortPathFlag(bool _shortPathFlag);
	bool						isShortPathFlag();



	RECT	getTextureRect()
	{
		return this->m_textureRect;
	}

	void	useItemThunder();
	BOOL	canThunderChar( CCharacter* pChar );

};

#endif