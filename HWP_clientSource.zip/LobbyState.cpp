#include "stdafx.h"
#include "LobbyState.h"
#include "UI/CUIManager.h"
#include "DrawManager.h"
#include "MessageManager.h"
#include "UserManager.h"
#include "PrintObject.h"
#include <time.h>
#include "../RevSound/SoundManager.h"

class ActionListener2 : public Clistener
{
	int currentRoom;

	void requestRoomList()
	{
		CLobbyState* pLobby = (CLobbyState*)CGameManager::getInstance()->getState( GAME_STATE_LOBBY );
		Packet packet(REQ_NEXT_ROOMLIST);
		packet << CUserManager::getInstance()->getMyUserName() << pLobby->getNowPage();
		CMessageManager::getInstance()->sendMessageToMainServer(packet);
	}

	void requestMakeRoom()
	{
		Packet packet(REQ_MAKE_ROOM);

		char roomName[ROOM_ID_LENGTH]={0};
		strcpy(roomName, "");

		CTextBox& inputName = CUIManager::getInstance()["makeRoomPopUp"].getTextBox("inputRoomName");

		strcpy(roomName, inputName.getString());

		if( !strcmp(roomName, "") )
		{
			int random = rand()%8;

			switch(random)
			{
			case 0:
				strcpy(roomName, "�Բ� �ؿ�");
				break;
			case 1:
				strcpy(roomName, "������ ����!!");
				break;
			case 2:
				strcpy(roomName, "�ƹ��� ������~");
				break;
			case 3:
				strcpy(roomName, "��ȭ�� �̿�!!");
				break;
			case 4:
				strcpy(roomName, "�˻󱸰� �����Ŀ� �Ф�");
				break;
			case 5:
				strcpy(roomName, "�������� �κ񿡼� ���ٰ�!!");
				break;
			case 6:
				strcpy(roomName, "����~ ������~");
				break;
			case 7:
				strcpy(roomName, "���� �޷�");
				break;
			default:
				strcpy(roomName, "-_-");
				break;
			}
		}

		packet << CUserManager::getInstance()->getMyUserName()
			<< roomName
			<< ""
			<< CUserManager::getInstance()->getMyUserIP();

		CMessageManager::getInstance()->sendMessageToMainServer(packet);
	}

public:

	void action()
	{
		// �� ���� ������ ���
		if( getEvented().compare("room1_button") == 0 )
		{
			// ������Ʈ ��ȭ
			// �ش� �� ���� ��û
			getSoundManager()->play("��ưŬ��3", FALSE);
			currentRoom = 0;
			CLobbyState* pLobby = (CLobbyState*)CGameManager::getInstance()->getState( GAME_STATE_LOBBY );
			if ( pLobby->getRoomNo(0) )
			{
				Packet packet(REQ_ENTER_ROOM);
				packet << CUserManager::getInstance()->getMyUserName() << pLobby->getRoomNo(0) << "";
				CMessageManager::getInstance()->sendMessageToMainServer(packet);
			}
			return;
		}

		if( getEvented().compare("room2_button") == 0)
		{
			// ������Ʈ ��ȭ
			// �ش� �� ���� ��û
			getSoundManager()->play("��ưŬ��3", FALSE);
			currentRoom = 1;
			CLobbyState* pLobby = (CLobbyState*)CGameManager::getInstance()->getState( GAME_STATE_LOBBY );
						if ( pLobby->getRoomNo(1) )
			{
				Packet packet(REQ_ENTER_ROOM);
				packet << CUserManager::getInstance()->getMyUserName() << pLobby->getRoomNo(1) << "";
				CMessageManager::getInstance()->sendMessageToMainServer(packet);
			}
			return;
		}
			
		if( getEvented().compare("room3_button") == 0)
		{
			// ������Ʈ ��ȭ
			// �ش� �� ���� ��û
			getSoundManager()->play("��ưŬ��3", FALSE);
			currentRoom = 2;
			CLobbyState* pLobby = (CLobbyState*)CGameManager::getInstance()->getState( GAME_STATE_LOBBY );
			if ( pLobby->getRoomNo(2) )
			{
				Packet packet(REQ_ENTER_ROOM);
				packet << CUserManager::getInstance()->getMyUserName() << pLobby->getRoomNo(2) << "";
				CMessageManager::getInstance()->sendMessageToMainServer(packet);
			}
			return;
		}

		if( getEvented().compare("room4_button") == 0)
		{
			// ������Ʈ ��ȭ
			// �ش� �� ���� ��û
			getSoundManager()->play("��ưŬ��3", FALSE);
			currentRoom = 3;
			CLobbyState* pLobby = (CLobbyState*)CGameManager::getInstance()->getState( GAME_STATE_LOBBY );
			if ( pLobby->getRoomNo(3) )
			{
				Packet packet(REQ_ENTER_ROOM);
				packet << CUserManager::getInstance()->getMyUserName() << pLobby->getRoomNo(3) << "";
				CMessageManager::getInstance()->sendMessageToMainServer(packet);
			}
			return;
		}

		// �� ����Ʈ ����
		if( getEvented().compare("refresh_button") == 0)
		{
			getSoundManager()->play("��ưŬ��2", FALSE);
			// �� ����Ʈ �ٽ� ��û
			CLobbyState* pLobby = (CLobbyState*)CGameManager::getInstance()->getState( GAME_STATE_LOBBY );
			pLobby->setNowPage(1);
			requestRoomList();
			return;
		}

		// �渮��Ʈ�� ���� �������� ��û
		if(getEvented().compare("nextPage_button") == 0)
		{
			getSoundManager()->play("��ưŬ��1", FALSE);
			CLobbyState* pLobby = (CLobbyState*)CGameManager::getInstance()->getState( GAME_STATE_LOBBY );
			pLobby->setNowPage(pLobby->getNowPage()+1);
			requestRoomList();
			return;
		}

		// �渮��Ʈ�� ���� �������� ��û
		if(getEvented().compare("prePage_button") == 0)
		{
			getSoundManager()->play("��ưŬ��1", FALSE);
			CLobbyState* pLobby = (CLobbyState*)CGameManager::getInstance()->getState( GAME_STATE_LOBBY );
			if(pLobby->getNowPage() != 1)
				pLobby->setNowPage(pLobby->getNowPage()-1);
			requestRoomList();
			return;
		}

		// ���� ����Ʈ ���� ������
		if(getEvented().compare("preUserList_button") == 0)
		{
			getSoundManager()->play("��ưŬ��1", FALSE);
			Packet tPacket;
			CLobbyState* pLobby = (CLobbyState*)CGameManager::getInstance()->getState( GAME_STATE_LOBBY );
			tPacket = pLobby->getUserList();

			char id[USER_ID_LENGTH]={0};
			CUIDialogbox& playersList = CUIManager::getInstance()["lobbyContainer"].getDialogBox("playersList");

			if(pLobby->getNowULPage() < 2)
				return;
			else
			{
				playersList.reset();
				for(int i=0; i < (pLobby->getNowULPage()-1)*USERS_PER_PAGE; i++)
				{
					tPacket >> id;
					if(!strcmp(id, ""))
						return;
					playersList.insertString(id);
				}
			}
			pLobby->setNowULPage(pLobby->getNowULPage()-1);
			return;
		}

		// ���� ����Ʈ ���� ������
		if(getEvented().compare("nextUserList_button") == 0)
		{
			getSoundManager()->play("��ưŬ��1", FALSE);
			Packet tPacket;
			CLobbyState* pLobby = (CLobbyState*)CGameManager::getInstance()->getState( GAME_STATE_LOBBY );
			tPacket = pLobby->getUserList();

			char id[USER_ID_LENGTH]={0};
			CUIDialogbox& playersList = CUIManager::getInstance()["lobbyContainer"].getDialogBox("playersList");
			// playersList.release();
			playersList.reset();

			for(int i=0; i < (pLobby->getNowULPage()+1)*USERS_PER_PAGE; i++)
			{
				tPacket >> id;
				if(!strcmp(id, ""))
					return;
				playersList.insertString(id);
			}
			pLobby->setNowULPage(pLobby->getNowULPage()+1);
			return;
		}

		// ������ ������ ���
		if( getEvented().compare("exit_button") == 0)
		{
			getSoundManager()->play("��ưŬ��1", FALSE);
			// ������Ʈ ��ȯ
			CUIManager::getInstance()["lobbyContainer"].setEnable(FALSE);
			CUIManager::getInstance()["exitPopUp"].setEnable(TRUE);
			return;
		}

		// ������ Ȯ�� ��ư
		if( getEvented().compare("exitAcceptButton") == 0)
		{
			getSoundManager()->play("��ưŬ��1", FALSE);
			CUIManager::getInstance()["exitPopUp"].setEnable(FALSE);
			CUIManager::getInstance()["endScreen"].setEnable(TRUE);
			CDrawManager::getInstance()->display(0);
			Packet packet(REQ_DISCONNECT);
			packet << CUserManager::getInstance()->getMyUserName();
			CMessageManager::getInstance()->sendMessageToMainServer(packet);
			Sleep(1000);
			PostQuitMessage(0);
		}

		// ������ ��� ��ư
		if(getEvented().compare("exitCancelButton") == 0)
		{
			getSoundManager()->play("��ưŬ��1", FALSE);
			// ������Ʈ ��ȯ
			// �˾� �������
			CUIManager::getInstance()["lobbyContainer"].setEnable(TRUE);
			CUIManager::getInstance()["exitPopUp"].setEnable(FALSE);
			requestRoomList();
			return;
		}

		// �游��� ��ư
		if( getEvented().compare("make_room") == 0)
		{
			getSoundManager()->play("��ưŬ��1", FALSE);
			// ������Ʈ ��ȯ
			// �˾� ȭ�� ���
			getIME()->ClearBufstr();
			CUIManager::getInstance()["lobbyContainer"].setEnable(FALSE);
			CUIManager::getInstance()["makeRoomPopUp"].setEnable(TRUE);

			CTextBox& inputName = CUIManager::getInstance()["makeRoomPopUp"].getTextBox("inputRoomName");
			CUIManager::getInstance().setActiveTextbox(&inputName);

			return;
		}

		// �� ����� Ȯ�� ��ư
		if(getEvented().compare("makeRoomAcceptButton") == 0)
		{
			getSoundManager()->play("��ưŬ��1", FALSE);
			requestMakeRoom();
			return;
		}

		// �� ����� ��� ��ư
		if(getEvented().compare("makeRoomCancelButton") == 0)
		{
			getSoundManager()->play("��ưŬ��1", FALSE);
			// ������Ʈ ��ȯ
			// �˾� �������
			CUIManager::getInstance()["lobbyContainer"].setEnable(TRUE);
			CUIManager::getInstance()["makeRoomPopUp"].setEnable(FALSE);
			requestRoomList();
			getIME()->ClearBufstr();
			return;
		}

		// �н����� Ȯ�� ��ư
		if(getEvented().compare("enterPWAcceptButton") == 0)
		{
			getSoundManager()->play("��ưŬ��1", FALSE);
			Packet packet(REQ_ENTER_ROOM);

			CLobbyState* pLobby = (CLobbyState*)CGameManager::getInstance()->getState( GAME_STATE_LOBBY );

			packet << CUserManager::getInstance()->getMyUserName()
				<< pLobby->getRoomNo(currentRoom)
				<< "";

			CMessageManager::getInstance()->sendMessageToMainServer(packet);

			return;
		}

		// �н����� ��� ��ư
		if(getEvented().compare("enterPWCancelButton") == 0)
		{
			getSoundManager()->play("��ưŬ��1", FALSE);
			// ������Ʈ ��ȯ
			// �˾� �������
			CUIManager::getInstance()["lobbyContainer"].setEnable(TRUE);
			CUIManager::getInstance()["inputPWPopUp"].setEnable(FALSE);
			requestRoomList();
			getIME()->ClearBufstr();
			return;
		}

		// �������� �ʴ� �� Ȯ�� ��ư
		if(getEvented().compare("notExistAcceptButton") == 0)
		{
			getSoundManager()->play("��ưŬ��1", FALSE);
			CUIManager::getInstance()["lobbyContainer"].setEnable(TRUE);
			CUIManager::getInstance()["notExist"].setEnable(FALSE);
			requestRoomList();
			return;
		}

		// �ο��ʰ� Ȯ�� ��ư
		if(getEvented().compare("isFullAcceptButton") == 0)
		{
			getSoundManager()->play("��ưŬ��1", FALSE);
			CUIManager::getInstance()["lobbyContainer"].setEnable(TRUE);
			CUIManager::getInstance()["isFull"].setEnable(FALSE);
			requestRoomList();
			return;
		}

		// ������ Ȯ�� ��ư
		if(getEvented().compare("onPlayAcceptButton") == 0)
		{
			getSoundManager()->play("��ưŬ��1", FALSE);
			CUIManager::getInstance()["lobbyContainer"].setEnable(TRUE);
			CUIManager::getInstance()["onPlay"].setEnable(FALSE);
			requestRoomList();
			return;
		}

		// ���� ������ Ȯ�� ��ư
		if(getEvented().compare("disconnectedAcceptButton") == 0)
		{
			getSoundManager()->play("��ưŬ��3", FALSE);
			CUIManager::getInstance()["mainDisconnected"].setEnable(FALSE);
			CUIManager::getInstance()["endScreen"].setEnable(TRUE);
			Sleep(1000);
			PostQuitMessage(0);
		}
}

public:
	void textChanged()
	{
		getIME()->setPos(543, -20);

		if( CUIManager::getInstance()["lobbyContainer"].isEnable() )
		{
			char temp[50] = {0};
			getIME()->GetStr( temp, 49 );
			CUIManager::getInstance()["lobbyContainer"].getTextBox("lobbyChat").changeString(temp);
		}
		if( CUIManager::getInstance()["makeRoomPopUp"].isEnable() )
		{
			char temp[50] = {0};
			getIME()->GetStr( temp, 49 );
			CUIManager::getInstance()["makeRoomPopUp"].getTextBox("inputRoomName").changeString(temp);
		}
		if( CUIManager::getInstance()["inputPWPopUp"].isEnable() )
		{
			char temp[50] = {0};
			getIME()->GetStr( temp, 49 );
			CUIManager::getInstance()["inputPWPopUp"].getTextBox("inputPW_enter").changeString(temp);
		}
	}

	void pressReturn() 
	{	
		if( CUIManager::getInstance()["lobbyContainer"].isEnable() )
		{
			CUIDialogbox& chatlist = CUIManager::getInstance()["lobbyContainer"].getDialogBox("chatlist");
			CTextBox& chat = CUIManager::getInstance()["lobbyContainer"].getTextBox("lobbyChat");

			if( !strcmp(chat.getString(), "") )
				return;

			Packet packet(REQ_CHAT);
			packet << CUserManager::getInstance()->getMyUserName() << 0 << chat.getString();
			CMessageManager::getInstance()->sendMessageToMainServer(packet);

			getIME()->ClearBufstr();
			chat.activeControl(REV_MOUSE_DOWN);
			return;
		}

		if( CUIManager::getInstance()["makeRoomPopUp"].isEnable() )
		{
			requestMakeRoom();
			return;
		}

		if( CUIManager::getInstance()["inputPWPopUp"].isEnable() )
		{
			CTextBox& inputName = CUIManager::getInstance()["inputPWPopUp"].getTextBox("inputPW_enter");

			getIME()->ClearBufstr();
			inputName.activeControl(REV_MOUSE_DOWN);
		}
	}
};



CLobbyState::CLobbyState(CGameManager* _gameManager)
{
	this->m_gameManager = _gameManager;

	m_nowPage = 1;
	m_nowUserListPage = 1;
	m_lastTime = GetTickCount();

	srand(time(NULL));

	memset(m_roomNO, 0, sizeof(m_roomNO));
}

CLobbyState::~CLobbyState()
{
}

bool	CLobbyState::initialize()
{
	getSoundManager()->play("�κ�",true);

	m_listener = new ActionListener2();



	/*******************/
	/* �κ� �����̳ʵ� */
	/*******************/

	// �κ� ��� �����̳�
	CUIManager& manager = CUIManager::getInstance();
	manager.makeContainer("lobbyBackground", 0, 0, 1024, 768, 0, 0, "image/lBackground.bmp");

	// �⺻ �κ� �����̳�
	manager.makeContainer("lobbyContainer", 0, 0, 1024, 768, 1024, 768, "image/lButtons.bmp");
	CUIContainer& lobbyContainer = manager["lobbyContainer"];

	// �游���� �˾� ������ �����̳�
	manager.makeContainer("makeRoomPopUp", 312, 278, 400, 212, 624, 652, "image/lButtons.bmp");
	CUIContainer& makeRoomPopUp = manager["makeRoomPopUp"];

	// ��й�ȣ �Է¿� �˾� ������ �����̳�
	manager.makeContainer("inputPWPopUp", 312, 304, 400, 160, 624, 864, "image/lButtons.bmp");
	CUIContainer& inputPWPopUp = manager["inputPWPopUp"];

	// ������ Ȯ�ο� �˾� ������ �����̳�
	manager.makeContainer("exitPopUp", 314, 304, 396, 160, 628, 492, "image/lButtons.bmp");
	CUIContainer& exitPopUp = manager["exitPopUp"];

	// �������� �ʴ� �� �˾� ������ �����̳�
	manager.makeContainer("notExist", 315, 304, 396, 160, 0, 160, "image/lError.bmp");
	CUIContainer& notExist = manager["notExist"];

	// �ο��ʰ� �˾� ������ �����̳�
	manager.makeContainer("isFull", 315, 304, 396, 160, 0, 0, "image/lError.bmp");
	CUIContainer& isFull = manager["isFull"];

	// ���� ������ �˾� ������ �����̳�
	manager.makeContainer("mainDisconnected", 257, 304, 510, 160, 0, 480, "image/lError.bmp");
	CUIContainer& mainDisconnected = manager["mainDisconnected"];

	// ������ �˾� ������ �����̳�
	manager.makeContainer("onPlay", 257, 304, 510, 160, 0, 320, "image/lError.bmp");
	CUIContainer& onPlay = manager["onPlay"];

	// ���� ȭ��
	manager.makeContainer("endScreen", 0, 0, 1024, 768, 0, 0, "image/endscreen.bmp");
	CUIContainer& endScreen = manager["endScreen"];
	endScreen.setEnable(FALSE);
	



	/****************/
	/* �� �⺻ UI�� */
	/****************/

	// ȭ�鿡 ���̴� �� ��ư
	lobbyContainer.add("button", "room1_button", 286, 25, 370, 250, 0, 545, "image/lButtons.bmp");
	lobbyContainer.add("button", "room2_button", 654, 25, 370, 250, 0, 545, "image/lButtons.bmp");
	lobbyContainer.add("button", "room3_button", 286, 265, 370, 250, 0, 545, "image/lButtons.bmp");
	lobbyContainer.add("button", "room4_button", 654, 265, 370, 250, 0, 545, "image/lButtons.bmp");
	lobbyContainer["room1_button"].addListener(m_listener);
	lobbyContainer["room2_button"].addListener(m_listener);
	lobbyContainer["room3_button"].addListener(m_listener);
	lobbyContainer["room4_button"].addListener(m_listener);
	lobbyContainer.getButton("room1_button").setImageFlag(REV_NORMAL);
	lobbyContainer.getButton("room2_button").setImageFlag(REV_NORMAL);
	lobbyContainer.getButton("room3_button").setImageFlag(REV_NORMAL);
	lobbyContainer.getButton("room4_button").setImageFlag(REV_NORMAL);

	// �游��� ��ư
	lobbyContainer.add("button", "make_room", 24, 197, 240, 80, 0, 0,"image/lButtons.bmp");
	lobbyContainer.getButton("make_room").setImageFlag(REV_NORMAL|REV_ROLLOVER);
	lobbyContainer["make_room"].addListener(m_listener);

	// ������ ��ư
	lobbyContainer.add("button", "exit_button", 23, 279, 240, 80, 0, 80,"image/lButtons.bmp");
	lobbyContainer.getButton("exit_button").setImageFlag(REV_NORMAL|REV_ROLLOVER);
	lobbyContainer["exit_button"].addListener(m_listener);

	// �� ����Ʈ �ڵ鸵 ��ư
	lobbyContainer.add("button", "prePage_button", 583, 515, 73, 50, 0, 265, "image/lButtons.bmp");
	lobbyContainer.add("button", "nextPage_button", 659, 515, 73, 50, 0, 315, "image/lButtons.bmp");
	lobbyContainer.getButton("prePage_button").setImageFlag(REV_NORMAL|REV_ROLLOVER);
	lobbyContainer.getButton("nextPage_button").setImageFlag(REV_NORMAL|REV_ROLLOVER);
	lobbyContainer["nextPage_button"].addListener(m_listener);
	lobbyContainer["prePage_button"].addListener(m_listener);

	// ������ ����Ʈ �ڵ鸵 ��ư
	lobbyContainer.add("button", "preUserList_button", 101, 691, 59, 45, 0, 365, "image/lButtons.bmp");
	lobbyContainer.add("button", "nextUserList_button", 162, 691, 59, 45, 0, 410, "image/lButtons.bmp");
	lobbyContainer.getButton("preUserList_button").setImageFlag(REV_NORMAL|REV_ROLLOVER);
	lobbyContainer.getButton("nextUserList_button").setImageFlag(REV_NORMAL|REV_ROLLOVER);
	lobbyContainer["nextUserList_button"].addListener(m_listener);
	lobbyContainer["preUserList_button"].addListener(m_listener);

	// �������� ��ư
	lobbyContainer.add("button", "refresh_button", 342, 610, 105, 105, 0,160,"image/lButtons.bmp");
	lobbyContainer.getButton("refresh_button").setImageFlag(REV_NORMAL|REV_ROLLOVER);
	lobbyContainer["refresh_button"].addListener(m_listener);

	// ä�� �޽��� �ö���� ���̾�α�
	lobbyContainer.add("dialogbox", "chatlist", 524, 590, 427, 98, 0, 795, "image/lButtons.bmp");
	CUIDialogbox& chatlist = lobbyContainer.getDialogBox("chatlist");
	chatlist.setFontPosition(10, 10);
	chatlist.setFontColor(255,255,255,100);
	chatlist.setFontSize(7);
	chatlist.setLineSpace(7);
	chatlist.setRange(5);

	// ä�� �޽��� �Է��ϴ� �ؽ�Ʈ �ڽ�
	lobbyContainer.add("textbox","lobbyChat", 533, 712, 410, 22, 0, 795+98, "image/lButtons.bmp");
	lobbyContainer.getTextBox("lobbyChat").setFontColor(255,255,255,100);
	lobbyContainer.getTextBox("lobbyChat").setFontSize(7);
	lobbyContainer.getTextBox("lobbyChat").setFontPosition(10, 1);
	lobbyContainer.getTextBox("lobbyChat").addListener(m_listener);
	CTextBox& chat = CUIManager::getInstance()["lobbyContainer"].getTextBox("lobbyChat");
	CUIManager::getInstance().setActiveTextbox(&chat);

	// ������ ����Ʈ ���̴� ���̾�α�
	lobbyContainer.add("dialogbox", "playersList", 87, 495, 150, 200, 370, 545, "image/lButtons.bmp");
	CUIDialogbox& playersList = lobbyContainer.getDialogBox("playersList");
	playersList.setFontPosition(30, 10);
	playersList.setFontColor(255,255,255,100);
	playersList.setFontSize(9);
	playersList.setLineSpace(7);
	playersList.setRange(5);

	// �� ���� �̸��� ���̴� ���̾�α�
	lobbyContainer.add("dialogbox", "room_name1", 286, 89, 370, 27, 0, 609, "image/lButtons.bmp");
	CUIDialogbox& room_name1 = lobbyContainer.getDialogBox("room_name1");
	room_name1.setFontPosition(60, 5);
	room_name1.setFontColor(255,255,255,100);
	room_name1.setFontSize(7);
	room_name1.setLineSpace(7);
	room_name1.setRange(5);
	
	lobbyContainer.add("dialogbox", "room_name2",  654, 89, 370, 27, 0, 609, "image/lButtons.bmp");
	CUIDialogbox& room_name2 = lobbyContainer.getDialogBox("room_name2");
	room_name2.setFontPosition(60, 5);
	room_name2.setFontColor(255,255,255,100);
	room_name2.setFontSize(7);
	room_name2.setLineSpace(7);
	room_name2.setRange(5);
	
	lobbyContainer.add("dialogbox", "room_name3", 286, 329, 370, 27, 0, 609, "image/lButtons.bmp");
	CUIDialogbox& room_name3 = lobbyContainer.getDialogBox("room_name3");
	room_name3.setFontPosition(60, 5);
	room_name3.setFontColor(255,255,255,100);
	room_name3.setFontSize(7);
	room_name3.setLineSpace(7);
	room_name3.setRange(5);
	
	lobbyContainer.add("dialogbox", "room_name4", 654, 329, 370, 27, 0, 609, "image/lButtons.bmp");
	CUIDialogbox& room_name4 = lobbyContainer.getDialogBox("room_name4");
	room_name4.setFontPosition(60, 5);
	room_name4.setFontColor(255,255,255,100);
	room_name4.setFontSize(7);
	room_name4.setLineSpace(7);
	room_name4.setRange(5);
	
	// �濡�� ������ �� �̹����ڽ�
	lobbyContainer.add("imagebox", "room1_map", 342, 128, 128, 95, 0, 915, "image/lButtons.bmp");
	lobbyContainer.add("imagebox", "room2_map", 710, 128, 128, 95, 0, 915, "image/lButtons.bmp");
	lobbyContainer.add("imagebox", "room3_map", 342, 368, 128, 95, 0, 915, "image/lButtons.bmp");
	lobbyContainer.add("imagebox", "room4_map", 710, 368, 128, 95, 0, 915, "image/lButtons.bmp");
	lobbyContainer.getImageBox("room1_map").visible = FALSE;
	lobbyContainer.getImageBox("room2_map").visible = FALSE;
	lobbyContainer.getImageBox("room3_map").visible = FALSE;
	lobbyContainer.getImageBox("room4_map").visible = FALSE;	

	// ���� �̸� �̹����ڽ�
	lobbyContainer.add("imagebox", "room1_mapName", 482, 155, 105, 24, 144, 1000, "image/lButtons.bmp");
	lobbyContainer.add("imagebox", "room2_mapName", 850, 155, 105, 24, 144, 1000, "image/lButtons.bmp");
	lobbyContainer.add("imagebox", "room3_mapName", 482, 395, 105, 24, 144, 1000, "image/lButtons.bmp");
	lobbyContainer.add("imagebox", "room4_mapName", 850, 395, 105, 24, 144, 1000, "image/lButtons.bmp");
	lobbyContainer.add("imagebox", "room1_mapType", 488, 205, 54, 22, 144, 978, "image/lButtons.bmp");
	lobbyContainer.add("imagebox", "room2_mapType", 856, 205, 54, 22, 144, 978, "image/lButtons.bmp");
	lobbyContainer.add("imagebox", "room3_mapType", 488, 445, 54, 22, 144, 978, "image/lButtons.bmp");
	lobbyContainer.add("imagebox", "room4_mapType", 856, 445, 54, 22, 144, 978, "image/lButtons.bmp");
	lobbyContainer.getImageBox("room1_mapName").visible = FALSE;
	lobbyContainer.getImageBox("room2_mapName").visible = FALSE;
	lobbyContainer.getImageBox("room3_mapName").visible = FALSE;
	lobbyContainer.getImageBox("room4_mapName").visible = FALSE;
	lobbyContainer.getImageBox("room1_mapType").visible = FALSE;
	lobbyContainer.getImageBox("room2_mapType").visible = FALSE;
	lobbyContainer.getImageBox("room3_mapType").visible = FALSE;
	lobbyContainer.getImageBox("room4_mapType").visible = FALSE;

	// �� ���� ���� �̹����ڽ� (����Ʈ / Ǯ / ������ / ���� ����) �� ��Ÿ��
	lobbyContainer.add("imagebox", "room1_state_wait", 578, 196, 55, 55, 0, 455, "image/lButtons.bmp");
	lobbyContainer.add("imagebox", "room2_state_wait", 946, 196, 55, 55, 0, 455, "image/lButtons.bmp");
	lobbyContainer.add("imagebox", "room3_state_wait", 578, 436, 55, 55, 0, 455, "image/lButtons.bmp");
	lobbyContainer.add("imagebox", "room4_state_wait", 946, 436, 55, 55, 0, 455, "image/lButtons.bmp");
	lobbyContainer.getImageBox("room1_state_wait").visible = FALSE;
	lobbyContainer.getImageBox("room2_state_wait").visible = FALSE;
	lobbyContainer.getImageBox("room3_state_wait").visible = FALSE;
	lobbyContainer.getImageBox("room4_state_wait").visible = FALSE;
	lobbyContainer.add("imagebox", "room1_state_onPlay", 578, 196, 55, 55, 55, 455, "image/lButtons.bmp");
	lobbyContainer.add("imagebox", "room2_state_onPlay", 946, 196, 55, 55, 55, 455, "image/lButtons.bmp");
	lobbyContainer.add("imagebox", "room3_state_onPlay", 578, 436, 55, 55, 55, 455, "image/lButtons.bmp");
	lobbyContainer.add("imagebox", "room4_state_onPlay", 946, 436, 55, 55, 55, 455, "image/lButtons.bmp");
	lobbyContainer.getImageBox("room1_state_onPlay").visible = FALSE;
	lobbyContainer.getImageBox("room2_state_onPlay").visible = FALSE;
	lobbyContainer.getImageBox("room3_state_onPlay").visible = FALSE;
	lobbyContainer.getImageBox("room4_state_onPlay").visible = FALSE;
	lobbyContainer.add("imagebox", "room1_state_full", 578, 196, 55, 55, 110, 455, "image/lButtons.bmp");
	lobbyContainer.add("imagebox", "room2_state_full", 946, 196, 55, 55, 110, 455, "image/lButtons.bmp");
	lobbyContainer.add("imagebox", "room3_state_full", 578, 436, 55, 55, 110, 455, "image/lButtons.bmp");
	lobbyContainer.add("imagebox", "room4_state_full", 946, 436, 55, 55, 110, 455, "image/lButtons.bmp");
	lobbyContainer.getImageBox("room1_state_full").visible = FALSE;
	lobbyContainer.getImageBox("room2_state_full").visible = FALSE;
	lobbyContainer.getImageBox("room3_state_full").visible = FALSE;
	lobbyContainer.getImageBox("room4_state_full").visible = FALSE;

	// �� ���� �н����� ���� �̹��� �ڽ�
	lobbyContainer.add("imagebox", "room1_pwIs", 308, 48, 35, 35, 35, 510, "image/lButtons.bmp");
	lobbyContainer.add("imagebox", "room2_pwIs", 676, 48, 35, 35, 35, 510, "image/lButtons.bmp");
	lobbyContainer.add("imagebox", "room3_pwIs", 308, 288, 35, 35, 35, 510, "image/lButtons.bmp");
	lobbyContainer.add("imagebox", "room4_pwIs", 676, 288, 35, 35, 35, 510, "image/lButtons.bmp");
	lobbyContainer.getImageBox("room1_pwIs").visible = FALSE;
	lobbyContainer.getImageBox("room2_pwIs").visible = FALSE;
	lobbyContainer.getImageBox("room3_pwIs").visible = FALSE;
	lobbyContainer.getImageBox("room4_pwIs").visible = FALSE;
	lobbyContainer.add("imagebox", "room1_pwNot", 308, 48, 35, 35, 0, 510, "image/lButtons.bmp");
	lobbyContainer.add("imagebox", "room2_pwNot", 676, 48, 35, 35, 0, 510, "image/lButtons.bmp");
	lobbyContainer.add("imagebox", "room3_pwNot", 308, 288, 35, 35, 0, 510, "image/lButtons.bmp");
	lobbyContainer.add("imagebox", "room4_pwNot", 676, 288, 35, 35, 0, 510, "image/lButtons.bmp");
	lobbyContainer.getImageBox("room1_pwNot").visible = FALSE;
	lobbyContainer.getImageBox("room2_pwNot").visible = FALSE;
	lobbyContainer.getImageBox("room3_pwNot").visible = FALSE;
	lobbyContainer.getImageBox("room4_pwNot").visible = FALSE;



	/**************************/
	/* �游���� �˾� ������ */
	/**************************/
	
	// �� ���� Ȯ�� ��ư
	makeRoomPopUp.add("button", "makeRoomAcceptButton", 439, 442, 72, 42, 736, 366, "image/lButtons.bmp");
	makeRoomPopUp.getButton("makeRoomAcceptButton").setImageFlag(REV_NORMAL|REV_ROLLOVER);
	makeRoomPopUp["makeRoomAcceptButton"].addListener(m_listener);

	// �� ���� ��� ��ư
	makeRoomPopUp.add("button", "makeRoomCancelButton", 522, 442, 72, 42, 736, 324, "image/lButtons.bmp");
	makeRoomPopUp.getButton("makeRoomCancelButton").setImageFlag(REV_NORMAL|REV_ROLLOVER);
	makeRoomPopUp["makeRoomCancelButton"].addListener(m_listener);

	// �� �̸� �Է� �ؽ�Ʈ �ڽ�
	makeRoomPopUp.add("textbox","inputRoomName", 312+115, 278+35, 400-115, 30, 624+115, 652+35, "image/lButtons.bmp");
	makeRoomPopUp.getTextBox("inputRoomName").setFontColor(255,255,255,100);
	makeRoomPopUp.getTextBox("inputRoomName").setFontSize(7);
	makeRoomPopUp.getTextBox("inputRoomName").setFontPosition(10, 5);
	makeRoomPopUp.getTextBox("inputRoomName").addListener(m_listener);

	// �н����� �Է� �ؽ�Ʈ �ڽ�
	makeRoomPopUp.add("textbox","inputPW_make", 312+115, 278+80, 400-115, 30, 624+115, 652+80, "image/lButtons.bmp");
	makeRoomPopUp.getTextBox("inputPW_make").setFontColor(255,255,255,100);
	makeRoomPopUp.getTextBox("inputPW_make").setFontSize(7);
	makeRoomPopUp.getTextBox("inputPW_make").setFontPosition(10, 5);
	makeRoomPopUp.getTextBox("inputPW_make").addListener(m_listener);
	makeRoomPopUp.getTextBox("inputPW_make").insertString("���� �������� �ʴ� ����Դϴ�.");

	makeRoomPopUp.setEnable(FALSE);



	/*******************************/
	/* ��й�ȣ �Է¿� �˾� ������ */
	/*******************************/

	// �н����� �Է� Ȯ�� ��ư
	inputPWPopUp.add("button", "enterPWAcceptButton", 436, 422, 72, 42, 736, 450, "image/lButtons.bmp");
	inputPWPopUp.getButton("enterPWAcceptButton").setImageFlag(REV_NORMAL|REV_ROLLOVER);
	inputPWPopUp["enterPWAcceptButton"].addListener(m_listener);

	// �н����� �Է� ��� ��ư
	inputPWPopUp.add("button", "enterPWCancelButton", 518, 422, 72, 42, 736, 408, "image/lButtons.bmp");
	inputPWPopUp.getButton("enterPWCancelButton").setImageFlag(REV_NORMAL|REV_ROLLOVER);
	inputPWPopUp["enterPWCancelButton"].addListener(m_listener);

	// �н����� �Է� �ؽ�Ʈ �ڽ�
	inputPWPopUp.add("textbox","inputPW_enter", 533, 712, 410, 22, 0, 795+98, "image/lButtons.bmp");
	inputPWPopUp.getTextBox("inputPW_enter").setFontColor(255,255,255,100);
	inputPWPopUp.getTextBox("inputPW_enter").setFontSize(7);
	inputPWPopUp.getTextBox("inputPW_enter").setFontPosition(10, 5);
	inputPWPopUp.getTextBox("inputPW_enter").addListener(m_listener);
	CTextBox& inputPW_enter = CUIManager::getInstance()["inputPWPopUp"].getTextBox("inputPW_enter");
	CUIManager::getInstance().setActiveTextbox(&inputPW_enter);

	inputPWPopUp.setEnable(FALSE);



	/*****************************/
	/* ������ Ȯ�ο� �˾� ������ */
	/*****************************/
	
	// ������ Ȯ�� ��ư
	exitPopUp.add("button", "exitAcceptButton", 436, 422, 72, 42, 736, 450, "image/lButtons.bmp");
	exitPopUp.getButton("exitAcceptButton").setImageFlag(REV_NORMAL|REV_ROLLOVER);
	exitPopUp["exitAcceptButton"].addListener(m_listener);

	// ������ �Է� ��� ��ư
	exitPopUp.add("button", "exitCancelButton", 518, 422, 72, 42, 736, 408, "image/lButtons.bmp");
	exitPopUp.getButton("exitCancelButton").setImageFlag(REV_NORMAL|REV_ROLLOVER);
	exitPopUp["exitCancelButton"].addListener(m_listener);

	exitPopUp.setEnable(FALSE);



	/********************************/
	/* �������� �ʴ� �� �˾� ������ */
	/********************************/

	// �������� �ʴ� �� Ȯ�� ��ư
	notExist.add("button", "notExistAcceptButton", 476, 423, 72, 42, 0, 1024-42, "image/lError.bmp");
	notExist.getButton("notExistAcceptButton").setImageFlag(REV_NORMAL|REV_ROLLOVER);
	notExist["notExistAcceptButton"].addListener(m_listener);

	notExist.setEnable(FALSE);



	/************************/
	/* �ο��ʰ� �˾� ������ */
	/************************/

	// �ο��ʰ� Ȯ�� ��ư
	isFull.add("button", "isFullAcceptButton", 476, 423, 72, 42, 0, 1024-42, "image/lError.bmp");
	isFull.getButton("isFullAcceptButton").setImageFlag(REV_NORMAL|REV_ROLLOVER);
	isFull["isFullAcceptButton"].addListener(m_listener);

	isFull.setEnable(FALSE);



	/***************************/
	/* ���� ������ �˾� ������ */
	/***************************/

	// ���� ������ Ȯ�� ��ư
	mainDisconnected.add("button", "disconnectedAcceptButton", 476, 423, 72, 42, 0, 1024-42, "image/lError.bmp");
	mainDisconnected.getButton("disconnectedAcceptButton").setImageFlag(REV_NORMAL|REV_ROLLOVER);
	mainDisconnected["disconnectedAcceptButton"].addListener(m_listener);

	mainDisconnected.setEnable(FALSE);



	/***************************/
	/* ������ �˾� ������ */
	/***************************/

	// ������ Ȯ�� ��ư
	onPlay.add("button", "onPlayAcceptButton", 476, 423, 72, 42, 0, 1024-42, "image/lError.bmp");
	onPlay.getButton("onPlayAcceptButton").setImageFlag(REV_NORMAL|REV_ROLLOVER);
	onPlay["onPlayAcceptButton"].addListener(m_listener);

	onPlay.setEnable(FALSE);



	/******************/
	/* �׸� ��� ���� */
	/******************/

	// �̹��� ���� ����
	manager.getUIDraw(0)->setFileName("image/lBackground.bmp"); // �����
	manager.getUIDraw(1)->setFileName("image/lButtons.bmp"); // �� �⺻
	manager.getUIDraw(2)->setFileName("image/lButtons.bmp"); // �� ����� �˾�
	manager.getUIDraw(3)->setFileName("image/lButtons.bmp"); // �н����� �˾�
	manager.getUIDraw(4)->setFileName("image/lButtons.bmp"); // ������ �˾�
	manager.getUIDraw(5)->setFileName("image/lError.bmp"); // �������� �ʴ� �� �˾�
	manager.getUIDraw(6)->setFileName("image/lError.bmp"); // �ο��ʰ� �˾�
	manager.getUIDraw(7)->setFileName("image/lError.bmp"); // ���� ������ �˾�
	manager.getUIDraw(8)->setFileName("image/lError.bmp"); // ������ �˾�
	manager.getUIDraw(9)->setFileName("image/endscreen.bmp"); // ����ȭ��


	// �� �Ʒ�
	CDrawManager::getInstance()->insertObject(DRAW_OBJECT_INTERFACE, (IDrawObject*)manager.getUIDraw(0));
	CDrawManager::getInstance()->insertObject(DRAW_OBJECT_INTERFACE, (IDrawObject*)manager.getUIDraw(1));
	CDrawManager::getInstance()->insertObject(DRAW_OBJECT_INTERFACE, (IDrawObject*)manager.getUIDraw(2));
	CDrawManager::getInstance()->insertObject(DRAW_OBJECT_INTERFACE, (IDrawObject*)manager.getUIDraw(3));
	CDrawManager::getInstance()->insertObject(DRAW_OBJECT_INTERFACE, (IDrawObject*)manager.getUIDraw(4));
	CDrawManager::getInstance()->insertObject(DRAW_OBJECT_INTERFACE, (IDrawObject*)manager.getUIDraw(5));
	CDrawManager::getInstance()->insertObject(DRAW_OBJECT_INTERFACE, (IDrawObject*)manager.getUIDraw(6));
	CDrawManager::getInstance()->insertObject(DRAW_OBJECT_INTERFACE, (IDrawObject*)manager.getUIDraw(7));
	CDrawManager::getInstance()->insertObject(DRAW_OBJECT_INTERFACE, (IDrawObject*)manager.getUIDraw(8));
	CDrawManager::getInstance()->insertObject(DRAW_OBJECT_INTERFACE, (IDrawObject*)manager.getUIDraw(9));
	// �� ����

	Packet packet(REQ_NEXT_ROOMLIST);
	packet << CUserManager::getInstance()->getMyUserName() << getNowPage();
	CMessageManager::getInstance()->sendMessageToMainServer(packet);

	return true;
}

void CLobbyState::release()
{
	getSoundManager()->stop("�κ�");

	delete m_listener;
	CUIManager& manager = CUIManager::getInstance();

	CDrawManager::getInstance()->eraseObject(DRAW_OBJECT_INTERFACE, manager.getUIDraw(0)->getOrder());
	CDrawManager::getInstance()->eraseObject(DRAW_OBJECT_INTERFACE, manager.getUIDraw(1)->getOrder());
	CDrawManager::getInstance()->eraseObject(DRAW_OBJECT_INTERFACE, manager.getUIDraw(2)->getOrder());
	CDrawManager::getInstance()->eraseObject(DRAW_OBJECT_INTERFACE, manager.getUIDraw(3)->getOrder());
	CDrawManager::getInstance()->eraseObject(DRAW_OBJECT_INTERFACE, manager.getUIDraw(4)->getOrder());
	CDrawManager::getInstance()->eraseObject(DRAW_OBJECT_INTERFACE, manager.getUIDraw(5)->getOrder());
	CDrawManager::getInstance()->eraseObject(DRAW_OBJECT_INTERFACE, manager.getUIDraw(6)->getOrder());
	CDrawManager::getInstance()->eraseObject(DRAW_OBJECT_INTERFACE, manager.getUIDraw(7)->getOrder());
	CDrawManager::getInstance()->eraseObject(DRAW_OBJECT_INTERFACE, manager.getUIDraw(8)->getOrder());
	CDrawManager::getInstance()->eraseObject(DRAW_OBJECT_INTERFACE, manager.getUIDraw(9)->getOrder());

	CDrawManager::getInstance()->eraseList();

	//{{ bakky : �κ񿡼� ����� �����̳� �޸� ����
	CUIManager::getInstance().destroyAllContainer();
	//}}

	return;
}

void	CLobbyState::onKeyboard(WPARAM _wParam)
{
	if( _wParam == VK_RETURN )
	{
		CUIManager::getInstance().on_Enter_KeyDown();
	}

	return;
}

void	CLobbyState::processMouseMove()
{
	return;
}


void	CLobbyState::onUpdate()
{

	if( m_lastTime+10000 < GetTickCount() )
	{
		Packet packet(REQ_NEXT_ROOMLIST);
		packet << CUserManager::getInstance()->getMyUserName() << getNowPage();
		CMessageManager::getInstance()->sendMessageToMainServer(packet);
		m_lastTime = GetTickCount();
	}

	return;
}

void	CLobbyState::setRoom1(int _whatRoom, int _roomNo, char* _roomName, int _roomState, char* _password, int _mapNo)
{
	m_roomNO[_whatRoom] = _roomNo;
	m_roomState[_whatRoom] = _roomState;
	
	CUIDialogbox& room_name = CUIManager::getInstance()["lobbyContainer"].getDialogBox("room_name1");

	CUIImageBox& UImap = CUIManager::getInstance()["lobbyContainer"].getImageBox("room1_map");
	CUIImageBox& UImapname = CUIManager::getInstance()["lobbyContainer"].getImageBox("room1_mapName");
	CUIImageBox& UImapType = CUIManager::getInstance()["lobbyContainer"].getImageBox("room1_mapType");

	CUIImageBox& UIRoomStateWait = CUIManager::getInstance()["lobbyContainer"].getImageBox("room1_state_wait");
	CUIImageBox& UIRoomStateOnPlay = CUIManager::getInstance()["lobbyContainer"].getImageBox("room1_state_onPlay");
	CUIImageBox& UIRoomStateFull = CUIManager::getInstance()["lobbyContainer"].getImageBox("room1_state_full");

	CUIImageBox& UIRoomPWis = CUIManager::getInstance()["lobbyContainer"].getImageBox("room1_pwIs");
	CUIImageBox& UIRoomPWnot = CUIManager::getInstance()["lobbyContainer"].getImageBox("room1_pwNot");

	if(m_roomNO[_whatRoom])
	{
		room_name.reset();
		room_name.insertString(_roomName);

		switch(_roomState)
		{
		case ROOM_STATE_WAIT:
			UIRoomStateWait.visible = TRUE;
			UIRoomStateOnPlay.visible = FALSE;
			UIRoomStateFull.visible = FALSE;
			break;
		case ROOM_STATE_ONPLAY:
			UIRoomStateWait.visible = FALSE;
			UIRoomStateOnPlay.visible = TRUE;
			UIRoomStateFull.visible = FALSE;
			break;
		case ROOM_STATE_FULL:
			UIRoomStateWait.visible = FALSE;
			UIRoomStateOnPlay.visible = FALSE;
			UIRoomStateFull.visible = TRUE;
			break;
		}

		switch(_mapNo)
		{
		case DONG_NE:
			UImap.visible = TRUE;
			UImapname.visible = TRUE;
			UImapType.visible = TRUE;
			break;
		default:
			UImap.visible = FALSE;
			UImapname.visible = FALSE;
			UImapType.visible = FALSE;
			break;
		}

		if ( !strcmp(_password, "") )
		{
			UIRoomPWis.visible = FALSE;
			UIRoomPWnot.visible = TRUE;
		}
		else
		{
			UIRoomPWis.visible = TRUE;
			UIRoomPWnot.visible = FALSE;
		}
	}
	else
	{
		room_name.reset();

		UIRoomStateWait.visible = FALSE;
		UIRoomStateOnPlay.visible = FALSE;
		UIRoomStateFull.visible = FALSE;

		UImap.visible = FALSE;
		UImapname.visible = FALSE;
		UImapType.visible = FALSE;

		UIRoomPWis.visible = FALSE;
		UIRoomPWnot.visible = FALSE;
	}
}


void	CLobbyState::setRoom2(int _whatRoom, int _roomNo, char* _roomName, int _roomState, char* _password, int _mapNo)
{
	m_roomNO[_whatRoom] = _roomNo;
	m_roomState[_whatRoom] = _roomState;

	CUIDialogbox& room_name = CUIManager::getInstance()["lobbyContainer"].getDialogBox("room_name2");

	CUIImageBox& UImap = CUIManager::getInstance()["lobbyContainer"].getImageBox("room2_map");
	CUIImageBox& UImapname = CUIManager::getInstance()["lobbyContainer"].getImageBox("room2_mapName");
	CUIImageBox& UImapType = CUIManager::getInstance()["lobbyContainer"].getImageBox("room2_mapType");

	CUIImageBox& UIRoomStateWait = CUIManager::getInstance()["lobbyContainer"].getImageBox("room2_state_wait");
	CUIImageBox& UIRoomStateOnPlay = CUIManager::getInstance()["lobbyContainer"].getImageBox("room2_state_onPlay");
	CUIImageBox& UIRoomStateFull = CUIManager::getInstance()["lobbyContainer"].getImageBox("room2_state_full");

	CUIImageBox& UIRoomPWis = CUIManager::getInstance()["lobbyContainer"].getImageBox("room2_pwIs");
	CUIImageBox& UIRoomPWnot = CUIManager::getInstance()["lobbyContainer"].getImageBox("room2_pwNot");

	if(m_roomNO[_whatRoom])
	{
		room_name.reset();
		room_name.insertString(_roomName);

		switch(_roomState)
		{
		case ROOM_STATE_WAIT:
			UIRoomStateWait.visible = TRUE;
			UIRoomStateOnPlay.visible = FALSE;
			UIRoomStateFull.visible = FALSE;
			break;
		case ROOM_STATE_ONPLAY:
			UIRoomStateWait.visible = FALSE;
			UIRoomStateOnPlay.visible = TRUE;
			UIRoomStateFull.visible = FALSE;
			break;
		case ROOM_STATE_FULL:
			UIRoomStateWait.visible = FALSE;
			UIRoomStateOnPlay.visible = FALSE;
			UIRoomStateFull.visible = TRUE;
			break;
		}

		switch(_mapNo)
		{
		case DONG_NE:
			UImap.visible = TRUE;
			UImapname.visible = TRUE;
			UImapType.visible = TRUE;
			break;
		default:
			UImap.visible = FALSE;
			UImapname.visible = FALSE;
			UImapType.visible = FALSE;
			break;
		}

		if ( !strcmp(_password, "") )
		{
			UIRoomPWis.visible = FALSE;
			UIRoomPWnot.visible = TRUE;
		}
		else
		{
			UIRoomPWis.visible = TRUE;
			UIRoomPWnot.visible = FALSE;
		}
	}
	else
	{
		room_name.reset();

		UIRoomStateWait.visible = FALSE;
		UIRoomStateOnPlay.visible = FALSE;
		UIRoomStateFull.visible = FALSE;

		UImap.visible = FALSE;
		UImapname.visible = FALSE;
		UImapType.visible = FALSE;

		UIRoomPWis.visible = FALSE;
		UIRoomPWnot.visible = FALSE;
	}
}

void	CLobbyState::setRoom3(int _whatRoom, int _roomNo, char* _roomName, int _roomState, char* _password, int _mapNo)
{
	m_roomNO[_whatRoom] = _roomNo;
	m_roomState[_whatRoom] = _roomState;

	CUIDialogbox& room_name = CUIManager::getInstance()["lobbyContainer"].getDialogBox("room_name3");

	CUIImageBox& UImap = CUIManager::getInstance()["lobbyContainer"].getImageBox("room3_map");
	CUIImageBox& UImapname = CUIManager::getInstance()["lobbyContainer"].getImageBox("room3_mapName");
	CUIImageBox& UImapType = CUIManager::getInstance()["lobbyContainer"].getImageBox("room3_mapType");

	CUIImageBox& UIRoomStateWait = CUIManager::getInstance()["lobbyContainer"].getImageBox("room3_state_wait");
	CUIImageBox& UIRoomStateOnPlay = CUIManager::getInstance()["lobbyContainer"].getImageBox("room3_state_onPlay");
	CUIImageBox& UIRoomStateFull = CUIManager::getInstance()["lobbyContainer"].getImageBox("room3_state_full");

	CUIImageBox& UIRoomPWis = CUIManager::getInstance()["lobbyContainer"].getImageBox("room3_pwIs");
	CUIImageBox& UIRoomPWnot = CUIManager::getInstance()["lobbyContainer"].getImageBox("room3_pwNot");

	if(m_roomNO[_whatRoom])
	{
		room_name.reset();
		room_name.insertString(_roomName);

		switch(_roomState)
		{
		case ROOM_STATE_WAIT:
			UIRoomStateWait.visible = TRUE;
			UIRoomStateOnPlay.visible = FALSE;
			UIRoomStateFull.visible = FALSE;
			break;
		case ROOM_STATE_ONPLAY:
			UIRoomStateWait.visible = FALSE;
			UIRoomStateOnPlay.visible = TRUE;
			UIRoomStateFull.visible = FALSE;
			break;
		case ROOM_STATE_FULL:
			UIRoomStateWait.visible = FALSE;
			UIRoomStateOnPlay.visible = FALSE;
			UIRoomStateFull.visible = TRUE;
			break;
		}

		switch(_mapNo)
		{
		case DONG_NE:
			UImap.visible = TRUE;
			UImapname.visible = TRUE;
			UImapType.visible = TRUE;
			break;
		default:
			UImap.visible = FALSE;
			UImapname.visible = FALSE;
			UImapType.visible = FALSE;
			break;
		}

		if ( !strcmp(_password, "") )
		{
			UIRoomPWis.visible = FALSE;
			UIRoomPWnot.visible = TRUE;
		}
		else
		{
			UIRoomPWis.visible = TRUE;
			UIRoomPWnot.visible = FALSE;
		}
	}
	else
	{
		room_name.reset();

		UIRoomStateWait.visible = FALSE;
		UIRoomStateOnPlay.visible = FALSE;
		UIRoomStateFull.visible = FALSE;

		UImap.visible = FALSE;
		UImapname.visible = FALSE;
		UImapType.visible = FALSE;

		UIRoomPWis.visible = FALSE;
		UIRoomPWnot.visible = FALSE;
	}
}

void	CLobbyState::setRoom4(int _whatRoom, int _roomNo, char* _roomName, int _roomState, char* _password, int _mapNo)
{
	m_roomNO[_whatRoom] = _roomNo;
	m_roomState[_whatRoom] = _roomState;

	CUIDialogbox& room_name = CUIManager::getInstance()["lobbyContainer"].getDialogBox("room_name4");

	CUIImageBox& UImap = CUIManager::getInstance()["lobbyContainer"].getImageBox("room4_map");
	CUIImageBox& UImapname = CUIManager::getInstance()["lobbyContainer"].getImageBox("room4_mapName");
	CUIImageBox& UImapType = CUIManager::getInstance()["lobbyContainer"].getImageBox("room4_mapType");

	CUIImageBox& UIRoomStateWait = CUIManager::getInstance()["lobbyContainer"].getImageBox("room4_state_wait");
	CUIImageBox& UIRoomStateOnPlay = CUIManager::getInstance()["lobbyContainer"].getImageBox("room4_state_onPlay");
	CUIImageBox& UIRoomStateFull = CUIManager::getInstance()["lobbyContainer"].getImageBox("room4_state_full");

	CUIImageBox& UIRoomPWis = CUIManager::getInstance()["lobbyContainer"].getImageBox("room4_pwIs");
	CUIImageBox& UIRoomPWnot = CUIManager::getInstance()["lobbyContainer"].getImageBox("room4_pwNot");

	if(m_roomNO[_whatRoom])
	{
		room_name.reset();
		room_name.insertString(_roomName);

		switch(_roomState)
		{
		case ROOM_STATE_WAIT:
			UIRoomStateWait.visible = TRUE;
			UIRoomStateOnPlay.visible = FALSE;
			UIRoomStateFull.visible = FALSE;
			break;
		case ROOM_STATE_ONPLAY:
			UIRoomStateWait.visible = FALSE;
			UIRoomStateOnPlay.visible = TRUE;
			UIRoomStateFull.visible = FALSE;
			break;
		case ROOM_STATE_FULL:
			UIRoomStateWait.visible = FALSE;
			UIRoomStateOnPlay.visible = FALSE;
			UIRoomStateFull.visible = TRUE;
			break;
		}

		switch(_mapNo)
		{
		case DONG_NE:
			UImap.visible = TRUE;
			UImapname.visible = TRUE;
			UImapType.visible = TRUE;
			break;
		default:
			UImap.visible = FALSE;
			UImapname.visible = FALSE;
			UImapType.visible = FALSE;
			break;
		}

		if ( !strcmp(_password, "") )
		{
			UIRoomPWis.visible = FALSE;
			UIRoomPWnot.visible = TRUE;
		}
		else
		{
			UIRoomPWis.visible = TRUE;
			UIRoomPWnot.visible = FALSE;
		}
	}
	else
	{
		room_name.reset();

		UIRoomStateWait.visible = FALSE;
		UIRoomStateOnPlay.visible = FALSE;
		UIRoomStateFull.visible = FALSE;

		UImap.visible = FALSE;
		UImapname.visible = FALSE;
		UImapType.visible = FALSE;

		UIRoomPWis.visible = FALSE;
		UIRoomPWnot.visible = FALSE;
	}
}

void CLobbyState::popUpNotExist()
{
	CUIManager::getInstance()["lobbyContainer"].setEnable(FALSE);
	CUIManager::getInstance()["notExist"].setEnable(TRUE);
}

void CLobbyState::popUpIsFull()
{
	CUIManager::getInstance()["lobbyContainer"].setEnable(FALSE);
	CUIManager::getInstance()["isFull"].setEnable(TRUE);
}

void CLobbyState::popUpOnPlay()
{
	CUIManager::getInstance()["lobbyContainer"].setEnable(FALSE);
	CUIManager::getInstance()["onPlay"].setEnable(TRUE);
}

void CLobbyState::disconnected()
{
	CUIManager::getInstance()["lobbyContainer"].setEnable(FALSE);
	CUIManager::getInstance()["makeRoomPopUp"].setEnable(FALSE);
	CUIManager::getInstance()["inputPWPopUp"].setEnable(FALSE);
	CUIManager::getInstance()["exitPopUp"].setEnable(FALSE);
	CUIManager::getInstance()["notExist"].setEnable(FALSE);
	CUIManager::getInstance()["isFull"].setEnable(FALSE);
	CUIManager::getInstance()["onPlay"].setEnable(FALSE);
	CUIManager::getInstance()["mainDisconnected"].setEnable(TRUE);
}
