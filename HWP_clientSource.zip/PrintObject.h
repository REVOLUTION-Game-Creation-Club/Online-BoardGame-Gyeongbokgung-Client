#ifndef __PrintObject_h__
#define __PrintObject_h__
#include "IDrawObject.h"

class CPrintObject : public IDrawObject{
protected:
	LPD3DXFONT			m_font;
	D3DXCOLOR			m_color;
	RECT				m_rect;
	int					m_fontSize;
	char				m_string[128];
	bool				m_visible;

public:
	CPrintObject();
	CPrintObject(int _x, int _y, char* _str);
	CPrintObject(int _x, int _y, int _size, char* _str);
	virtual ~CPrintObject();
	
	void			setString(char* _str){ strcpy_s(m_string,_str); }
	char*			getString(){ return m_string; }

	void			setSize(int _size){ m_fontSize = _size;}
	int				getSize(){ return m_fontSize; }

	void			setColor(float _r, float _g, float _b, float _a){ m_color = D3DXCOLOR( _r, _g, _b, _a ); }
	D3DCOLOR		getColor(){ return m_color; }

	void			setVisible(int _visible){ m_visible = _visible;}
	int				isVisible(){ return m_visible; }

	virtual bool	initialize(IDirect3DDevice9* const _device);
	virtual void	release();

	void			setPosition(int _x, int _y);

	virtual void	draw(DWORD _timeDelta);
};

#endif