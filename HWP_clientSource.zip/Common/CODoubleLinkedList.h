#ifndef _CODOUBLE_LINKEDLIST_H_
#define _CODOUBLE_LINKEDLIST_H_

#include <windows.h>

//Double Linked List Node
class CNODE{
public:
	CNODE() { next = NULL; pre = NULL; color = 0; }

	char* data;
	BYTE  color;
	CNODE* next;
	CNODE* pre;
};

//Double Lineked List 
class CNODE_LIST{
public:
	CNODE_LIST();
	~CNODE_LIST();
	BOOL AddTail(BYTE byColor, char* data);
//	BOOL Insert(int S,int data);
//	BOOL ConsolePrint();
	BOOL DeleteTail();
	BOOL DeleteFirst();
	BOOL DeleteAll();
	CNODE* first;
	CNODE* tail;
	int nData;
// Data Number
};

#endif