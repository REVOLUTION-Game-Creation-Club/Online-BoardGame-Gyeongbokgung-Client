#include "stdafx.h"
#include "PlayState.h"
#include "UserManager.h"
#include "DrawManager.h"
#include "UI/CUIManager.h"
#include "Map.h"
#include "Rullet.h"
#include "FPS.h"
#include "MessageManager.h"


class ActionListener : public Clistener
{
	CPlayState*	m_pPlayState;

public :
	ActionListener( CPlayState* pPlayState ) : m_pPlayState( pPlayState ) {}

	void action()
	{
		//{{ bakky : ���� ����Ǹ� ä���� ������ ��� �Է��� ���´�.
		if( m_pPlayState->isGameEnd() )
			return;
		//}} 
		
		if( getEvented().compare("button2") == 0)
			exit(0);
		if( getEvented().compare("characterchange") == 0)
		{
			if(!CUserManager::getInstance()->isMyTurn())
				return;
			if(CUserManager::getInstance()->getMyUser()->getSelectCharacter()->getCharacterState() != CHARACTER_STATE_WAIT)
				return;

			Packet packet(REQ_CHARACTER_CHANGE);
			CMessageManager::getInstance()->sendMessageToClientServer(packet);
		}
		if( getEvented().compare("itembutton") == 0 )
		{
			if(!CUserManager::getInstance()->isMyTurn())
				return;

			if(CUserManager::getInstance()->getMyUser()->getSelectCharacter()->getCharacterState() != CHARACTER_STATE_WAIT)
				return;

			CUserManager::getInstance()->getNowTurnUser()->getSelectCharacter()->clickItem();
		}

		// �귿 ���� Ŭ������ ��
		char selectName[6][128] = {"select-1","select0","select1","select2","select3","select4"};
		int selectNumber[6] = {-1,0,1,2,3,4};

		for(int i = 0; i<6; i++)
		{
			if( getEvented().compare(selectName[i]) == 0 )
			{
				// �ڱ� ���� �ƴϸ� ����
				if(!CUserManager::getInstance()->isMyTurn())
					return;
			
				CUser* myUser = CUserManager::getInstance()->getMyUser();

				// �ڱ� ĳ���� ���°� WAIT�� �ƴϸ� ����
				if(myUser->getSelectCharacter()->getCharacterState() != CHARACTER_STATE_WAIT)
					return;
				
				// �귵 ���� Ŭ�� �ߺ��� ���� ���ؼ� �÷��׸� ����
				if(myUser->getStartRulletFlag() == false)
				{
					myUser->setRulletClickFlag(true);
					myUser->setStartRulletFlag(true);

					// ���� �̵��� ���� skipPrev�� fals	e��
//					CCharacter* nowTurnCharacter = CUserManager::getInstance()->getNowTurnUser()->getSelectCharacter();
					myUser->getSelectCharacter()->setScrollAvailable(false);
					Packet sendPacket(REQ_RULLET_START);
					sendPacket << (i-1);
					CMessageManager::getInstance()->sendMessageToClientServer(sendPacket);
				}
			}
		}

		if( getEvented().compare("mapclick") == 0)
		{
			//{{ bakky
			// ���� ĳ���Ͱ� �̵� �����̸� ��ũ���� �ȵǰ� �Ѵ�.
			CUser*		pTurnUser = CUserManager::getInstance()->getNowTurnUser();
			if( !pTurnUser )
				return;

			CCharacter* pTurnChar = pTurnUser->getSelectCharacter();
			if( !pTurnChar )
				return;


			if( !(pTurnChar->getCharacterState() == CHARACTER_STATE_WAIT 
				|| pTurnChar->getCharacterState() == CHARACTER_STATE_WATERBALL) )
				return;
			//}}

			CUIButton& mapbutton = CUIManager::getInstance()["minimap"].getButton("mapclick");

			POINT clicked;

			clicked.x = mapbutton.mouseClicked_x * 10 - 512;
			clicked.y = mapbutton.mouseClicked_y * 10 - 384;

			if( clicked.x < 0 )
				clicked.x = 0;
			else if( clicked.x > BG_WIDTH - 1024 )
				clicked.x = BG_WIDTH - 1024;

			if( clicked.y < 0 )
				clicked.y = 0;
			else if( clicked.y > BG_HEIGHT - 768)
				clicked.y = BG_HEIGHT - 768;

			CPlayState* playState = (CPlayState*)CGameManager::getInstance()->getState(GAME_STATE_PLAY);
			playState->getMap()->setScreenPoint(clicked);
		}
		if( getEvented().compare("rest") == 0 )
		{
			// ��ŵ��ư�� ������ ���� �� ������ �ڽ��̰�
			// ���� �� ������ WAIT�����̸� �����Ѵ�. 
			CUserManager* userManager = CUserManager::getInstance();
			if(!userManager->isMyTurn())
				return;

			CUser* myUser = userManager->getMyUser();
			CCharacter* character = myUser->getSelectCharacter();

			if(character->getCharacterState() != CHARACTER_STATE_WAIT)
				return;
			// ��ŵ ��ư�� Ŭ���ϸ� ���忡�� ���� ID�� �ѱ��.
			// ������ ��ŵ ��Ŷ�� ������ 
			// ��ŵ �޼����� �����鿡�� ������
			// �װ��� ���� Ŭ���̾�Ʈ���� ���� ID ������ ���õ� ĳ������ ��ŵ �÷��׸� �����ϰ�
			// ���� Ŭ���̾�Ʈ�鿡�� ACK_TURN_OUT ��Ŷ�� ������.
			// Ŭ���̾�Ʈ�� �� ������ ���� �ѱ��.

			//  ��ŵ��ư�� �ߺ� Ŭ���� ���´�.
			if(!myUser->isSkipClickFlag())
			{
				myUser->setSkipClickFlag(false);
				Packet packet(REQ_TURN_SKIP);
				packet << character->getUserId();
				CMessageManager::getInstance()->sendMessageToClientServer(packet);
			}
		}
	}

	void textChanged()
	{
		getIME()->setPos(0, -20);
		CUIManager::getInstance()["container2"].getTextBox("Playchat").changeString(getIME()->GetStr());
	}

	void pressReturn() 
	{	
			static BOOL bChatable = FALSE;

			// enter -> send chat message & bChatable = false & ��Ȱ��ȭ
			if( bChatable )
			{
				CTextBox& chat = CUIManager::getInstance()["container2"].getTextBox("Playchat");		

				if( !this->m_pPlayState->cheatOrder( chat.getString() ) )
				{
					Packet packet(REQ_GAME_CHAT);
					packet << CUserManager::getInstance()->getMyUser()->getName() << chat.getString();
					CMessageManager::getInstance()->sendMessageToClientServer(packet);
				}
				

				getIME()->ClearBufstr();

				CUIManager::getInstance()["container2"].getImageBox( "chatInvisible" ).setVisible( true );
				CUIManager::getInstance().setActiveTextbox(NULL);

				bChatable = FALSE;
			}
			// �Է� ������ ���·� �����
			else
			{
				CUIManager::getInstance()["container2"].getImageBox( "chatInvisible" ).setVisible( false );

				CTextBox& chat = CUIManager::getInstance()["container2"].getTextBox("Playchat");		
				CUIManager::getInstance().setActiveTextbox(&chat);

				bChatable = TRUE;
			}

	}
};


CPlayState::CPlayState(CGameManager* _gameManager)
{
	this->m_gameManager = _gameManager;

	m_map			= NULL;
	m_rullet		= NULL;
	m_fps			= NULL;
	m_effect		= NULL;
//	m_completeNum   = NULL;
	m_message		= NULL;
//	m_fighterImage1	= NULL;
	m_dwGameEndTime = 0;

	for( int i=0 ; i<4 ; i++ )
	{
		m_completeNum[i] = NULL;
		m_printLevelChar[i] = NULL;
	}
}

CPlayState::~CPlayState()
{
}

bool CPlayState::initialize()
{
	//{{ bakky
	// ���� ���� �÷���.. �ʱ�ȭ�� false
	m_bGameEnd = FALSE;
	//}}

	//game UI init
	m_listener = new ActionListener( this );	

	CUIManager& UIManager = CUIManager::getInstance();
	UIManager.makeContainer("container1", 61, 11, 213, 118, 0, 140, "image/UserInfo.bmp" );

	CUIContainer& container1 = UIManager["container1"];
	container1.add("imagebox", "characterface", 1, 9, 140, 140, 0, 0, "image/UserInfo.bmp" );	
	container1["characterface"].setImageFlag(3);	
	container1.add("imagebox", "itemslot", 133, 69, 42, 40, 0, 258,"image/UserInfo.bmp" );	
	container1["itemslot"].setImageFlag(8);
	container1.add("button", "itembutton", 133, 69, 42, 40, 0, 800,"image/UserInfo.bmp" );	
	container1["itembutton"].addListener(m_listener);	

	container1.add("imagebox", "level&exp", 178, 59, 50, 50, 0, 298,"image/UserInfo.bmp" );	
	container1.add("imagebox", "team1", 50, 151, 45, 45, 0, 348,"image/UserInfo.bmp" );
	container1["team1"].setImageFlag(4);	
	container1.add("imagebox", "team2", 100, 151, 45, 45, 0, 348,"image/UserInfo.bmp" );
	container1["team2"].setImageFlag(4);	
	container1.add("imagebox", "team3", 150, 151, 45, 45, 0, 348,"image/UserInfo.bmp" );
	container1["team3"].setImageFlag(4);	
	container1.add("imagebox", "team4", 200, 151, 45, 45, 0, 348,"image/UserInfo.bmp" );
	container1["team4"].setImageFlag(4);	

	// team face setting
	container1.add("imagebox", "teamface1", 50, 151, 45, 45, 180, 348, "image/UserInfo.bmp" );
	container1["teamface1"].setImageFlag( REV_NORMAL | REV_ROLLOVER | REV_PRESSED );	
	container1.add("imagebox", "teamface2", 100, 151, 45, 45, 180, 348, "image/UserInfo.bmp" );
	container1["teamface2"].setImageFlag( REV_NORMAL | REV_ROLLOVER | REV_PRESSED );	
	container1.add("imagebox", "teamface3", 150, 151, 45, 45, 180, 348, "image/UserInfo.bmp" );
	container1["teamface3"].setImageFlag( REV_NORMAL | REV_ROLLOVER | REV_PRESSED );	
	container1.add("imagebox", "teamface4", 200, 151, 45, 45, 180, 348, "image/UserInfo.bmp" );
	container1["teamface4"].setImageFlag( REV_NORMAL | REV_ROLLOVER | REV_PRESSED );	


	container1.add("dialogbox", "username", 150, 43, 0,0,0,0, "");
	container1.add("button", "characterchange", 127, 2, 30, 30, 0, 438, "image/UserInfo.bmp");

	container1["characterchange"].setImageFlag(REV_NORMAL | REV_ROLLOVER );
	container1["characterchange"].addListener(m_listener);
	CUIDialogbox& username = container1.getDialogBox("username");
	username.setFontPosition(65, 10);
	username.setFontColor(255,255,255,100);
	username.setFontSize(10);
	username.setLineSpace(7);
	username.setRange(5);
	username.insertString("");
	container1.add("dialogbox", "level", 235, 65, 0,0,0,0, "");
	CUIDialogbox& level = container1.getDialogBox("level");
	level.setFontPosition(65, 10);
	level.setFontColor(255,255,255,100);
	level.setFontSize(10);
	level.setLineSpace(7);
	level.setRange(5);
	level.insertString("");
	container1.add("dialogbox", "exp", 220, 85, 0,0,0,0, "");
	CUIDialogbox& exp = container1.getDialogBox("exp");
	exp.setFontPosition(65, 10);
	exp.setFontColor(255,255,255,100);
	exp.setFontSize(10);
	exp.setLineSpace(7);
	exp.setRange(5);
	exp.insertString("");


	UIManager.makeContainer("container2", 0, 516, 1024, 252, 0, 772, "image/rullet.bmp" );
	CUIContainer& container2 = UIManager["container2"];

	container2.add("button","rest", 36, 722, 105, 34, 0, 619, "image/rullet.bmp" );
	container2["rest"].setImageFlag( REV_NORMAL | REV_ROLLOVER );
	container2["rest"].addListener(m_listener);

	container2.add("dialogbox","chatlist", 318, 593, 425, 94, 0, 678, "image/rullet.bmp" );

	CUIDialogbox& chatlist = container2.getDialogBox("chatlist");
	chatlist.setFontPosition(10, 10);
	chatlist.setFontColor(255,255,255,100);
	chatlist.setFontSize(8);
	chatlist.setLineSpace(7);
	chatlist.setRange(5);	
	chatlist.setMaxString( 5 );

	container2.add("textbox","Playchat", 323, 712, 414, 25, 0, 653, "image/rullet.bmp" );
	container2.getTextBox("Playchat").setFontColor(255,255,255,100);
	container2.getTextBox("Playchat").setFontSize(8);
	container2.getTextBox("Playchat").setFontPosition(5, 5);
	container2.getTextBox("Playchat").addListener(m_listener);


	//{{ bakky 
	container2.add( "imagebox", "chatInvisible", 327, 716, 406, 16, 566, 673, "image/rullet.bmp" );
	container2.getImageBox( "chatInvisible" ).setVisible( true );
	//}}

	CTextBox& chat = container2.getTextBox("Playchat");
	CUIManager::getInstance().setActiveTextbox(NULL);

	char selectName[6][128] = {"select-1","select0","select1","select2","select3","select4"};
	POINT selectPos[6] = {{822,698},{774,616},{822,530},{920,529},{969,615},{922,698}};
	POINT selectTex[6] = {{759,238},{759,293},{759,348},{759,403},{759,458},{759,513}};

	for(int i = 0; i<6; i++)
	{
		container2.add("button", selectName[i], selectPos[i].x, selectPos[i].y, 45, 55, selectTex[i].x, selectTex[i].y, "image/rullet.bmp" );
		container2[selectName[i]].setImageFlag( REV_NORMAL | REV_ROLLOVER);
		container2[selectName[i]].addListener(m_listener);
	}

	UIManager.makeContainer("minimap", 36, 554, 200, 150, 0, 0, "image/minimap.png" );
	CUIContainer& minimap = UIManager["minimap"];	

	minimap.add("imagebox", "userpoint11", 36, 554, 5, 5, 0, 150, "image/minimap.png");
	minimap.add("imagebox", "userpoint12", 36, 554, 5, 5, 0, 150, "image/minimap.png");
	minimap.add("imagebox", "userpoint21", 36, 554, 5, 5, 0, 150, "image/minimap.png");
	minimap.add("imagebox", "userpoint22", 36, 554, 5, 5, 0, 150, "image/minimap.png");
	minimap.add("imagebox", "userpoint31", 36, 554, 5, 5, 0, 150, "image/minimap.png");
	minimap.add("imagebox", "userpoint32", 36, 554, 5, 5, 0, 150, "image/minimap.png");
	minimap.add("imagebox", "userpoint41", 36, 554, 5, 5, 0, 150, "image/minimap.png");
	minimap.add("imagebox", "userpoint42", 36, 554, 5, 5, 0, 150, "image/minimap.png");
	for (int i = 0 ; i < 8 ; i++ )
		minimap[i].setImageFlag(4);

	minimap.add("imagebox", "screen", 36, 554, 102, 76, 0, 155, "image/minimap.png");
	minimap.add("button", "mapclick", 36, 554, 200, 150, 0, 231, "image/minimap.png");

	//{{ bakky
	minimap.add( "imagebox", "GameEndBox", 342, 337, 340, 95, 132, 417, "image/minimap.png");
	minimap.getImageBox( "GameEndBox" ).setVisible( false );
	//}}

	minimap["mapclick"].addListener(m_listener);


	UIManager.getUIDraw(0)->setFileName("image/UserInfo.bmp");
	UIManager.getUIDraw(1)->setFileName("image/rullet.bmp");
	UIManager.getUIDraw(2)->setFileName("image/minimap.png");

	// ���� �� UI
	CUserManager* userManager = CUserManager::getInstance();
	int userNum = userManager->getUserNum();	//��� ���� �ִ��� �޾ƿɴϴ�.
	int teamcolor;

	UIManager["container1"]["team1"].tex_y += UIManager["container1"]["team1"].height;
	UIManager["container1"]["team2"].tex_y += UIManager["container1"]["team2"].height;
	UIManager["container1"]["team3"].tex_y += UIManager["container1"]["team3"].height;
	UIManager["container1"]["team4"].tex_y += UIManager["container1"]["team4"].height;
	UIManager["container1"]["teamface1"].tex_y += UIManager["container1"]["teamface1"].height;
	UIManager["container1"]["teamface2"].tex_y += UIManager["container1"]["teamface2"].height;
	UIManager["container1"]["teamface3"].tex_y += UIManager["container1"]["teamface3"].height;
	UIManager["container1"]["teamface4"].tex_y += UIManager["container1"]["teamface4"].height;	

	//�̴ϸʿ� ǥ�õǴ� �� �߿��� 2��° �ɸ��� ���ϰ����� ���������� ����
	if( userNum > 2 )
	{
		for( int i = 1 ; i < 8 ; i += 2 )
		{
			UIManager["minimap"][i].visible = false;
		}
	}

	//�� ������ ���� UIManager�� ���°� �޶����ϴ�.
	switch( userNum ) 
	{
	case 1:		//�÷��̾ 1���� ��
		//�� �ʱ�ȭ
		UIManager["container1"]["teamface1"].setImageState(userManager->getUser(0)->getCharacter(0)->getKind());

		//������ ���� ���¸� �Ⱥ��Դϴ�.
		UIManager["container1"]["team2"].visible = false;
		UIManager["container1"]["team3"].visible = false;
		UIManager["container1"]["team4"].visible = false;
		UIManager["container1"]["teamface2"].visible = false;
		UIManager["container1"]["teamface3"].visible = false;
		UIManager["container1"]["teamface4"].visible = false;

		//�̴ϸʿ� ������ ���� ������ ���� ���� ����.
		for( int i = 2; i < 8 ; i++ )
			UIManager["minimap"][i].visible = false;

		//���� ������ �ʱ�ȭ �մϴ�.
		teamcolor= userManager->getUser(0)->getTeamColor();
		UIManager["container1"]["team1"].setImageState(teamcolor);

		//�̴ϸʿ� ������ ���� ���� �ʱ�ȭ
		for( int i = 0 ; i < userNum ; i++ )
		{
			teamcolor= userManager->getUser(i)->getTeamColor();
			UIManager["minimap"][i*2].setImageState(teamcolor);
			UIManager["minimap"][i*2+1].setImageState(teamcolor);
		}

		//�Ʒ��� ������ ���� ������.

		break;
	case 2:		//�÷��̾ 2���� ��
		UIManager["container1"]["teamface1"].setImageState(userManager->getUser(0)->getCharacter(0)->getKind());
		UIManager["container1"]["teamface2"].setImageState(userManager->getUser(1)->getCharacter(0)->getKind());

		UIManager["container1"]["team3"].visible = false;
		UIManager["container1"]["team4"].visible = false;
		UIManager["container1"]["teamface3"].visible = false;
		UIManager["container1"]["teamface4"].visible = false;

		for( int i = 4; i < 8 ; i++ )
			UIManager["minimap"][i].visible = false;

		int teamcolor;
		teamcolor= userManager->getUser(0)->getTeamColor();
		UIManager["container1"]["team1"].setImageState(teamcolor);
		teamcolor= userManager->getUser(1)->getTeamColor();
		UIManager["container1"]["team2"].setImageState(teamcolor);

		//�̴ϸʿ� ������ ���� ���� �ʱ�ȭ
		for( int i = 0 ; i < userNum ; i++ )
		{
			teamcolor= userManager->getUser(i)->getTeamColor();
			UIManager["minimap"][i*2].setImageState(teamcolor);
			UIManager["minimap"][i*2+1].setImageState(teamcolor);
		}
		break;
	case 3:		//�÷��̾ 3���� ��
		UIManager["container1"]["teamface1"].setImageState(userManager->getUser(0)->getCharacter(0)->getKind());
		UIManager["container1"]["teamface2"].setImageState(userManager->getUser(1)->getCharacter(0)->getKind());
		UIManager["container1"]["teamface3"].setImageState(userManager->getUser(2)->getCharacter(0)->getKind());

		UIManager["container1"]["team4"].visible = false;
		UIManager["container1"]["teamface4"].visible = false;

		for( int i = 6; i < 8 ; i++ )
			UIManager["minimap"][i].visible = false;

		teamcolor= userManager->getUser(0)->getTeamColor();
		UIManager["container1"]["team1"].setImageState(teamcolor);
		teamcolor= userManager->getUser(1)->getTeamColor();
		UIManager["container1"]["team2"].setImageState(teamcolor);
		teamcolor= userManager->getUser(2)->getTeamColor();
		UIManager["container1"]["team3"].setImageState(teamcolor);

		//�̴ϸʿ� ������ ���� ���� �ʱ�ȭ
		for( int i = 0 ; i < userNum ; i++ )
		{
			teamcolor= userManager->getUser(i)->getTeamColor();
			UIManager["minimap"][i*2].setImageState(teamcolor);
			UIManager["minimap"][i*2+1].setImageState(teamcolor);
		}
		break;
	case 4:		//�÷��̾ 4���� ��
		UIManager["container1"]["teamface1"].setImageState(userManager->getUser(0)->getCharacter(0)->getKind());
		UIManager["container1"]["teamface2"].setImageState(userManager->getUser(1)->getCharacter(0)->getKind());
		UIManager["container1"]["teamface3"].setImageState(userManager->getUser(2)->getCharacter(0)->getKind());
		UIManager["container1"]["teamface4"].setImageState(userManager->getUser(3)->getCharacter(0)->getKind());

		teamcolor= userManager->getUser(0)->getTeamColor();
		UIManager["container1"]["team1"].setImageState(teamcolor);
		teamcolor= userManager->getUser(1)->getTeamColor();
		UIManager["container1"]["team2"].setImageState(teamcolor);
		teamcolor= userManager->getUser(2)->getTeamColor();
		UIManager["container1"]["team3"].setImageState(teamcolor);
		teamcolor= userManager->getUser(3)->getTeamColor();
		UIManager["container1"]["team4"].setImageState(teamcolor);

		//�̴ϸʿ� ������ ���� ���� �ʱ�ȭ
		for( int i = 0 ; i < userNum ; i++ )
		{
			teamcolor= userManager->getUser(i)->getTeamColor();
			UIManager["minimap"][i*2].setImageState(teamcolor);
			UIManager["minimap"][i*2+1].setImageState(teamcolor);
		}
		break;
	}


	//game init
	CDrawManager* drawManager = CDrawManager::getInstance();

	m_map = new CMap();
	m_effect = new CSpriteObject(0,0,200,200,"image/effect.bmp");
	m_effect->setVisible(false);
	m_rullet = new CRullet(775,522);
	
	/// ���� ���� ǥ��
	static const int COMPLETE_POINT[4][2] = { {55, 199}, {105, 199}, {155, 199}, {205, 199} };
	static const int LEVEL_POINT[4][2] = { {65, 135 }, { 115, 135 }, { 165, 135 }, {215, 135} };
	for( int i=0 ; i<CUserManager::getInstance()->getUserNum() ; i++ )
	{
		m_completeNum[i] = new CPrintObject(COMPLETE_POINT[i][0],COMPLETE_POINT[i][1],"0/0");
		m_completeNum[i]->setSize(13);
		m_completeNum[i]->setColor(1.0f,0.0f,0.0f,1.0f);

		m_printLevelChar[i] = new CPrintObject(LEVEL_POINT[i][0], LEVEL_POINT[i][1], "0" );
		m_printLevelChar[i]->setSize( 13 );
		m_printLevelChar[i]->setColor( 1.0f, 0.992f, 0.313f, 1.0f );
	}
	
	m_message = new CPrintObject(350,550,"�ٸ� ������ ��ٸ��� �ֽ��ϴ�.");
	m_message->setSize(10);
	m_message->setColor(0.3,0.3,0.3,1.0);
	m_fps = new CFPS();

	m_fighterImage1 = new CFightImage();
	m_fighterImage1->setVisible(false);

	//{{ bakky , �귿 ���� �̹��� �ε�
	UIManager.makeContainer("contRulletAlpha", 775, 522, 238, 238, 0, 0, "image/rullet_alpha.bmp" );
	UIManager["contRulletAlpha"].setVisible( false );

	UIManager.getUIDraw(3)->setFileName("image/rullet_alpha.bmp");
	//}}

	registerDrawObject();

	//{{ bakky
	// �ε��� �����ٰ� ���忡�� �˸���
	Packet packet(NOTIFY_LOAD_END);
	packet << CUserManager::getInstance()->getMyUserName();
	CMessageManager::getInstance()->sendMessageToClientServer( packet );
	//}}
	
	// ��!!!��!!��!! ���� 06.11.21
	//int userNum = CUserManager::getInstance()->getUserNum();
	//CUserManager* userManager = CUserManager::getInstance();
	//CUIManager& UIManager = CUIManager::getInstance();

	//int x1, y1, x2, y2, x, y;
	//for( int i = 0; i < alluser ; i++ )
	//{
	//	// �̴� ���� ��ǥ�� ���´�.
	//	int minimapX = UIManager["minimap"].x;
	//	int minimapY = UIManager["minimap"].y;

	//	// ĳ������ �߽� ��ǥ�� ���´�.

	//	int charNum = userManager->getUser(i)->getCharacterNum();

	//	if( charNum != 2 )
	//	{
	//		POINT ptChar0 = userManager->getUser(0)->
	//		x1 = minimapX + ptChar0->x / 10;	
	//		y1 = minimapY + ptChar0->y / 10;
	//	}
	//	else
	//	{
	//		x = minimapX + ptChar0->x / 10;
	//		y = minimapY + ptChar1->y / 10;
	//	}

	//}

	//{{ �� �ʱ�ȭ
	CDrawManager::getInstance()->createCastle();
	//}}


	return true;
}

void CPlayState::release()
{
	unregisterDrawObject();

	//{{ �� �ʱ�ȭ
	CDrawManager::getInstance()->releaseCastle();
	//}}

	//{{ bakky
	delete m_listener;
	m_listener = NULL;
	//}}
	delete m_effect;
	m_effect = NULL;
	delete m_fps;
	m_fps = NULL;
	delete m_rullet;
	m_rullet = NULL;
	delete m_map;
	m_map = NULL;

	// ���� ���� ǥ�� ����
	for( int i=0 ; i<4 ; i++ )
	{
		if( m_completeNum[i] )
		{
			delete m_completeNum[i];
			m_completeNum[i] = NULL;
		}

		if( m_printLevelChar[i] )
		{
			delete m_printLevelChar[i];
			m_printLevelChar[i] = NULL;
		}
	}
	
	delete m_message;
	m_message = NULL;
	delete m_fighterImage1;
	m_fighterImage1 = NULL;
}

void CPlayState::registerDrawObject()
{
	CDrawManager*	drawManager = CDrawManager::getInstance();
	CUserManager*	userManager = CUserManager::getInstance();
	CUIManager&		UIManager	= CUIManager::getInstance();

	drawManager->insertObject(DRAW_OBJECT_MAP, m_map);
	for(int i =0; i < userManager->getUserNum(); i++)
	{
		for(int j = 0; j < userManager->getUser(i)->getCharacterNum(); j++)
		{
			userManager->getUser(i)->getCharacter(j)->initCenterPoint();
			drawManager->insertObject(DRAW_OBJECT_CHARACTER, userManager->getUser(i)->getCharacter(j));
		}
	}
	drawManager->insertObject(DRAW_OBJECT_CHARACTER, m_effect);

	drawManager->insertObject(DRAW_OBJECT_INTERFACE, m_rullet);

	CDrawManager::getInstance()->insertObject(DRAW_OBJECT_INTERFACE, (IDrawObject*)UIManager.getUIDraw(0));	// User Info
	CDrawManager::getInstance()->insertObject(DRAW_OBJECT_INTERFACE, (IDrawObject*)UIManager.getUIDraw(1));	// Rullet
	CDrawManager::getInstance()->insertObject(DRAW_OBJECT_INTERFACE, (IDrawObject*)UIManager.getUIDraw(2));	// Minimap
	CDrawManager::getInstance()->insertObject(DRAW_OBJECT_INTERFACE, (IDrawObject*)UIManager.getUIDraw(3));	// �귿 ����

	drawManager->insertObject(DRAW_OBJECT_INTERFACE, m_fighterImage1);

	drawManager->insertObject(DRAW_OBJECT_INTERFACE, m_fps);
	for( int i=0 ; i<CUserManager::getInstance()->getUserNum() ; i++ )
	{
		drawManager->insertObject(DRAW_OBJECT_INTERFACE, m_completeNum[i]);
		drawManager->insertObject(DRAW_OBJECT_INTERFACE, m_printLevelChar[i] );
	}
	drawManager->insertObject(DRAW_OBJECT_INTERFACE, m_message);

}

void CPlayState::unregisterDrawObject()
{
	CDrawManager*	drawManager = CDrawManager::getInstance();
	CUserManager*	userManager = CUserManager::getInstance();
	CUIManager&		UIManager		= CUIManager::getInstance();

	drawManager->eraseObject(DRAW_OBJECT_MAP, m_map->getOrder());

	for(int i =0; i < userManager->getUserNum(); i++)
	{
		for(int j = 0; j < userManager->getUser(i)->getCharacterNum(); j++)
		{
			drawManager->eraseObject(DRAW_OBJECT_CHARACTER, userManager->getUser(i)->getCharacter(j)->getOrder());
		}
	}
	drawManager->eraseObject(DRAW_OBJECT_CHARACTER, m_effect->getOrder());
	drawManager->eraseObject(DRAW_OBJECT_INTERFACE, m_fighterImage1->getOrder());

	drawManager->eraseObject(DRAW_OBJECT_INTERFACE, m_rullet->getOrder());

	CDrawManager::getInstance()->eraseObject(DRAW_OBJECT_INTERFACE, UIManager.getUIDraw(0)->getOrder());	// User Info
	CDrawManager::getInstance()->eraseObject(DRAW_OBJECT_INTERFACE, UIManager.getUIDraw(1)->getOrder());	// Rullet
	CDrawManager::getInstance()->eraseObject(DRAW_OBJECT_INTERFACE, UIManager.getUIDraw(2)->getOrder());	// Minimap
	CDrawManager::getInstance()->eraseObject(DRAW_OBJECT_INTERFACE, UIManager.getUIDraw(3)->getOrder());	// Minimap

	drawManager->eraseObject(DRAW_OBJECT_INTERFACE, m_fps->getOrder());

	for( int i=0 ; i<CUserManager::getInstance()->getUserNum() ; i++ )
	{
		drawManager->eraseObject(DRAW_OBJECT_INTERFACE, m_completeNum[i]->getOrder());
		drawManager->eraseObject(DRAW_OBJECT_INTERFACE, m_printLevelChar[i]->getOrder() );
	}
	
	drawManager->eraseObject(DRAW_OBJECT_INTERFACE, m_message->getOrder());


	CDrawManager::getInstance()->eraseList();
	CUIManager::getInstance().destroyAllContainer();
}

void CPlayState::onKeyboard(WPARAM _wParam)
{
	if( _wParam == VK_RETURN )
		m_listener->pressReturn();

	if( _wParam == VK_SPACE )
	{
		CUserManager* userManager = CUserManager::getInstance();

		if(userManager->isMyTurn())
		{
			CPlayState* playState = (CPlayState*)CGameManager::getInstance()->getState(GAME_STATE_PLAY);

			CUser* myUser = CUserManager::getInstance()->getMyUser();

			// ĳ���� ���°� WAIT(������� �Է��� ��ٸ��� ����)�� �ƴϸ� �����Ѵ�
			if(myUser->getSelectCharacter()->getCharacterState() != CHARACTER_STATE_WAIT)
				return;

			// �����̽� �ٸ� �ߺ����� ������ ���� ����
			if((myUser->getSpacebarFlag() == false)&&(myUser->isRulletClickFlag() == true))
			{
				myUser->setRulletClickFlag(false);
				myUser->setSpacebarFlag(true);
				// �귿�� ���� ���ڸ� ��´�
				int number = playState->getRullet()->getComputeNumber();

				// �귿 ���� ��û
				Packet packet(REQ_RULLET_STOP);
				packet << number; 
				CMessageManager::getInstance()->sendMessageToClientServer(packet);
			}
		}
	}
	//else if( _wParam == 0x51 )			//	Q key
	//{
	//	Packet packet(REQ_CLIENT_CONNECT);
	//	packet << "127.0.0.1";
	//	CMessageManager::getInstance()->sendMessageToClientServer(packet);
	//}
	//else if( _wParam == 0x10 )		// SHIFT
	//{
	//	Packet packet(REQ_GAME_START);
	//	CMessageManager::getInstance()->sendMessageToClientServer(packet);
	//}
#ifdef _DEBUG
	if( _wParam == 0x11 )		// CONTROL
	{
	}
	else if( _wParam == 0x31 )
	{
		if(CUserManager::getInstance()->isMyTurn())
		{
			Packet packet(REQ_RULLET_STOP);
			packet << -1;
			CMessageManager::getInstance()->sendMessageToClientServer(packet);
		}
	}
	else if( _wParam == 0x32 )
	{
		if(CUserManager::getInstance()->isMyTurn())
		{
			Packet packet(REQ_RULLET_STOP);
			packet << 0;
			CMessageManager::getInstance()->sendMessageToClientServer(packet);
		}
	}
	else if( _wParam == 0x33 )
	{
		if(CUserManager::getInstance()->isMyTurn())
		{
			Packet packet(REQ_RULLET_STOP);
			packet << 1;
			CMessageManager::getInstance()->sendMessageToClientServer(packet);
		}
	}
	else if( _wParam == 0x34 )
	{
		if(CUserManager::getInstance()->isMyTurn())
		{
			Packet packet(REQ_RULLET_STOP);
			packet << 2;
			CMessageManager::getInstance()->sendMessageToClientServer(packet);
		}
	}
	else if( _wParam == 0x35 )
	{
		if(CUserManager::getInstance()->isMyTurn())
		{
			Packet packet(REQ_RULLET_STOP);
			packet << 3;
			CMessageManager::getInstance()->sendMessageToClientServer(packet);
		}
	}
	else if( _wParam == 0x36 )
	{
		if(CUserManager::getInstance()->isMyTurn())
		{
			Packet packet(REQ_RULLET_STOP);
			packet << 4;
			CMessageManager::getInstance()->sendMessageToClientServer(packet);
		}
	}
#endif
	//{{ bakky
	// ���� ĳ���Ͱ� �̵� �����̸� ��ũ���� �ȵǰ� �Ѵ�.
	CUser*		pTurnUser = CUserManager::getInstance()->getNowTurnUser();
	if( !pTurnUser )
		return;

	CCharacter* pTurnChar = pTurnUser->getSelectCharacter();
	if( !pTurnChar )
		return;


	if( !(pTurnChar->getCharacterState() == CHARACTER_STATE_WAIT 
		|| pTurnChar->getCharacterState() == CHARACTER_STATE_WATERBALL) )
		return;
	//}}

	POINT screenPoint = m_map->getScreenPoint();

	if( _wParam == VK_LEFT )
	{
		if(screenPoint.x >= SCROLL_MOVE_AMOUNT_X)
			screenPoint.x -= SCROLL_MOVE_AMOUNT_X;
		else
			screenPoint.x = 0;
	}

	if( _wParam == VK_RIGHT )
	{
		if(screenPoint.x <= BG_WIDTH - BGVIEW_WIDTH - SCROLL_MOVE_AMOUNT_X)
			screenPoint.x += SCROLL_MOVE_AMOUNT_X;
		else
			screenPoint.x = BG_WIDTH - BGVIEW_WIDTH;
	}

	if( _wParam == VK_UP )
	{
		if(screenPoint.y >= SCROLL_MOVE_AMOUNT_Y)
			screenPoint.y -= SCROLL_MOVE_AMOUNT_Y;
		else
			screenPoint.y = 0;
	}

	if( _wParam == VK_DOWN )
	{
		if(screenPoint.y <= BG_HEIGHT - BGVIEW_HEIGHT - SCROLL_MOVE_AMOUNT_Y)
			screenPoint.y += SCROLL_MOVE_AMOUNT_Y;
		else
			screenPoint.y = BG_HEIGHT - BGVIEW_HEIGHT;
	}
	m_map->setScreenPoint(screenPoint);
}

void CPlayState::processMouseMove()
{
	//{{ bakky
	// ���� ĳ���Ͱ� �̵� �����̸� ��ũ���� �ȵǰ� �Ѵ�.
	CUser*		pTurnUser = CUserManager::getInstance()->getNowTurnUser();
	if( !pTurnUser )
		return;

	CCharacter* pTurnChar = pTurnUser->getSelectCharacter();
	if( !pTurnChar )
		return;

	if( !(pTurnChar->getCharacterState() == CHARACTER_STATE_WAIT 
		|| pTurnChar->getCharacterState() == CHARACTER_STATE_WATERBALL) )
		return;
	//}}

	bool scrollAvailable = CUserManager::getInstance()->getNowTurnUser()->getSelectCharacter()->isScrollAvailable();

	if( scrollAvailable == false )
		return;

	CPlayState* playState = (CPlayState*)CGameManager::getInstance()->getState(GAME_STATE_PLAY);

	POINT screenPoint = playState->getMap()->getScreenPoint();
	POINT mousePoint = m_gameManager->getMousePoint();

	if(mousePoint.x < SCROLL_MOVE_MARGIN_X)
	{
		if(screenPoint.x >= SCROLL_MOVE_AMOUNT_X)
			screenPoint.x -= SCROLL_MOVE_AMOUNT_X;
		else
			screenPoint.x = 0;
	}

	if( 1024-SCROLL_MOVE_MARGIN_X < mousePoint.x)
	{
		if(screenPoint.x <= BG_WIDTH - BGVIEW_WIDTH - SCROLL_MOVE_AMOUNT_X)
			screenPoint.x += SCROLL_MOVE_AMOUNT_X;
		else
			screenPoint.x = BG_WIDTH - BGVIEW_WIDTH;
	}

	if(mousePoint.y < SCROLL_MOVE_MARGIN_Y )
	{
		if(screenPoint.y >= SCROLL_MOVE_AMOUNT_Y)
			screenPoint.y -= SCROLL_MOVE_AMOUNT_Y;
		else
			screenPoint.y = 0;
	}

	if( 768-SCROLL_MOVE_MARGIN_Y < mousePoint.y )
	{
		if(screenPoint.y <= BG_HEIGHT - BGVIEW_HEIGHT - SCROLL_MOVE_AMOUNT_Y)
			screenPoint.y += SCROLL_MOVE_AMOUNT_Y;
		else
			screenPoint.y = BG_HEIGHT - BGVIEW_HEIGHT;
	}

	playState->getMap()->setScreenPoint(screenPoint);
}


void CPlayState::onUpdate()
{
	// ĳ���� ���� ������Ʈ...
	updateLevelChar();

	//{{ bakky
	// ������ ����Ǵ� �Ŷ��....
	// ���ʵڿ� state ��ȯ
	if( isGameEnd() )
	{
		if( timeGetTime() - m_dwGameEndTime > TIME_GAME_END_MSG )
		{
			// result state�� ��ȯ
			CGameManager::getInstance()->setState( GAME_STATE_RESULT );
		}

		return;
	}
	//}}

	int alluser = CUserManager::getInstance()->getUserNum();
	CUserManager* user = CUserManager::getInstance();
	CUIManager& UI = CUIManager::getInstance();

	for( int i = 0; i < alluser ; i++ )
	{
		int minimapX = UI["minimap"].x;
		int minimapY = UI["minimap"].y;

		CCharacter* pChar = user->getUser(i)->getCharacter(0);
		POINT ptChar0 = pChar->getCenterPoint();

		pChar = user->getUser(i)->getCharacter(1);
		POINT ptChar1 = pChar->getCenterPoint();

		if( alluser <= 2 )
		{
			UI["minimap"][i*2].x = minimapX + ptChar0.x / 10;
			UI["minimap"][i*2].y = minimapY + ptChar0.y / 10;
			UI["minimap"][i*2+1].x = minimapX + ptChar1.x / 10;
			UI["minimap"][i*2+1].y = minimapY + ptChar1.y / 10;
		}
		else
		{
			UI["minimap"][i*2].x = minimapX + ptChar0.x / 10;
			UI["minimap"][i*2].y = minimapY + ptChar1.y / 10;
		}

		//if( alluser <= 2 )
		//{
		//	UI["minimap"][i*2].x = UI["minimap"].x + user->getUser(i)->getCharacter(0)->getCenterPoint().x / 10;
		//	UI["minimap"][i*2].y = UI["minimap"].y + user->getUser(i)->getCharacter(0)->getCenterPoint().y / 10;
		//	UI["minimap"][i*2+1].x = UI["minimap"].x + user->getUser(i)->getCharacter(1)->getCenterPoint().x / 10;
		//	UI["minimap"][i*2+1].y = UI["minimap"].y + user->getUser(i)->getCharacter(1)->getCenterPoint().y / 10;
		//}
		//else
		//{
		//	UI["minimap"][i*2].x = UI["minimap"].x + user->getUser(i)->getCharacter(0)->getCenterPoint().x / 10;
		//	UI["minimap"][i*2].y = UI["minimap"].y + user->getUser(i)->getCharacter(0)->getCenterPoint().y / 10;			
		//}
	}

	//CPlayState* playState = (CPlayState*)CGameManager::getInstance()->getState(GAME_STATE_PLAY);
	UI["minimap"]["screen"].x = UI["minimap"].x + m_map->getScreenPoint().x / 10;
	UI["minimap"]["screen"].y =	UI["minimap"].y + m_map->getScreenPoint().y / 10;
}

void CPlayState::onMouseLClick()
{
	if( isGameEnd() )
		return;

	// ���� ���õ� ĳ���͸� �޾ƿ´�.
	CCharacter* character = CUserManager::getInstance()->getNowTurnUser()->getSelectCharacter();

	// ĳ���Ͱ� waterball �����̸� ���콺 �Է��� �޴´�.
	if( character->isWaterOnce() )
	{
		POINT screenPoint = getMap()->getScreenPoint();		// screen ��ǥ
		POINT mousePoint = m_gameManager->getMousePoint();	// mouse ��ǥ

		for( int i=0 ; i<(int)m_vecWaterBallTile.size() ; i++ )
		{
			TileInfo tile = getMap()->getTile( m_vecWaterBallTile[i] );

			if((tile.m_x - 25 < screenPoint.x + mousePoint.x)&&(screenPoint.x + mousePoint.x < tile.m_x + 25)
				&&(tile.m_y - 25 < screenPoint.y + mousePoint.y)&&(screenPoint.y + mousePoint.y < tile.m_y + 25))
			{
				// ���õ� Ÿ�Ͽ� ��ǳ����ġ...
				setupWaterBall( tile.m_id, character->getId() );
			}
		}

		//int tileIndex = character->getTileIndex();			// ĳ������ Ÿ�� �ε���

		//int tileListSize = getMap()->getTileListSize();		// tile list size

		//for(int count = 0; count <3;)
		//{
		//	TileInfo tile = getMap()->getTile(tileIndex);
		//	if(tile.m_point == 1)
		//	{
		//		if((tile.m_x - 25 < screenPoint.x + mousePoint.x)&&(screenPoint.x + mousePoint.x < tile.m_x + 25)
		//			&&(tile.m_y - 25 < screenPoint.y + mousePoint.y)&&(screenPoint.y + mousePoint.y < tile.m_y + 25))
		//		{
		//			Packet packet(REQ_TILE_WATERBALL);
		//			packet << tileIndex;
		//			CMessageManager::getInstance()->sendMessageToClientServer(packet);
		//		}
		//		count++;
		//	}
		//	if(tileIndex < (tileListSize - 1))
		//		tileIndex++;
		//	else
		//		break;
		//}

		//for(int count = 0; count <3;)
		//{
		//	TileInfo tile = getMap()->getTile(tileIndex);
		//	if(tile.m_point == 1)
		//	{
		//		if((tile.m_x - 25 < screenPoint.x + mousePoint.x)&&(screenPoint.x + mousePoint.x < tile.m_x + 25)
		//			&&(tile.m_y - 25 < screenPoint.y + mousePoint.y)&&(screenPoint.y + mousePoint.y < tile.m_y + 25))
		//		{
		//			Packet packet(REQ_TILE_WATERBALL);
		//			packet << tileIndex;
		//			CMessageManager::getInstance()->sendMessageToClientServer(packet);
		//		}
		//		count++;
		//	}
		//	if(tileIndex > 0)
		//		tileIndex--;
		//	else
		//		break;
		//}
	}
}

void CPlayState::setGameEnd()
{
	m_bGameEnd = TRUE;
	m_dwGameEndTime = timeGetTime();

	// ä���� ������ ��� ��Ʈ�ѵ��� �Է��� ���´�..
	// �׸��� �޼����� �ٿ��.
	CUIManager::getInstance()["minimap"].getImageBox( "GameEndBox" ).setVisible( true );
}

BOOL CPlayState::isGameEnd()
{
	return m_bGameEnd;
}

void CPlayState::setWaterBallSelect( int nCharTileIndex )
{
	// vector clear
	m_vecWaterBallTile.clear();

	// �ʿ��� ��ǳ�� �����ϴ� Ÿ���� �׷��ְ� �Ѵ�.
	m_map->getCanWaterBallTiles( nCharTileIndex, m_vecWaterBallTile );

	// Ÿ���� ���ð����ϴٰ� �ٽ� �����Ѵ�.
	for( int i=0 ; i<(int)m_vecWaterBallTile.size() ; i++ )
	{
		int nTileIndex = m_vecWaterBallTile[i];

		TileInfo tileInfo = m_map->getTile( nTileIndex );
		tileInfo.m_select = 1;
		//m_map->setTile( tileInfo, nTileIndex );
		m_map->setTileFromId( tileInfo.m_id, tileInfo );
	}
}

void CPlayState::eraseWaterBallSelect()
{
	// Ÿ���� ���úҰ����ϴٰ� �ٽ� �����Ѵ�.
	for( int i=0 ; i<(int)m_vecWaterBallTile.size() ; i++ )
	{
		int nTileIndex = m_vecWaterBallTile[i];

		TileInfo tileInfo = m_map->getTile( nTileIndex );
		tileInfo.m_select = 0;
		//m_map->setTile( tileInfo, nTileIndex );
		m_map->setTileFromId( tileInfo.m_id, tileInfo );
	}	

	// vector clear
	m_vecWaterBallTile.clear();
}

void CPlayState::setupWaterBall( int nTileId, int nCharID )
{
	// packet�� ���� ������
	// ó���� ack�����Ѵ�.
	// ��ǳ���� �������� ����ϴ� ������ �ٸ� �����̹Ƿ�
	// �� ������ ĳ���� ���¸� ��������ش�.
	Packet packet(REQ_TILE_WATERBALL);
	packet << nTileId << nCharID << CUserManager::getInstance()->getMyUserId();
	CMessageManager::getInstance()->sendMessageToClientServer(packet);
}

void CPlayState::processSetupWaterBall( int nTileId )
{
	CUserManager* pUserManager = CUserManager::getInstance();
	
	// Ÿ������ ĳ���Ͱ� ������ ó��....
	for( int i=0 ; i<pUserManager->getUserNum() ; i++ )
	{
		CUser* pUser = pUserManager->getUser( i );

		for( int k = 0; k<pUser->getCharacterNum() ; k++ )
		{
			// ��ǳ���� ��ġ�ϴ� ���� ĳ����
			CCharacter* pChar = pUser->getCharacter( k );

			// ��ġ�� Ÿ������ ĳ���Ͱ� �ִ�..
			// �׷��� �� ĳ������ ���¸� suffer���·� �ٲ۴�
			if( pChar->getTileId() == nTileId )
			{
				pChar->setCharacterState( CHARACTER_STATE_SUFFER );
				eraseWaterBallSelect();
				//���� �Ѱܾ� �Ѵ�.

				// ������ �Ѿ�� �Ѵ�
				// ĳ������ ���¸� rest�� �ٲ۴�
				CCharacter* pNowChar = pUserManager->getNowTurnUser()->getSelectCharacter();
				pNowChar->setTurnOutFlag( true );
				pNowChar->setCharacterState( CHARACTER_STATE_REST );
				return;
			}
		}
	}
	eraseWaterBallSelect();

	// Ÿ�Ͽ� ��ǳ����ġ..
	TileInfo tile = m_map->getTile( nTileId );
	tile.m_waterball = 1;
	//m_map->setTile(tile, nTileIndex);
	m_map->setTileFromId( tile.m_id, tile );

	// ������ �Ѿ�� �Ѵ�
	// ĳ������ ���¸� rest�� �ٲ۴�
	CCharacter* pChar = pUserManager->getNowTurnUser()->getSelectCharacter();
	pChar->setTurnOutFlag( true );
	pChar->setCharacterState( CHARACTER_STATE_REST );
}

BOOL	CPlayState::cheatOrder( TCHAR* pMsg )
{
	string	msg( pMsg );

	// move
	int pos = msg.find( "/move " );
	if( pos != string::npos)
	{
		char * p = (char*)msg.c_str();
		int count = atoi( p+strlen("/move " ) );

		if( count < 0 && count > 50 )
			return FALSE;

		Packet packet(REQ_CHARACTER_MOVE);
		packet << count;
		CMessageManager::getInstance()->sendMessageToClientServer(packet);
		return TRUE;
	}

	return FALSE;
}

void	CPlayState::updateCompleteNumUI()
{
	for( int i=0 ; i<CUserManager::getInstance()->getUserNum() ; i++ )
	{
		CUser* pUser = CUserManager::getInstance()->getUser( i );

		int completeNum = pUser->getCompleteNum();
		int characterNum= pUser->getCharacterNum();

		char buf[128];
		sprintf_s(buf,"%d / %d",completeNum,characterNum);
		m_completeNum[i]->setString( buf );
	}
}

void CPlayState::updateLevelChar()
{
	// �� �������� ���õ� char�� ������ �ͼ� ������Ʈ
	for( int i=0 ; i<CUserManager::getInstance()->getUserNum() ; i++ )
	{
		CUser* pUser = CUserManager::getInstance()->getUser( i );
		CCharacter* pChar = pUser->getSelectCharacter();

		int nLevel = pChar->getLevel();

		char buf[128];
		sprintf_s(buf, "%d",nLevel);
		m_printLevelChar[i]->setString( buf );
	}
	
}