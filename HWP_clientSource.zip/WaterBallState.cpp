#include "stdafx.h"
#include "WaterBallState.h"
#include "UserManager.h"
#include "Map.h"
#include "PlayState.h"
#include "RestState.h"

CWaterBallState::CWaterBallState(CCharacter* _character)
{
	this->m_character	= _character;
	m_count				= 0;
}

CWaterBallState::~CWaterBallState()
{

}

void CWaterBallState::stateStart()
{
	//if(m_character->isWaterOnce() == false)
	//	return;

	//CPlayState* playState = (CPlayState*)CGameManager::getInstance()->getState(GAME_STATE_PLAY);

	//// ���� ĳ������ Ÿ�� �ε����� �޾ƿ´�
	//int tileIndex = m_character->getTileIndex();

	//// Ÿ�ϸ���Ʈ�� ����� ���´�
	//int tileListSize = playState->getMap()->getTileListSize();

	//// count�� ������ 3ĭ�� �˻�
	//for(int count = 0; count <3;)
	//{
	//	// �ε����� ����ؼ� Ÿ���� ������ ���Ѵ�.
	//	TileInfo tile = playState->getMap()->getTile(tileIndex);

	//	// m_point == 1 : ���� Ÿ��. ���⿡�� ����ź�� ��ġ����
	//	if(tile.m_point == 1)
	//	{
	//		//TileInfo tile = playState->getMap()->getTile(tileIndex);
	//		tile.m_select = 1;	// ���⿡ ���� �����ϴٰ� �÷��� ����
	//		playState->getMap()->setTile(tile,tileIndex); // Ÿ�� ������ ����
	//		count++;
	//	}
	//	// 
	//	if(tileIndex < (tileListSize - 1))
	//		tileIndex++;
	//	else
	//		break;
	//}

	//// �ڷ� 3ĭ�� �˻�
	//for(int count = 0; count <3;)
	//{
	//	TileInfo tile = playState->getMap()->getTile(tileIndex);

	//	if(tile.m_point == 1)
	//	{
	//		//TileInfo tile = playState->getMap()->getTile(tileIndex);
	//		tile.m_select = 1;
	//		playState->getMap()->setTile(tile,tileIndex);
	//		count++;
	//	}
	//	if(tileIndex > 0)
	//		tileIndex--;
	//	else
	//		break;
	//}


	//if(m_character->getUserId() == CUserManager::getInstance()->getNowUserId())
	//	m_character->setWaterSuffer(true);

	//m_character->setWaterOnce(false);
}

void CWaterBallState::stateEnd()
{
	//CPlayState* playState = (CPlayState*)CGameManager::getInstance()->getState(GAME_STATE_PLAY);

	//int tileIndex = m_character->getTileIndex();
	//int tileListSize = playState->getMap()->getTileListSize();

	//for(int count = 0; count <3;)
	//{
	//	TileInfo tile = playState->getMap()->getTile(tileIndex);

	//	if(tile.m_point == 1)
	//	{
	//		TileInfo tile = playState->getMap()->getTile(tileIndex);
	//		if(tile.m_select == 1)
	//			tile.m_select = 0;
	//		playState->getMap()->setTile(tile,tileIndex);
	//		count++;
	//	}
	//	if(tileIndex < (tileListSize - 1))
	//		tileIndex++;
	//	else
	//		break;
	//}

	//for(int count = 0; count <3;)
	//{
	//	TileInfo tile = playState->getMap()->getTile(tileIndex);

	//	if(tile.m_point == 1)
	//	{
	//		TileInfo tile = playState->getMap()->getTile(tileIndex);
	//		if(tile.m_select == 1)
	//			tile.m_select = 0;
	//		playState->getMap()->setTile(tile,tileIndex);
	//		count++;
	//	}
	//	if(tileIndex > 0)
	//		tileIndex--;
	//	else
	//		break;
	//}
}

void CWaterBallState::draw(DWORD _timeDelta)
{
	UNREFERENCED_PARAMETER(_timeDelta);
	//CPlayState* playState = (CPlayState*)CGameManager::getInstance()->getState(GAME_STATE_PLAY);

	//if(m_count == 0)
	//{
	//	stateStart();
	//	m_count++;
	//}
	//else if(m_count < 200 )
	//	m_count++;
	////else
	////{
	////	m_count = 0;
	////	m_character->setWaterSuffer(false);
	////}

	//if(m_character->isWaterSuffer() == false)
	//{
	//	m_count = 0;
	//	m_character->setTurnOutFlag(true);
	//	m_character->setCharacterState(CHARACTER_STATE_REST);
	//}

	//POINT position;
	//position.x = m_character->getCenterPoint().x - 75 - playState->getMap()->getScreenPoint().x;
	//position.y = m_character->getCenterPoint().y - 125 - playState->getMap()->getScreenPoint().y;
	//m_character->setPosition(position);

	//m_character->setSpriteType(SPRITE_TYPE_WAIT);

	//int num = m_count/SPRITE_NUM_DELAY%SPRITE_NUM_WAIT;
	//m_character->setSpriteNo(num);
	//m_character->BitBlt();


	CPlayState* playState = (CPlayState*)CGameManager::getInstance()->getState(GAME_STATE_PLAY);

	if( m_count < SPRITE_NUM_DELAY*SPRITE_NUM_WAIT )
		m_count++;
	else
		m_count = 0;

	m_character->setSpriteType(SPRITE_TYPE_WAIT);
	m_character->setScrollAvailable(true);

	int num = m_count/SPRITE_NUM_DELAY%SPRITE_NUM_WAIT;
	m_character->setSpriteNo(num);

	POINT position;
	position.x = m_character->getCenterPoint().x - 75 - playState->getMap()->getScreenPoint().x;
	position.y = m_character->getCenterPoint().y - 125 - playState->getMap()->getScreenPoint().y;
	m_character->setPosition(position);

	m_character->BitBlt();
	m_character->drawOption();
}