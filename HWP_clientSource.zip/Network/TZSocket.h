#ifndef _CTASocket_H_
#define _CTASocket_H_

#include <windows.h>
#include "RGProtocol.h" // teleadam_20050207
#include "RSProtocol.h"
#include "TZQueue.h"
#include "Common/COUserData.h"

class CTZSocket
{
private:
	WSADATA			m_WsaData;
	SOCKADDR_IN		m_Addr;

	CCOUserData*	m_pUserData;
	
public:
	SOCKADDR_IN		m_ServerAddr;
	SOCKET			m_Socket;
	CTZQueue*		m_pQueue;
	HANDLE			m_hSema;

    CTZSocket(void);
	~CTZSocket(void);
	void ObjConntect(CCOUserData* pUserData) {	m_pUserData = pUserData;	}

	int WSASetup(void);				// Initialize Winsock version 2.2
	int CreateSocket(void);			// Create a new socket to datagrams on
	int SetupSocket(int arg_Port);	// Setup a SOCKADDR_IN, and bind
	int SendPacketToServer		(DATAUNIT *processDataUnit); // Send Pakcet
	int SendPacketToRoomMajor	(DATAUNIT *processDataUnit);
	int SendPacketToJoinUser	(DATAUNIT *processDataUnit);
	int ServerSetting(char* stripaddr, int arg_Port);
	void SetQueue(void);					// Allocate a Queue
	void FreeQueue(CTZQueue *freeQueue);	// Free the Queue

	// teleadam_20050207 [

	int SendTOS(LPP_COMMON lpPacket);
	
	// ] teleadam_20050207
};

#endif