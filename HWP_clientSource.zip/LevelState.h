#ifndef __LevelState_h__
#define __LevelState_h__
#include "ICharacterState.h"
#include "Character.h"

class CLevelState : public ICharacterState
{
private:
	CCharacter*				m_character;
	int						m_count;
	int						m_effectCount;
public:
	CLevelState(CCharacter* _character);
	virtual					~CLevelState();
	void					stateStart();
	void					stateEnd();
	void					draw(DWORD _timeDelta);
	void					drawLevelCharacter();
	void					drawLevelEffect();
};

#endif