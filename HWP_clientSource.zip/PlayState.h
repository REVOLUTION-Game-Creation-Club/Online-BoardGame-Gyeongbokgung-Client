#ifndef __PlayState_h__
#define __PlayState_h__
#include "IGameState.h"
#include "GameManager.h"
#include "FightImage.h"

#define TIME_GAME_END_MSG	3000	// 3��

class ActionListener;

class CPlayState : public IGameState
{
private:
	CGameManager*				m_gameManager;

	CMap*						m_map;
	CSpriteObject*				m_effect;
	CRullet*					m_rullet;
	CFPS*						m_fps;
	CPrintObject*				m_message;
	CPrintObject*				m_completeNum[4];
	CPrintObject*				m_printLevelChar[4];
	CFightImage*				m_fighterImage1;

	//{{ bakky
	ActionListener*				m_listener;
	BOOL						m_bGameEnd;	// ���� ���� �÷���.. �ʱ�ȭ�� false
	DWORD						m_dwGameEndTime;
	vector<int>					m_vecWaterBallTile;

	void updateLevelChar();
	//}}

public:
								CPlayState(CGameManager* _gameManager);
	virtual						~CPlayState();

	bool						initialize();
	void						release();
	
	void						registerDrawObject();
	void						unregisterDrawObject();

	void						onUpdate();
	void						onKeyboard(WPARAM _wParam);
	void						processMouseMove();
	void						onMouseLClick();

	CMap*						getMap(){ return m_map; }
	void						setMap(CMap* _map){ m_map = _map;}
	CRullet*					getRullet(){ return m_rullet; }
	void						setRullet(CRullet* _rullet){ m_rullet = _rullet;}
	CFPS*						getFPS(){ return m_fps; }
	void						setFPS(CFPS* _fps){ m_fps = _fps;}
	CPrintObject*				getMessage(){ return m_message; }
	void						setMessage(CPrintObject* _message){ m_message = _message;}
	//CPrintObject*				getCompleteNum(){ return m_completeNum; }
	//void						setCompleteNum(CPrintObject* _completeNum){ m_completeNum = _completeNum;}
	CFightImage*				getFightImage(){ return	m_fighterImage1; }
	void						setFightImage(CFightImage* _fighterImage1){ m_fighterImage1 = _fighterImage1;}
	CSpriteObject*				getEffect(){ return m_effect; }
	void						setCompleteNum(CSpriteObject* _effect){ m_effect = _effect;}





	//{{ bakky
	void	setGameEnd();
	BOOL	isGameEnd();
	void	setWaterBallSelect( int nCharTileIndex );
	void	eraseWaterBallSelect();	// water ball ���°� ������ ȣ��
	void	setupWaterBall( int nTileIndex, int nCharID );
	void	processSetupWaterBall( int nTileId );
	BOOL	cheatOrder( TCHAR* pMsg );	// TRUE �̸� cheat
	void	updateCompleteNumUI();
	//}}
};

#endif