#include "StdAfx.h"
#include "TextBox.h"

CTextBox::CTextBox(void)
{
}

CTextBox::~CTextBox(void)
{
}

CTextBox::CTextBox(string _name)
{
	kind	= "textbox";
	name	= _name;
	m_ListSize = 0;	

	m_fontPos_x = -99;
	m_fontPos_y = -99;
	m_lineSpace = 3;

	insertString("");
}

CTextBox::CTextBox(string _name, int _x, int _y, int _width, int _height)
{
	kind	= "textbox";
	name	= _name;
	x		= _x;
	y		= _y;
	width	= _width;
	height	= _height;
	m_ListSize = 0;


	m_fontPos_x = x;
	m_fontPos_y = y;
	m_lineSpace = 3;

	insertString("");
}

CTextBox::CTextBox(string _name, int _x, int _y, int _width, int _height, int _texX, int _texY, char* _fileName)
{
	kind	= "textbox";
	name	= _name;
	x		= _x;
	y		= _y;
	width	= _width;
	height	= _height;
	m_ListSize = 0;


	tex_x	= _texX;
	tex_y	= _texY;
	setFileNavi(_fileName);

	m_fontPos_x = x;
	m_fontPos_y = y;
	m_lineSpace = 3;

	insertString("");
}

void CTextBox::changeString(string _sentence)
{	
	refreshString(0, &_sentence[0]);
}

void CTextBox::changeString(char* _sentence)
{
	refreshString(0, _sentence);
}

void CTextBox::addListener(Clistener *_listener)
{
	m_listener = _listener;
}

void CTextBox::activeControl(int _state)
{
	if( _state == REV_MOUSE_DOWN )
	{
		if( m_listener != NULL )
		{
			m_listener->setChanged(name);
			m_listener->textChanged();
		}
		else
		{
			//���Ŀ� ����ó�� ����� ��ġ��!!		
		}
	}
	else if( _state == REV_MOUSE_MOVE )
	{

	}
}

void CTextBox::deactivate()
{
	
}

char* CTextBox::getString()
{
	return &m_stringList[0][0];
}

void CTextBox::pressReturn()
{
	if( m_listener != NULL )
	{
		m_listener->setChanged(name);
		m_listener->pressReturn();
	}
	else
	{
		//���Ŀ� ����ó�� ����� ��ġ��!!		
	}
}

