#ifndef __FrogState_h__
#define __FrogState_h__
#include "ICharacterState.h"
#include "Character.h"

class CFrogState : public ICharacterState
{
private:
	CCharacter*				m_character;
	int						m_count;
public:
	CFrogState(CCharacter* _character);
	virtual					~CFrogState();
	void					stateStart();
	void					stateEnd();
	void					draw(DWORD _timeDelta);
	void					drawFrogCharacter();
};

#endif