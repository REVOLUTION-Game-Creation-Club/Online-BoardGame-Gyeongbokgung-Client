#include "StdAfx.h"
#include "Sound.h"
#include "SoundFileLoader.h"
#include "SoundManager.h"

namespace rev
{

LPDIRECTSOUND8 CSound::m_lpDirectSound = NULL;

CSound::CSound( TCHAR* _szFileName ) : m_strFileName( _szFileName )
{
}

CSound::~CSound(void)
{
	destroy();
}

bool	
CSound::initialize()
{
	m_lpSoundBuffer	= 0;

	memset( &m_caps, 0, sizeof( DSBCAPS ) );
	memset( &m_waveFormat, 0, sizeof( WAVEFORMATEX ) );

	return true;
}

bool	
CSound::destroy()
{
	if( m_lpSoundBuffer )
	{
		m_lpSoundBuffer->Release();
		m_lpSoundBuffer = NULL;
	}

	return true;
}

bool	
CSound::stop()
{
	// cursor �ʱ�ȭ
	m_lpSoundBuffer->Stop();
	m_lpSoundBuffer->SetCurrentPosition( 0 );

	return true;
}

bool	
CSound::pause()
{
	//m_lpSoundBuffer->Stop();

	return true;
}

bool	
CSound::resume()
{
	//DWORD dwFlags = ( m_bLoop ? DSBPLAY_LOOPING : 0 );
	//m_lpSoundBuffer->Play( 0, 0, dwFlags );

	return true;
}

bool	
CSound::setVolume( long _volume )
{
	if( !m_lpSoundBuffer )
		return false;

	HRESULT hr = m_lpSoundBuffer->SetVolume( _volume );
	if( FAILED( hr ) )
	{
		debugDXError( hr );
		return false;
	}

	return true;
}

bool	
CSound::setPan( long _pan )
{
	HRESULT hr = m_lpSoundBuffer->SetPan( _pan );
	if( FAILED( hr ) )
	{
		debugDXError( hr );
		return false;
	}

	return true;
}

bool	
CSound::createSoundBuffer( DWORD dwBufferSize )
{
	HRESULT			hr;
	DSBUFFERDESC	desc;
	LPDIRECTSOUNDBUFFER	lpdsb;

	ZeroMemory( &desc, sizeof( DSBUFFERDESC ) );
	desc.dwSize	= sizeof( DSBUFFERDESC );
	desc.dwFlags= DSBCAPS_CTRLPAN | DSBCAPS_GETCURRENTPOSITION2 | DSBCAPS_CTRLVOLUME;
	desc.lpwfxFormat	= &m_waveFormat;
	desc.dwBufferBytes	= dwBufferSize;

	hr = m_lpDirectSound->CreateSoundBuffer( &desc, &lpdsb, NULL );
	if( FAILED( hr ) )
	{
		debugDXError( hr );
		return false;
	}

	hr = lpdsb->QueryInterface( IID_IDirectSoundBuffer8, (void**)&m_lpSoundBuffer );
	if( FAILED( hr ) )
	{
		debugDXError( hr );
		return false;
	}

	// �ӽ� sound buffer release
	lpdsb->Release();

	// set m_caps
	memset( &m_caps, 0, sizeof( DSBCAPS ) );
	m_caps.dwSize = sizeof( DSBCAPS );
	hr = m_lpSoundBuffer->GetCaps( &m_caps );
	if( FAILED( hr ) )
	{
		debugDXError( hr );
		return false;
	}

	return true;
}

bool	
CSound::loadSoundDataToSoundBuffer( CSoundFileLoader* pSoundFileLoader )
{
	HRESULT hr;
	void*	pData;
	DWORD	dwBytes;
	void*	pData2;
	DWORD	dwBytes2;
	DWORD	dwBytesRead;

	hr = m_lpSoundBuffer->Lock( 0, m_caps.dwBufferBytes, &pData, &dwBytes, &pData2, &dwBytes2, 0 );
	if( FAILED( hr ) )
	{
		debugDXError( hr );
		return false;
	}

	if( !pSoundFileLoader->read( (BYTE*)pData, dwBytes, &dwBytesRead ) )
	{
		debug( "pSoundFile->read failed \n" );
		return false;
	}

	hr = m_lpSoundBuffer->Unlock( pData, dwBytes, pData2, dwBytes2 );
	if( FAILED( hr ) )
	{
		debugDXError( hr );
		return false;
	}

	return true;
}

BYTE	
CSound::getSilenceData()
{
	if( m_waveFormat.wBitsPerSample == 8 )
		return 0x80;
	else if( m_waveFormat.wBitsPerSample == 16 )
		return 0x00;

	return 0;
}


void	
CSound::load( CSoundFileLoader* pSoundFileLoader )
{
	memcpy( &m_waveFormat, pSoundFileLoader->getFormat(), sizeof( WAVEFORMATEX ) );

	m_strFileName = pSoundFileLoader->getName();
}

}
