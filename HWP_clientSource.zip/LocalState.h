#ifndef __LocalState_h_
#define __LocalState_h_

#include "IMessageState.h"
#include "MessageManager.h"
#include "Packet.h"

class CLocalState: public IMessageState{
private:
	CMessageManager*	m_messageManager;
public:
	CLocalState(CMessageManager* _messageManager);
	virtual ~CLocalState();

	// ������ ��� ������ ����� ���� �����Ƿ� �ʿ����� �ʾ� ������ ������
	bool				initialize();
	void				cleanup();

	void				processPacket();
	static void			parsingPacket(Packet& _packet);
	void				broadcast(Packet& _packet);
	void				sendMessageToMainServer(Packet& _packet);
	bool				connectServer(char* _addr){return FALSE;};
	//
	void 				sendMessageToClientServer(Packet& _packet);	


	void				onReqGameStart(Packet& _packet);
	void				onReqGameEnd(Packet& _packet);
	void				onReqTurnIn(Packet& _packet);
	void				onReqTurnOut(Packet& _packet);
	void				onReqRulletStop(Packet& _packet);
	void				onReqCharacterMove(Packet& _packet);
	void				onReqCharacterChange(Packet& _packet);
	void				onReqItemMagnetic(Packet& _packet);
	void				onReqItemWaterBall(Packet& _packet);
	void				onReqItemThunder(Packet& _packet);
	void				onReqTileWaterball(Packet& _packet);
	void				onReqGameChat(Packet& _packet);

	void				onAckServerConnect(Packet& _packet);
	void				onAckClientConnect(Packet& _packet);
	void				onAckServerDisconnect(Packet& _packet);
	void				onAckClientDisconnect(Packet& _packet);
	void				onAckGameStart(Packet& _packet);
	void				onAckGameEnd(Packet& _packet);
	void				onAckTurnIn(Packet& _packet);
	void				onAckTurnOut(Packet& _packet);
	void				onAckRulletStop(Packet& _packet);
	void				onAckCharacterMove(Packet& _packet);
	void				onAckCharacterChange(Packet& _packet);
	void				onAckItemMagnetic(Packet& _packet);
	void				onAckItemWaterBall(Packet& _packet);
	void				onAckItemThunder(Packet& _packet);
	void				onAckTileWaterball(Packet& _packet);
	void				onAckGameChat(Packet& _packet);
};
#endif
