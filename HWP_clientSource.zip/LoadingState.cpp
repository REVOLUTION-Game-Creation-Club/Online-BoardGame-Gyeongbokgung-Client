#include "stdafx.h"
#include "LoadingState.h"
#include "DrawManager.h"
#include "ui/CUIManager.h"
#include "UserManager.h"

CLoadingState::CLoadingState(CGameManager* _gameManager)
{
	this->m_gameManager = _gameManager;
}
CLoadingState::~CLoadingState()
{

}
bool CLoadingState::initialize()
{
	CUIManager& manager = CUIManager::getInstance();
	switch(CUserManager::getInstance()->getMyUser()->getCharacter(0)->getKind())
	{
	case CHARACTER_KIND_BOY:
		manager.makeContainer("loadingContainer", 0, 0, 1024, 768, 0, 0, "image/loading_boy.bmp" );
		manager.getUIDraw(0)->setFileName("image/loading_boy.bmp");
	break;
	case CHARACTER_KIND_GIRL:
		manager.makeContainer("loadingContainer", 0, 0, 1024, 768, 0, 0, "image/loading_girl.bmp" );
		manager.getUIDraw(0)->setFileName("image/loading_girl.bmp");
		break;
	case CHARACTER_KIND_GIANT:
		manager.makeContainer("loadingContainer", 0, 0, 1024, 768, 0, 0, "image/loading_giant.bmp" );
		manager.getUIDraw(0)->setFileName("image/loading_giant.bmp");
		break;
	}
	CDrawManager::getInstance()->insertObject(DRAW_OBJECT_INTERFACE, (IDrawObject*)manager.getUIDraw(0));

	return true;
}
void CLoadingState::release()
{
	CUIManager& manager = CUIManager::getInstance();
	CDrawManager::getInstance()->eraseObject(DRAW_OBJECT_INTERFACE, manager.getUIDraw(0)->getOrder());
	CDrawManager::getInstance()->eraseList();

	//{{ bakky
	manager.destroyAllContainer();
	//}}
}
void CLoadingState::onUpdate()
{
	static DWORD count = 0;
	count++;

	if(count > 50)
	{
		count = 0;
		m_gameManager->setState(GAME_STATE_PLAY);
	}
}
void CLoadingState::onKeyboard(WPARAM _wParam)
{

}
void CLoadingState::processMouseMove()
{

}
