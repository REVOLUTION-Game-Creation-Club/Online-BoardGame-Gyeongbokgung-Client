#ifndef __LobbyState_h__
#define __LobbyState_h__
#include "IGameState.h"
#include "GameManager.h"
#include "GameProtocol.h"
#include "Packet.h"

class ActionListener2;

class CLobbyState : public IGameState
{
private:
	CGameManager*				m_gameManager;
	ActionListener2*			m_listener;

	Packet m_userList;
	int m_roomNO[ROOMS_PER_PAGE];
	int m_roomState[ROOMS_PER_PAGE];

	int m_nowPage;
	int m_nowUserListPage;

	DWORD m_lastTime;

public:
								CLobbyState(CGameManager* _gameManager);
	virtual						~CLobbyState();

	bool						initialize();
	void						release();

	void						onUpdate();
	void						onKeyboard(WPARAM _wParam);
	void						processMouseMove();
	void						onMouseLClick(){}

	void						setNowULPage(int _data){m_nowUserListPage = _data;}
	int							getNowULPage(){return m_nowUserListPage;}
	void						setUserList(Packet _packet){m_userList = _packet;}
	Packet						getUserList(){return m_userList;}
	void						setRoom1(int _whatRoom, int _roomNo, char* _roomName, int _roomState, char* _password, int _mapNo);
	void						setRoom2(int _whatRoom, int _roomNo, char* _roomName, int _roomState, char* _password, int _mapNo);
	void						setRoom3(int _whatRoom, int _roomNo, char* _roomName, int _roomState, char* _password, int _mapNo);
	void						setRoom4(int _whatRoom, int _roomNo, char* _roomName, int _roomState, char* _password, int _mapNo);
	void						setNowPage(int data){m_nowPage = data;}
	int							getNowPage(){return m_nowPage;}
	int							getRoomNo(int _locate) {return m_roomNO[_locate];}
	void popUpNotExist();
	void popUpIsFull();
	void disconnected();
	void popUpOnPlay();
};

#endif