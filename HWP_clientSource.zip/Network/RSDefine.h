//-----------------------------------------------------------------
//	Every Kind Define
//
//						
//	Copy right all reserved by Revolution Online Team
//														2002/07/28
//-----------------------------------------------------------------


#ifndef _RSDEFINE_H_
#define _RSDEFINE_H_

#define _WIN32_WINNT 0x0400

//-- Game Mode  --------------------------------------------
		#define GM_LOGO					0	//	�ΰ�		
		#define GM_LOGIN				1	//	�α� 
		#define GM_CHANNEL				2	//	ä��
		#define GM_WAITROOM				3	//	����	
		#define GM_GAMEROOM				4	//	���ӹ�
		#define GM_PLAYGAME				5	//	����

//-- GAME SPEED --------------------------------------------
		#define SP_GAMEFRAME			25	//	���� ��ü ������ �ӵ�
		#define SP_SGMOVE				8	//	���� �̵� �� ������ �ӵ�
		#define SP_ITEMANI				4	//	������ ������ �ӵ�

//-- Socket Option --------------------------------------------
		#define DEFAULT_PACKET_SIZE		1024	// default buffer size
		#define PORT_NO					5052
		#define SERVER_PORT_NO			5051
		#define SNAKE_ID 4
//		const	LPSTR lpszIPAddr		= "155.230.17.171";

//-- Procotol Kind --------------------------------------------
		#define PK_ID_DUP_CHK_REQ		0
		#define PK_ID_DUP_CHK_ACK		1
		#define PK_USER_REG_REQ			2
		#define PK_USER_REG_ACK			3
		#define PK_LOG_AUTH_REQ			4
		#define PK_LOG_AUTH_ACK			5
		#define PK_WAIT_ROOM_LIST_REQ	6
		#define PK_WAIT_ROOM_LIST_ACK	7
		#define PK_ENTER_WAIT_ROOM_REQ	8
		#define PK_ENTER_WAIT_ROOM_ACK	9
		#define PK_ROOM_LIST_REQ		10
		#define PK_ROOM_LIST_ACK		11
		#define	PK_USER_LIST_REQ		12
		#define	PK_USER_LIST_ACK		13
		#define	PK_ENTER_ROOM_REQ		14
		#define	PK_ENTER_ROOM_ACK		15
		#define	PK_MAKE_ROOM_REQ		16
		#define	PK_MAKE_ROOM_ACK		17
		#define PK_EXIT_WAIT_REQ		18
		#define PK_EXIT_WAIT_ACK		19
		#define PK_BACKTOCHANNEL_REQ	20
		#define PK_BACKTOCHANNEL_ACK	21
		#define PK_ROOMUSER_LIST_REQ    22
		#define PK_ROOMUSER_LIST_ACK    23
		#define PK_BACK_TOWAITROOM_REQ	24
		#define PK_ROOM_STATE_NOTIFY	26		
		#define	PK_ENTER_NEWUSER_ACK    27
		//Wait Room Chating Define
		#define PK_IPREQUEST_REQ		28
		#define PK_IPREQUEST_ACK		29
		#define PK_LOGOUTNOTIFY			30


//-- Room Procotol Kind --------------------------------------------
		// To Room Major
		#define GRK_MY_NOTIFY			50
		#define GRK_MAP_REQ				51
		#define GRK_CHAT_REQ			52
		
		// To Join User
		#define GRK_MAP_ACK				60
		#define GRK_USER_NOTIFY			61
		#define GRK_GAME_START_NOTIFY	62		
		#define PK_BACK_TOWAITROOM_ACK	63
		#define GRK_CHAT_ACK			64		
		#define GRK_INFO_REQ			65 // by TA

//-- Game Procotol Kind --------------------------------------------
		// To Room Major
		#define GPK_MOVE_REQ			100
		#define GPK_ATTACK_REQ	        101
		#define GPK_EXIT_REQ			102
		#define GPK_CHAT_REQ			103
		#define GPK_TIMEOVER_NOTIFY		104

		// To Join User
		#define GPK_MOVE_ACK			200
		#define GPK_MAP_NOTIFY			201
		#define GPK_GETITEM_NOTIFY		202
		#define GPK_DTSNAKE_NOTIFY		203
		#define GPK_CHAT_ACK			204
		#define GPK_EXIT_ACK			205
		#define	GPK_CHANGE_HOST			206

//-- Error Code -----------------------------------------------
		#define ERR_ID_DUP_CHK			1	//	DB have same identification
		#define ERR_USER_REG			2	//	Error user registration
		#define ERR_LOG_AUTH			3	//	Error update
		#define ERR_LOG_AUTH_ALR		4	//	Already Login identification
		#define ERR_LOG_AUTH_PWD		5	//	Password not correct
		#define ERR_LOG_AUTH_ID	Not		6	//	Exist identification
		#define ERR_ENTER_WAIT_ROOM		7	//	Error Enter wait room
		#define ERR_ENTER_ROOM_NOTEXIST	8	//	[no] Room is not exist
		#define ERR_ENTER_ROOM_FULL		9	//	Room have 4 user
		#define ERR_ENTER_ROOM			10	//	Error update
		#define ERR_MAKE_ROOM			11	//	Error insert
		#define ERR_MAKE_ROOM_USER		12	//	Error update

//-- Macro Function -------------------------------------------
		#define SendDUToSVR()	g_pSocket->SendPacketToServer(DataUnit);
		#define SendDUToRM()	g_pSocket->SendPacketToRoomMajor(DataUnit, **g_pJoinUser);
		#define SendDUToJU()	g_pSocket->SendPacketToJoinUser(DataUnit, **g_pJoinUser);
		#define AllocDataUnit()	g_pSocket->m_pQueue->GetDataUnit(DEFAULT_PACKET_SIZE);

#endif