#include "stdafx.h"
#include "WaitState.h"
#include "Map.h"
#include "GameManager.h"
#include "PlayState.h"

CWaitState::CWaitState(CCharacter* _character)
{
	this->m_character	= _character;
	m_count				= 0;
}

CWaitState::~CWaitState()
{

}

void CWaitState::stateStart()
{
}

void CWaitState::stateEnd()
{
}

void CWaitState::draw(DWORD _timeDelta)
{
	UNREFERENCED_PARAMETER(_timeDelta);

	if( m_count < SPRITE_NUM_DELAY*SPRITE_NUM_WAIT )
		m_count++;
	else
		m_count = 0;

	drawWaitCharacter();
	m_character->drawOption();
}

void CWaitState::drawWaitCharacter()
{
	CPlayState* playState = (CPlayState*)CGameManager::getInstance()->getState(GAME_STATE_PLAY);

	m_character->setSpriteType(SPRITE_TYPE_WAIT);
	m_character->setScrollAvailable(true);

	int num = m_count/SPRITE_NUM_DELAY%SPRITE_NUM_WAIT;
	m_character->setSpriteNo(num);

	POINT position;
	position.x = m_character->getCenterPoint().x - 75 - playState->getMap()->getScreenPoint().x;
	position.y = m_character->getCenterPoint().y - 125 - playState->getMap()->getScreenPoint().y;
	m_character->setPosition(position);
	m_character->BitBlt();
}