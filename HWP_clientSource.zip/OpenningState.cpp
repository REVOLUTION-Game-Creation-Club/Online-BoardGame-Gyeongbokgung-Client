#include "StdAfx.h"
#include "OpenningState.h"
#include "DrawManager.h"
#include "GameManager.h"

#define OPENNING_FILE	("Openning\\hws.avi")
#define OPENNING_SIZE_WIDTH		720
#define OPENNING_SIZE_HEIGHT	480

COpenningState::COpenningState(CGameManager* _gameManager)
{
	this->m_gameManager = _gameManager;
}

COpenningState::~COpenningState(void)
{
}



bool	
COpenningState::initialize()
{
	HWND hWnd = CDrawManager::getInstance()->getHWnd();

	HINSTANCE hInst = (HINSTANCE)GetWindowLong( hWnd, GWL_HINSTANCE );

	int x = ( WINDOW_WIDTH - OPENNING_SIZE_WIDTH ) / 2;
	int y = ( WINDOW_HEIGHT - OPENNING_SIZE_HEIGHT ) / 2;

	BOOL b = 
	m_mciWnd.Create( WS_CHILD | WS_VISIBLE  | MCIWNDF_NOPLAYBAR | MCIWNDF_NOMENU | MCIWNDF_NOERRORDLG | MCIWNDF_NOTIFYERROR | MCIWNDF_NOTIFYMODE, 
					x, y, WINDOW_WIDTH, WINDOW_HEIGHT, hWnd, hInst );
	long l = m_mciWnd.Open(_T(OPENNING_FILE));

	////{{ �������� ũ�⿡ �°� ũ�⸦ �÷��ش�
	RECT rect;
	rect.left = 0;
	rect.top = 0;
	rect.right = WINDOW_WIDTH;
	rect.bottom = WINDOW_HEIGHT;

	//l = m_mciWnd.PutDest( rect );
	//l = m_mciWnd.SetDest( rect );
	////}}

	l = m_mciWnd.Play();

	return true;
}

void	
COpenningState::release()
{
}

void	
COpenningState::onKeyboard(WPARAM _wParam)
{
	if( _wParam == VK_SPACE )
	{
		onStop();
		m_mciWnd.Destroy();
	}
}

void	
COpenningState::onStop()
{
	ShowWindow( m_mciWnd.GetHwnd(), SW_HIDE );
	m_gameManager->setState(GAME_STATE_TITLE);
}
