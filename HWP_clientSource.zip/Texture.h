#ifndef	__TextureImage_h_
#define __TextureImage_h_
#include <string>
using namespace std;

class CTexture
{
private:
	IDirect3DDevice9*	m_device;
	LPDIRECT3DTEXTURE9	m_texture;
public:
	CTexture(IDirect3DDevice9* _device);
	~CTexture();
	void createTexture(string _fileName);
	void releaseTexture();
	LPDIRECT3DTEXTURE9 getTexture(){ return m_texture; }
};

#endif