#include "stdafx.h"
#include "ResultState.h"
#include "DrawManager.h"
#include "ui/CUIManager.h"
#include "UserManager.h"
#include "packet.h"
#include "MessageManager.h"

#define MAX_RESULT_DISPLAY_TIME	3000

CResultState::CResultState(CGameManager* _gameManager)
{
	this->m_gameManager = _gameManager;
}
CResultState::~CResultState()
{

}
bool CResultState::initialize()
{
	getSoundManager()->play( "���ھ�" );

	CUIManager& manager = CUIManager::getInstance();
	manager.makeContainer("resultContainer", 0, 0, 1024, 768, 0, 0, "image/resultBackground.bmp" );
	manager.getUIDraw(0)->setFileName("image/resultBackground.bmp");
	CDrawManager::getInstance()->insertObject(DRAW_OBJECT_INTERFACE, (IDrawObject*)manager.getUIDraw(0));
	CUIContainer& resultContainer = manager["resultContainer"];
	CUserManager* userManager = CUserManager::getInstance();
	int userNum = CUserManager::getInstance()->getUserNum();
	//int userNum = 4;

	//CCharacter* character1 = new CCharacter(0,CHARACTER_TEAM_RED,CHARACTER_TEAM_RED)

//	userManager->insertUser(user

	POINT panelPos[4] = {{249,185},{249,320},{249,455},{249,590}};
	POINT rankPos[4] = {{249,217},{249,352},{249,487},{249,622}};
	POINT charPos[4] = {{385,190},{385,325},{385,460},{385,595}};
	POINT IDPos[4] = {{600,255},{600,390},{600,575},{600,710}};

	char panel[4][16] = {"panel1","panel2","panel3","panel4"};
	char rank[4][16] = {"rank1","rank2","rank3","rank4"};
	char charface[4][16] = {"charface1","charface2","charface3","charface4"};

	// ��ũ������� �ε����� ���ϰ�	�װ� ���  panelPos�� �ٲ۴�.
	
	//int topRank = 0; 

	//for(int i = 0; i < userNum; i++)
	//{
	//	for(int j = 0; j < userNum; i++)
	//	{

	//	}
	//}
	
	resultContainer.add("imagebox", panel[0], panelPos[0].x, panelPos[0].y, 543, 129, 0, 897, "image/resultBackground.bmp");
	resultContainer.add("imagebox", panel[1], panelPos[1].x, panelPos[1].y, 543, 129, 0, 897, "image/resultBackground.bmp");
	resultContainer.add("imagebox", panel[2], panelPos[2].x, panelPos[2].y, 543, 129, 0, 897, "image/resultBackground.bmp");
	resultContainer.add("imagebox", panel[3], panelPos[3].x, panelPos[3].y, 543, 129, 0, 897, "image/resultBackground.bmp");

	for(int i = 0; i < userNum; i++)
	{
		if(userManager->getUser(i)->isUserComplete())
		{
			resultContainer.getImageBox(panel[i]).setValue(0,768,"image/resultBackground.bmp");
		}
	}

	for(int i = 0; i < userNum; i++)
	{
		switch(userManager->getUser(i)->getRank())
		{
		case 0:
			resultContainer.add("imagebox", rank[i], rankPos[i].x, rankPos[i].y, 144, 56, 880, 968, "image/resultBackground.bmp");
			break;
		case 1:
			resultContainer.add("imagebox", rank[i], rankPos[i].x, rankPos[i].y, 144, 56, 736, 912, "image/resultBackground.bmp");
			break;
		case 2:
			resultContainer.add("imagebox", rank[i], rankPos[i].x, rankPos[i].y, 144, 56, 880, 912, "image/resultBackground.bmp");
			break;
		case 3:
			resultContainer.add("imagebox", rank[i], rankPos[i].x, rankPos[i].y, 144, 56, 592, 968, "image/resultBackground.bmp");
			break;
		case 4:
			resultContainer.add("imagebox", rank[i], rankPos[i].x, rankPos[i].y, 144, 56, 736, 968, "image/resultBackground.bmp");
			break;
		}
	}

	for(int i = 0; i < userNum; i++)
	{
		switch(userManager->getUser(i)->getSelectCharacter()->getKind())
		{
		case CHARACTER_KIND_BOY:
			resultContainer.add("imagebox", charface[i], charPos[i].x, charPos[i].y, 110, 115, 694, 768, "image/resultBackground.bmp");
			break;
		case CHARACTER_KIND_GIRL:
			resultContainer.add("imagebox", charface[i], charPos[i].x, charPos[i].y, 110, 115, 804, 768, "image/resultBackground.bmp");
			break;
		case CHARACTER_KIND_GIANT:
			resultContainer.add("imagebox", charface[i], charPos[i].x, charPos[i].y, 110, 115, 914, 768, "image/resultBackground.bmp");
			break;
		}
	}

	// ���� ���̵� ���
	for(int i = 0; i < userNum; i++)
	{
		m_userID[i] = new CPrintObject(IDPos[i].x, IDPos[i].y,15, userManager->getUser(i)->getName());
		CDrawManager::getInstance()->insertObject(DRAW_OBJECT_INTERFACE, m_userID[i]);
	}

	//{{ bakky ��Ʈ��ũ ó��
	m_dwInitTime	= timeGetTime();
	m_bReturnRoom	= FALSE;
	processNetworkPacket();
	//}}

	return true;
}
void CResultState::release()
{
	CUIManager& manager = CUIManager::getInstance();
	
	CDrawManager::getInstance()->eraseObject(DRAW_OBJECT_INTERFACE, manager.getUIDraw(0)->getOrder());

	for(int i = 0; i<m_userNum;i++)
		CDrawManager::getInstance()->eraseObject(DRAW_OBJECT_INTERFACE, m_userID[i]->getOrder());

	CDrawManager::getInstance()->eraseList();
	CUserManager::getInstance()->resetData();
}
void CResultState::onUpdate()
{
	//
	// ��Ʈ��ũ���� ��Ŷ�� �޾Ҵٸ�
	// �����ð��� ȭ�鿡 ����� �ؾ��Ѵ�.
	if( m_bReturnRoom )
	{
		DWORD dwCurrTime = timeGetTime();
		if( dwCurrTime - m_dwInitTime > MAX_RESULT_DISPLAY_TIME )
		{
			// ȭ�� ��ȯ
			// room state�� ��ȯ�Ѵ�...
			CGameManager::getInstance()->setState( GAME_STATE_ROOM );
		}
	}
}
void CResultState::onKeyboard(WPARAM _wParam)
{

}
void CResultState::processMouseMove()
{
}
void CResultState::onMouseLClick()
{

}


void CResultState::processNetworkPacket()
{
	// ��� ȭ�鿡 �ö� ���忡�� ���� �����ٰ� �޼����� ������.
	Packet packet( REQ_USER_GAMEEND );

	CMessageManager::getInstance()->sendMessageToClientServer( packet );
}

void CResultState::setReturnRoomFlag( BOOL bReturnRoom )
{
	m_bReturnRoom = bReturnRoom;
}
