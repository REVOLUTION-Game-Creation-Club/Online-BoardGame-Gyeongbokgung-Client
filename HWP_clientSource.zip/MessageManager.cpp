#include "stdafx.h"
#include "MessageManager.h"
#include "PlayState.h"
#include "RoomState.h"
#include "LobbyState.h"
#include "LocalState.h"
#include "NetworkState.h"

CMessageManager* CMessageManager::selfInstance = 0;

CMessageManager::CMessageManager()
{
	m_networkState	= new CNetworkState(this);
	m_localState	= new CLocalState(this);
	//m_nowState		= m_localState;
	m_nowState		= m_networkState;
}

CMessageManager::~CMessageManager()
{
	delete m_networkState;
	m_networkState = 0;
	delete m_localState;
	m_localState = 0;
}

CMessageManager* CMessageManager::getInstance()
{
	if( selfInstance == 0 )
		selfInstance = new CMessageManager();

	return selfInstance;
}

void CMessageManager::release()
{
	if( selfInstance != 0 )
	{
		selfInstance->cleanup();
		delete selfInstance;
		selfInstance = 0;
	}
}

bool CMessageManager::initialize()
{
	m_nowState->initialize();
	return true;
}

void CMessageManager::cleanup()
{
	m_nowState->cleanup();
}

void CMessageManager::processPacket()
{
	m_nowState->processPacket();
}

void CMessageManager::broadcast(Packet& _packet)
{
	m_nowState->broadcast(_packet);
}

void CMessageManager::sendMessageToClientServer(Packet& _packet)
{
	m_nowState->sendMessageToClientServer(_packet);
}

void CMessageManager::sendMessageToMainServer(Packet& _packet)
{
	m_nowState->sendMessageToMainServer(_packet);
}

bool CMessageManager::connectServer(char* _addr)
{
	return m_nowState->connectServer(_addr);
}
IMessageState* CMessageManager::getState(MESSAGE_STATE _messageState)
{
	switch(_messageState)
	{
	case MESSAGE_STATE_NOW:
		return m_nowState;
	case MESSAGE_STATE_NETWORK:
		return m_networkState;
	case MESSAGE_STATE_LOCAL:
		return m_localState;
	default:
		return NULL;
	}
}
void CMessageManager::setState(MESSAGE_STATE _messageState)
{
	if( _messageState == MESSAGE_STATE_NOW)
		return;

	switch(_messageState)
	{
	case MESSAGE_STATE_NETWORK:
		m_nowState =m_networkState;
	case MESSAGE_STATE_LOCAL:
		m_nowState =m_localState;
		break;
	default:
		break;
	}
}
