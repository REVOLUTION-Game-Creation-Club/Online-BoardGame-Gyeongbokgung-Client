#include "stdafx.h"
#include "User.h"

CUser::CUser()
{
	m_index					= 0;
	m_major					= false;
	strcpy_s(m_name,"");
	m_teamColor				= USER_TEAM_RED;
	m_completeNum			= 0;
	m_characterNum			= 0;
	m_selectCharacterNo		= 0;
	m_sleep					= false;
	m_rank					= 0;
	m_spacebarFlag			= true;
	m_startRulletFlag		= true;
	m_restFlag				= true;

	m_skipClickFlag			= false;
}

CUser::CUser(int _index, char* _name, USER_TEAM_COLOR _teamColor)
{
	m_index					= _index;
	m_major					= false;
	strcpy_s(m_name,_name);
	m_teamColor				= _teamColor;
	m_completeNum			= 0;
	m_characterNum			= 0;
	m_selectCharacterNo		= 0;
	m_sleep					= false;
	m_rank					= 0;
	m_major					= false;
//	strcpy_s(m_IP, "155.230.25.120"); // ����� �߰�����

	m_spacebarFlag			= true;
	m_startRulletFlag		= true;
	m_rulletClickFlag		= false;
	m_restFlag				= true;

	// ��ŵó�� 12.01 ����
	m_skipClickFlag			= false;
}

CUser::~CUser()
{
	if(m_characterNum == 1)
		delete m_characterList[0];
	else if(m_characterNum == 2)
	{
		delete m_characterList[0];
		delete m_characterList[1];
	}

	m_characterList.clear();
}

void CUser::insertCharacter(CCharacter* _character)
{
	m_characterList.push_back(_character);
//	m_characterNum++;
}

void CUser::eraseCharacter(int _where)
{
	m_characterList.erase(m_characterList.begin() + _where);
//	m_characterNum--;
}
void CUser::changeSelectCharacter()
{
	//{{ ���� 06.11.21
	if( getCharacterNum() !=2 )
		return;
	//{{
	if(m_selectCharacterNo == 0)
	{
		if(getCharacter(1)->isCarryCharacter()||getCharacter(1)->isComplete())
			return;

		m_selectCharacterNo = 1;
		setSelectCharacterNo(m_selectCharacterNo);
	}
	else
	{
		if(getCharacter(0)->isCarryCharacter()||getCharacter(0)->isComplete())
			return;

		m_selectCharacterNo = 0;
		setSelectCharacterNo(m_selectCharacterNo);
	}
}

CCharacter*	CUser::getSelectCharacter()
{
	return m_characterList[m_selectCharacterNo];
}