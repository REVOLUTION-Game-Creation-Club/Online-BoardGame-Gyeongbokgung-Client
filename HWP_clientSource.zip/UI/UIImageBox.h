#pragma once
#include "CUIControl.h"

class CUIImageBox : public CUIControl
{	
	int m_imageFlag;

	CUIImageBox();
public:
	CUIImageBox(string _name);
	CUIImageBox(string _name, int _x, int _y, int _width, int _height);
	CUIImageBox(string _name, int _x, int _y, int _width, int _height, int _texX, int _texY, char* _fileName);
	~CUIImageBox(void);	

	void setImageFlag(int _flag);
	void setImageState(int _flag = 0);

	void activeControl(int _state) { _state = 0;}
	void deactivate() {}
};
