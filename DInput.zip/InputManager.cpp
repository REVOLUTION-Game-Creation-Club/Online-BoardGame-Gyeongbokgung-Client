#include "InputManager.h"
#include "InputKeyboard.h"
#include "InputMouse.h"

namespace rev {

	CInputManager*	CInputManager::m_pInstance = NULL;

	CInputManager::CInputManager()
	{
		m_hWnd		= 0;

		m_lpDI		= NULL;
		m_pKeyboard	= NULL;
		m_pMouse	= NULL;
	}

	CInputManager::~CInputManager()
	{
	}

	bool CInputManager::initialize( HINSTANCE _hInst, HWND _hWnd )
	{
		m_hWnd	= _hWnd;

		HRESULT hr = DirectInput8Create( _hInst, DIRECTINPUT_VERSION  , IID_IDirectInput8, (void**)&m_lpDI, NULL );
		if( FAILED( hr ) )
		{
			return false;
		}

		m_pKeyboard	= new CInputKeyboard();
		m_pKeyboard->initialize( m_lpDI );

		m_pMouse	= new CInputMouse();
		m_pMouse->initialize( m_lpDI, _hWnd );

		POINT pt;
		GetCursorPos( &pt );
		ScreenToClient( _hWnd, &pt );
		m_pMouse->setMousePoint( pt.x, pt.y );

		return true;
	}

	bool CInputManager::destroy()
	{
		if( m_pKeyboard )
		{
			m_pKeyboard->destroy();
			delete m_pKeyboard;
		}

		if( m_pMouse )
		{
			m_pMouse->destroy();
			delete m_pMouse;
		}

		if( m_lpDI )
		{
			m_lpDI->Release();
			m_lpDI = NULL;
		}

		return true;
	}

	void CInputManager::process()
	{
		if( m_pKeyboard )	m_pKeyboard->process();
		if( m_pMouse	)	m_pMouse->process();
	}

	void CInputManager::active( bool _bActive )
	{
		if( m_pKeyboard )	m_pKeyboard->active( _bActive );
		if( m_pMouse	)	m_pMouse->active( _bActive );
	}

	bool CInputManager::createKeyboard( READ_DATA_STYLE _dwMode, int _nBufferSize, DINPUT_FLAGS _dwFlags, bool _bWinKeyEnable )
	{
		return m_pKeyboard->create( m_hWnd, _dwFlags, _dwMode, _nBufferSize, _bWinKeyEnable );
	}

	bool CInputManager::destroyKeyboard()
	{
		return m_pKeyboard->destroy();
	}

	bool CInputManager::createMouse( READ_DATA_STYLE _dwMode, int _nBufferSize, DINPUT_FLAGS _dwFlags )
	{
		return m_pMouse->create( m_hWnd, _nBufferSize, _dwFlags, _dwMode );
	}

	bool CInputManager::destroyMouse()
	{
		return m_pMouse->destroy();
	}

	void CInputManager::setKeyboardImmediateFunc( CallBackImmediateKeyboard _pfImmediate )
	{
		m_pKeyboard->setImmediateFunc( _pfImmediate );
	}

	void CInputManager::setKeyboardBufferedFunc( CallBackBufferedKeyboard _pfBuffered )
	{
		m_pKeyboard->setBufferedFunc( _pfBuffered );
	}

	void CInputManager::setMouseImmediateFunc( CallBackImmediateMouse _pfImmediate )
	{
		m_pMouse->setImmediateFunc( _pfImmediate );
	}

	//void CInputManager::setMouseBufferedFunc( CallBackBufferedMouse _pfBuffered )
	//{
	//	m_pMouse->setBufferedFunc( _pfBuffered );
	//}

	//
	void CInputManager::setMousePoint( int _x, int _y )	
	{
		m_pMouse->setMousePoint( _x, _y ); 
	}

	void CInputManager::getMousePoint( int& _x, int& _y ) 
	{
		m_pMouse->getMousePoint( _x, _y );
	}

	// 
	void CInputManager::setPointStyle( MOUSE_POINT_STYLE _style )
	{
		m_pMouse->setPointStyle( _style );
	}

	MOUSE_POINT_STYLE CInputManager::getPointStyle() const
	{
		return m_pMouse->getPointStyle();
	}

	void CInputManager::setCallBackBufferedMouseMove( CallBackBufferedMouseMove _pf)
	{
		m_pMouse->setCallBackBufferedMouseMove( _pf );
	}

	void CInputManager::setCallBackBufferedMouseUp( CallBackBufferedMouseUpDown  _pf )
	{
		m_pMouse->setCallBackBufferedMouseUp( _pf );
	}

	void CInputManager::setCallBackBufferedMouseDown( CallBackBufferedMouseUpDown  _pf )
	{
		m_pMouse->setCallBackBufferedMouseDown( _pf );
	}

};

