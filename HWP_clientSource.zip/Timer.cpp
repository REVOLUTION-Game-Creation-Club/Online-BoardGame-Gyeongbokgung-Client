#include "stdafx.h"
#include "Timer.h"

CTimer::CTimer(void)
{
	m_nStartTime = 0;
}

void CTimer::Start(void)
{
	m_nStartTime = GetTickCount();
}

long CTimer::Time(void)
{
	return GetTickCount() - m_nStartTime;
}

bool CTimer::Elapsed(long &start, long interval)
{
	long current_time = Time();
	if(current_time >= start + interval)
	{
		start = current_time;
		return true;
	}
	else 
		return false;
}
