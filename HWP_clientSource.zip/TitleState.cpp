#include "stdafx.h"
#include "TitleState.h"
#include "DrawManager.h"
#include "ui/CUIManager.h"
#include "MessageManager.h"
#include "UserManager.h"
#include "../RevSound/SoundManager.h"

class titleLisner : public Clistener
{
public:
	void action()
	{
		// ���� ���� Ȯ�� ������ ��
		if( getEvented().compare("disconnectedAcceptButton") == 0)
		{
			PostQuitMessage(0);
		}
	}

	void textChanged()
	{
		return;
	}

	void pressReturn() 
	{
		return;
	}
};


CTitleState::CTitleState(CGameManager* _gameManager)
{
	this->m_gameManager = _gameManager;

	m_listener = NULL;
}
CTitleState::~CTitleState()
{

}
bool CTitleState::initialize()
{
	m_connected = FALSE;

	getSoundManager()->play("����Ÿ��Ʋ");

	CUIManager& manager = CUIManager::getInstance();
	manager.makeContainer("titleContainer", 0, 0, 1024, 768, 0, 0, "image/title.bmp" );
	manager.getUIDraw(0)->setFileName("image/title.bmp");
	CDrawManager::getInstance()->insertObject(DRAW_OBJECT_INTERFACE,manager.getUIDraw(0));

	// ���� ������ �˾� ������ �����̳�
	m_listener = new titleLisner();
	manager.makeContainer("mainDisconnected", 257, 304, 510, 160, 0, 480, "image/lError.bmp");
	CUIContainer& mainDisconnected = manager["mainDisconnected"];
	mainDisconnected.add("button", "disconnectedAcceptButton", 476, 423, 72, 42, 0, 1024-42, "image/lError.bmp");
	mainDisconnected.getButton("disconnectedAcceptButton").setImageFlag(REV_NORMAL|REV_ROLLOVER);
	mainDisconnected["disconnectedAcceptButton"].addListener(m_listener);
	mainDisconnected.setEnable(FALSE);
	manager.getUIDraw(1)->setFileName("image/lError.bmp");
	CDrawManager::getInstance()->insertObject(DRAW_OBJECT_INTERFACE, (IDrawObject*)manager.getUIDraw(1));

	char buf[15];
	memset(buf, 0, sizeof(buf));
	FILE* fd;
	fd = fopen("config.cfg", "r");
	fread(buf, sizeof(buf), 1, fd);

	if( !CMessageManager::getInstance()->connectServer(buf) )
	{
		mainDisconnected.setEnable(TRUE);
	}
	else
	{
		m_connected = TRUE;
	}

	fclose(fd);

	Packet tempPacket(REQ_MainServer_Connect);
	char id[USER_ID_LENGTH];
	strcpy(id, CUserManager::getInstance()->getMyUserName());
	tempPacket << CUserManager::getInstance()->getMyUserName() << CUserManager::getInstance()->getMyUserIP();

	CMessageManager::getInstance()->sendMessageToMainServer(tempPacket);

	return true;
}
void CTitleState::release()
{
	getSoundManager()->stop("����Ÿ��Ʋ");

	CUIManager& manager = CUIManager::getInstance();
	CDrawManager::getInstance()->eraseObject(DRAW_OBJECT_INTERFACE, manager.getUIDraw(0)->getOrder());
	CDrawManager::getInstance()->eraseObject(DRAW_OBJECT_INTERFACE, manager.getUIDraw(1)->getOrder());
	CDrawManager::getInstance()->eraseList();

	//{{ bakky : Ÿ��Ʋȭ�鿡�� ����� �����̳� �޸� ����
	CUIManager::getInstance().destroyAllContainer();
	if( m_listener )
	{
		delete m_listener;
		m_listener = NULL;
	}
	//}}
}
void CTitleState::onUpdate()
{
	static DWORD count = 0;
	count++;

	if(count == 400 && m_connected)
	{
		count = 0;

		m_gameManager->setState(GAME_STATE_LOBBY);
	}
}
void CTitleState::onKeyboard(WPARAM _wParam)
{

}
void CTitleState::processMouseMove()
{

}
void CTitleState::onMouseLClick()
{

}