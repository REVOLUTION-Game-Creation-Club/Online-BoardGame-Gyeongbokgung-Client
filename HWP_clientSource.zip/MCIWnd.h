
#ifndef __MCI_WND_H__

#pragma comment( lib, "Vfw32.lib" )
#pragma comment( lib, "winmm.lib" )

// Video for windows included here so users of CMCIWnd don't have to...
#include <vfw.h>
#include <string>

/******************************************************************************
**
** CMCIWnd
**
******************************************************************************/
class CMCIWnd
{
protected :
	HWND m_hWnd;

public:
	HWND GetHwnd()	{ return m_hWnd;	}

	// Object Construction
	CMCIWnd();
	virtual ~CMCIWnd();
	BOOL Create(DWORD dwStyle, const RECT& rect, HWND hWndParent, UINT nID);
	BOOL Create(DWORD dwStyle, int x, int y, int w, int h, HWND hWndParent, HINSTANCE hInst );
	
	// Window Management
	void ChangeStyles(UINT nMask, long nValue);
	UINT GetStyles();
	void SetOwner(HWND hWndOwner);

	// File and Device Management
	void Close();
	void Destroy();
	long Eject();
	long New(LPCSTR strDeviceName);
	long Open(TCHAR* strFileName, UINT nFlags = 0);
	long OpenDialog();
	void OpenInterface(LPUNKNOWN pUnk);
	long Save(LPCSTR strFileName);
	long SaveDialog();

	// Playback Options
	BOOL GetRepeat();
	long Pause();
	long Play();
	long PlayFrom(long nPosition);
	long PlayFromTo(long nStart, long nEnd);
	long PlayReverse();
	long PlayTo(long nPosition);
	long Resume();
	void SetRepeat(BOOL bRepeat);
	long Stop();
	long SetDest( RECT& rect );

	// Recording
	long Record();

	// Positioning
	long End();
	long GetEnd();
	long GetLength();
	long GetPosition();
	long GetPositionString(std::string & strPosition, UINT nMaxPosStringLength = 1000);
	long GetStart();
	long Home();
	long Seek(long nPosition);
	long Step(long nSteps);

	// Performance Tuning
	long GetSpeed();
	long GetVolume();
	UINT GetZoom();
	long SetSpeed(UINT nSpeed);
	long SetVolume(UINT nVolume);
	void SetZoom(UINT nZoom);

	// Image and Palette Adjustments
	long GetDest(RECT & rect);
	HPALETTE GetPalette();
	long GetSource(RECT & rect);
	long PutDest(RECT& rect);
	long PutSource(RECT& rect);
	long Realize(BOOL bBackground);
	long SetPalette(HPALETTE hPalette);

	// Event and Error Notification
	long GetError(std::string & strError, UINT nMaxErrorStringLength = 1000);

	// Time Formats
	long GetTimeFormat(std::string & strTimeFormat, UINT nMaxFormatStringLength = 1000);
	long SetTimeFormat(LPCSTR strTimeFormat);
	long UseFrames();
	long UseTime();
	void ValidateMedia();

	// Status Updates
	UINT GetActiveTimer();
	UINT GetInactiveTimer();
	void SetActiveTimer(UINT nMilliseconds);
	void SetInactiveTimer(UINT nMilliseconds);
	void SetTimers(UINT nActive, UINT nInactive);

	// Device Capabilities
	BOOL CanConfig();
	BOOL CanEject();
	BOOL CanPlay();
	BOOL CanRecord();
	BOOL CanSave();
	BOOL CanWindow();

	// MCI Device Settings
	UINT GetAlias();
	long GetDevice(std::string & strDevName, UINT nMaxDevNameLength = 1000);
	UINT GetDeviceID();
	long GetFileName(std::string & strFilename, UINT nMaxFilenameLength = 1000);
	long GetMode(std::string & strMode, UINT nMaxModeLength = 1000);

	// MCI Command-String Interface
	long ReturnString(std::string & strReply, UINT nMaxReplyStringLength = 1000);
	long SendString(LPCSTR strCommand);


protected:

};

#endif	//__MCI_WND_H__