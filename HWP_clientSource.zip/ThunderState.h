#ifndef __ThunderState_h__
#define __ThunderState_h__
#include "ICharacterState.h"
#include "Character.h"
#define	CHARACTER_SPRITE_THUNDER 6
class CThunderState : public ICharacterState
{
private:
	CCharacter*				m_character;
	int						m_count;
	int		m_sizeX;
	int		m_sizeY;
	RECT	m_rectOrig;
	CCharacter* m_pSwapChar;

public:
	CThunderState(CCharacter* _character);
	virtual					~CThunderState();
	void					stateStart();
	void					stateEnd();
	void					draw(DWORD _timeDelta);
	void					drawThunderCharacter();

	void setSwapChar( CCharacter* pSwapChar );
};

#endif