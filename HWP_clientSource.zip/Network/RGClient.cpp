// RGClient.cpp: implementation of the RGClient class.
//
//////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <time.h>
#include "RGClient.h"
// #include "PacketLog.h"

// extern CPacketLog g_packetLog;

#define WM_RGERRMSG WM_USER+100
#define WM_CHAT WM_USER+101
#define WM_GAMEMODE	WM_USER+205

#define GM_LOGO					0	//	�ΰ�		
#define GM_LOGIN				1	//	�α� 
#define GM_CHANNEL				2	//	ä��
#define GM_WAITROOM				3	//	����	
#define GM_GAMEROOM				4	//	���ӹ�
#define GM_PLAYGAME				5	//	����


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

RGClient* RGClient::m_pThis = NULL;

void RGClient::CreateInstance( void )
{
	if( m_pThis ) return;
//	g_packetLog.openFile();
	m_pThis = new RGClient;
}

RGClient* RGClient::GetInstance( void )
{
	if( !m_pThis ) CreateInstance();
	
	return m_pThis;
}
void RGClient::DeleteInstance( void )
{
//	g_packetLog.closeFile();
	delete m_pThis;
}
RGClient::RGClient()
{
	initPacket( (LPP_COMMON)&tos_req_enter_lobby,	TOS_REQ_ENTER_LOBBY,	sizeof( tos_req_enter_lobby ) );
	initPacket( (LPP_COMMON)&tos_req_enter_room,	TOS_REQ_ENTER_ROOM,		sizeof( tos_req_enter_room ) );
	initPacket( (LPP_COMMON)&tos_req_make_room,		TOS_REQ_MAKE_ROOM,		sizeof( tos_req_make_room ) );
	initPacket( (LPP_COMMON)&tos_ntf_exit_game,		TOS_NTF_EXIT_GAME,		sizeof( tos_ntf_exit_game ) );
	initPacket( (LPP_COMMON)&tos_ntf_user_state,	TOS_NTF_USER_STATE,		sizeof( tos_ntf_user_state ) );
	initPacket( (LPP_COMMON)&tos_ntf_update_room,	TOS_NTF_UPDATE_ROOM,	sizeof( tos_ntf_update_room ) );
	initPacket( (LPP_COMMON)&tos_ntf_chat_lobby,	TOS_NTF_CHAT_LOBBY,		sizeof( tos_ntf_chat_lobby ) );
	initPacket( (LPP_COMMON)&tor_req_enter_room,	TOR_REQ_ENTER_ROOM,		sizeof( tor_req_enter_room ) );
	initPacket( (LPP_COMMON)&tor_req_update_user,	TOR_REQ_UPDATE_USER,	sizeof( tor_req_update_user ) );
	initPacket( (LPP_COMMON)&tor_ntf_exit_room,		TOR_NTF_EXIT_ROOM,		sizeof( tor_ntf_exit_room ) );
	initPacket( (LPP_COMMON)&tor_ntf_chat_room,		TOR_NTF_CHAT_ROOM,		sizeof( tor_ntf_chat_room ) );
	initPacket( (LPP_COMMON)&tom_ack_enter_room,	TOM_ACK_ENTER_ROOM,		sizeof( tom_ack_enter_room ) );
	initPacket( (LPP_COMMON)&tom_ack_update_user,	TOM_ACK_UPDATE_USER,	sizeof( tom_ack_update_user ) );
	initPacket( (LPP_COMMON)&tom_ntf_update_room,	TOM_NTF_UPDATE_ROOM,	sizeof( tom_ntf_update_room ) );
	initPacket( (LPP_COMMON)&tom_ntf_chat_room,		TOM_NTF_CHAT_ROOM,		sizeof( tom_ntf_chat_room ) );
	initPacket( (LPP_COMMON)&tom_ntf_start_game,	TOM_NTF_START_GAME,		sizeof( tom_ntf_start_game ) );
	initPacket( (LPP_COMMON)&tom_ntf_update_state,	TOM_NTF_UPDATE_STATE,	sizeof( tom_ntf_update_state ) );
	initPacket( (LPP_COMMON)&tom_req_user_state,	TOM_REQ_USER_STATE,		sizeof( tom_req_user_state ) );

	/////////////////////////////////////////////// 050522(��) ��ŷ ���� A - ���
	initPacket( (LPP_COMMON)&tom_ntf_change_score,	TOM_NTF_CHANGE_SCORE,	sizeof( tom_ntf_change_score ) ); //�ٲ������� ����鿡�� ���� : 050505 ���
	initPacket(	(LPP_COMMON)&tos_req_update_score,	TOS_REQ_UPDATE_SCORE,	sizeof( tos_req_update_score) );
	initPacket(	(LPP_COMMON)&tos_req_top10_rank,	TOS_REQ_TOP10_RANK,		sizeof( tos_req_top10_rank) );
	initPacket(	(LPP_COMMON)&tos_req_user_rank,		TOS_REQ_USER_RANK,		sizeof( tos_req_user_rank) );
	/************************************************************************/
	memset( m_ltRoom, 0, sizeof(ROOM)*MAX_ROOM );
	memset( m_ltUser, 0, sizeof(USER)*MAX_USER );

	m_dwUserCount = 0;
	m_dwRoomCount = 0;

	m_sRNUSCount = 0;
	memset( &m_gRoom, 0, sizeof( GROOM ) );		
	memset( m_ltgRUser, 0, sizeof( GRUSER ) * 4 );

	m_dwUserIndex = 0;
	m_dwMajorIndex = 0;

	m_bMajor = FALSE;
	m_bStartGame = FALSE;
	m_dwExitCount = 0;
	/////////////////////////////////////////////// 050522(��) ��ŷ ���� A - ���
	m_dwPlusScore[0] = 0;
	m_dwPlusScore[1] = 0;
	m_dwPlusScore[2] = 0;
	m_dwPlusScore[3] = 0;
	isCal = false;
	isSend = false;
}

RGClient::~RGClient()
{

}
void 
RGClient::init( HWND hWnd, SOCKET hSock, SOCKADDR_IN addr )
{
	m_hWnd			= hWnd;
	m_hSock			= hSock;
	m_addrServer	= addr;
}

void 
RGClient::initUser( char* strID, char* strName, DWORD dwScore )
{
	if( !strID || !strName )
	{
		return;
	}

	strcpy( m_myUser.strID,	strID );
	strcpy( m_myUser.strName, strName );
	m_myUser.dwScore = dwScore;
	m_myUser.rgState = IN_LOBBY;
}

void 
RGClient::procTocAckEnterLobby( LPP_TOC_ACK_ENTER_LOBBY msg )
{
//	g_packetLog.procTocAckEnterLobby(msg);
	if( msg->err != NO_ERR )
	{
		SendMessage( m_hWnd, WM_RGERRMSG, (WPARAM)&msg->strMessage, NULL );
	}

	memset( m_ltRoom, 0, sizeof(ROOM)*MAX_ROOM );
	memset( m_ltUser, 0, sizeof(USER)*MAX_USER );

	m_dwUserCount = 0;
	m_dwRoomCount = 0;

	SendMessage(m_hWnd, WM_GAMEMODE, GM_WAITROOM, NULL);
}
void 
RGClient::procTocAckEnterRoom( LPP_TOC_ACK_ENTER_ROOM msg )
{
//	g_packetLog.procTocAckEnterRoom(msg);
	if( msg->err != NO_ERR )
	{
		SendMessage( m_hWnd, WM_RGERRMSG, (WPARAM)&msg->strMessage, NULL );
	}
	else
	{
		sendTorReqEnterRoom( msg->sockAddr );
	}
}

void 
RGClient::procTocAckMakeRoom( LPP_TOC_ACK_MAKE_ROOM msg )
{
//	g_packetLog.procTocAckMakeRoom(msg);
	if( msg->err != NO_ERR )
	{
		SendMessage( m_hWnd, WM_RGERRMSG, (WPARAM)&msg->strMessage, NULL );
	}
	else
	{
		sendTosNtfUserState( IN_ROOM );

		memset( &m_gRoom, 0, sizeof( GROOM ) );		
		memset( m_ltgRUser, 0, sizeof( GRUSER ) * 4 );

		m_ltgRUser[0].user	= m_myUser;
		m_ltgRUser[0].byMajor = 1;
		m_ltgRUser[0].rgrState = RU_NOREADY_S;
		m_ltgRUser[0].ipaddr	= msg->sockAddr;
		
		// ������ �����Ǹ� �����Ѵ�.
		m_gRoom.room = msg->makeRoom;
		
		// ������ �����Ƿ�
		m_gRoom.room.dwJoinUserCount = 1;

		// �ʱ� �� ������ �����̴�
		m_gRoom.dwMap = 10;

		m_bMajor = TRUE;

		sendTosNtfUpdateRoom( INSERT_T );
		SendMessage(m_hWnd , WM_GAMEMODE, GM_GAMEROOM, NULL);
	}
}

void 
RGClient::procTocNtfRoomList( LPP_TOC_NTF_ROOM_LIST msg )
{
//	g_packetLog.procTocNtfRoomList(msg);
	memcpy( &m_ltRoom[ msg->dwPage * 10], msg->listRoom, sizeof( ROOM )*10 );
	m_dwRoomCount = msg->dwRoomCount;
}

void 
RGClient::procTocNtfUserList( LPP_TOC_NTF_USER_LIST msg )
{
//	g_packetLog.procTocNtfUserList(msg);
	memcpy( &m_ltUser[ msg->dwPage * 10], msg->listUser, sizeof( USER )*10 );
	m_dwUserCount = msg->dwUserCount;
}

void 
RGClient::procTocNtfUpdateRoom( LPP_TOC_NTF_UPDATE_ROOM msg )
{
//	g_packetLog.procTocNtfUpdateRoom(msg);
	int i;
	switch( msg->rgUpdateType )
	{
	case INSERT_T:
		// ROOM ����Ʈ �߿� �� ����Ʈ�� ����ϰ� 
		for( i = 0; i < MAX_ROOM; i++ )
		{
			// �� ����Ʈ�� �ִٸ� ( ������ �� ������ 0 �϶��̴� )
			if( m_ltRoom[i].dwKey == 0 )
			{
				m_ltRoom[i] = msg->updateRoom;
				m_dwRoomCount++;
				break;
			}
		}
		break;
	case MODIFY_T:
		// ROOM ����Ʈ �߿� �� ����Ʈ�� ����ϰ� 
		for( i = 0; i < MAX_ROOM; i++ )
		{
			// �� ����Ʈ�� �ִٸ� ( ������ �� ������ 0 �϶��̴� )
			if( m_ltRoom[i].dwKey == msg->updateRoom.dwKey )
			{
				m_ltRoom[i] = msg->updateRoom;
				break;
			}
		}
		break;
	case DELETE_T:
		// ROOM ����Ʈ �߿� �� ����Ʈ�� ����ϰ� 
		for( i = 0; i < MAX_ROOM; i++ )
		{
			// �� ����Ʈ�� �ִٸ� ( ������ �� ������ 0 �϶��̴� )
			if( m_ltRoom[i].dwKey == msg->updateRoom.dwKey )
			{
				m_ltRoom[i].dwKey = 0;
				m_dwRoomCount--;
				break;
			}
		}
		break;
	}
}
void 
RGClient::procTocNtfUpdateUser( LPP_TOC_NTF_UPDATE_USER msg )
{
//	g_packetLog.procTocNtfUpdateUser(msg);

	int i;
	switch( msg->rgUpdateType )
	{
	case INSERT_T:
		for( i = 0; i < MAX_USER; i++ )
		{
			if( m_ltUser[i].strID[0] == NULL )
			{
				m_ltUser[i] = msg->updateUser;
				m_dwUserCount++;
				break;
			}
		}
		break;
	case MODIFY_T:
		for( i = 0; i < MAX_USER; i++ )
		{
			if( !strcmp( m_ltUser[i].strID, msg->updateUser.strID ) )
			{
				m_ltUser[i] = msg->updateUser;
				break;
			}
		}
		break;
	case DELETE_T:
		for( i = 0; i < MAX_USER; i++ )
		{
			if( !strcmp( m_ltUser[i].strID, msg->updateUser.strID ) )
			{
				m_ltUser[i].strID[0] = NULL;
				m_dwUserCount--;
				break;
			}
		}
		break;
	}
}
void 
RGClient::procTocNtfServerState( LPP_TOC_NTF_SERVER_STATE msg )
{
//	g_packetLog.procTocNtfServerState(msg);
}

void 
RGClient::procTocNtfChatLobby( LPP_TOC_NTF_CHAT_LOBBY msg )
{
//	g_packetLog.procTocNtfChatLobby(msg);

	SendMessage(m_hWnd , WM_CHAT, (WPARAM)&msg->strMessage, NULL);
}

void 
RGClient::procTorReqEnterRoom( LPP_TOR_REQ_ENTER_ROOM msg )
{
//	g_packetLog.procTorReqEnterRoom(msg);

	int i; 
	for( i = 0; i < 4; i++ )
	{
		if( m_ltgRUser[i].rgrState == RU_NONE_S )
		{
			memset(&m_ltgRUser[i], 0, sizeof(m_ltgRUser[i]));
			break;
		}
	}
	
	if( i == 4 )
	{
		sendTomAckEnterRoom( msg->hdr.sockAddr, ENTER_ROOM_ERR, "�濡 �� �� �����ϴ�" );
	}
	else
	{
		m_ltgRUser[i].user = msg->user;
		m_ltgRUser[i].byMajor = 0;
		m_ltgRUser[i].rgrState = RU_NOREADY_S;
		m_ltgRUser[i].ipaddr = msg->hdr.sockAddr;
		sendTomAckEnterRoom( msg->hdr.sockAddr, NO_ERR, NULL );

		checkUserCount();
		sendTosNtfUpdateRoom( MODIFY_T );
		sendTomNtfUpdateRoom();
	}
}
void 
RGClient::procTorReqUpdateUser( LPP_TOR_REQ_UPDATE_USER msg )
{
//	g_packetLog.procTorReqUpdateUser(msg);

	int i; 
	for( i = 0; i < 4; i++ )
	{
		if( !strcmp( m_ltgRUser[i].user.strID, msg->grUser.user.strID ) )
		{
			m_ltgRUser[i] = msg->grUser;
			m_ltgRUser[i].ipaddr = msg->hdr.sockAddr;
			break;
		}
	}
	
	if( i == 4 )
	{
		sendTomAckEnterRoom( msg->hdr.sockAddr, ENTER_ROOM_ERR, "���� �� �� �����ϴ�" );
	}
	else
	{
		sendTomNtfUpdateRoom();
	}
}

void 
RGClient::procTorNtfExitRoom( LPP_TOR_NTF_EXIT_ROOM msg )
{
//	g_packetLog.procTorNtfExitRoom(msg);

	int i; 
	for( i = 0; i < 4; i++ )
	{
		if( !strcmp( m_ltgRUser[i].user.strID, msg->user.strID ) )
		{
			memset( &m_ltgRUser[i], 0, sizeof( GRUSER ) );			
			break;
		}
	}

	checkUserCount();
	sendTosNtfUpdateRoom( MODIFY_T );
	sendTomNtfUpdateRoom();
}

void 
RGClient::procTorNtfChatRoom( LPP_TOR_NTF_CHAT_ROOM msg )
{
//	g_packetLog.procTorNtfChatRoom(msg);

	sendTomNtfChatRoom( msg->strMessage );
}

void 
RGClient::procTomAckEnterRoom( LPP_TOM_ACK_ENTER_ROOM msg )
{
//	g_packetLog.procTomAckEnterRoom(msg);

	if( msg->err != NO_ERR )
	{
		SendMessage( m_hWnd, WM_RGERRMSG, (WPARAM)&msg->strMessage, NULL );
	}
	else
	{
		initRoom();
		sendTosNtfUserState( IN_ROOM );		// �������� ������ �濡 ������ �˸���.
		SendMessage(m_hWnd , WM_GAMEMODE, GM_GAMEROOM, NULL);
	}
}
void 
RGClient::procTomAckUpdateUser( LPP_TOM_ACK_UPDATE_USER msg )
{	
//	g_packetLog.procTomAckUpdateUser(msg);

	if( msg->err != NO_ERR )
	{
		SendMessage( m_hWnd, WM_RGERRMSG, (WPARAM)&msg->strMessage, NULL );
	}
}

void 
RGClient::procTomNtfUpdateRoom( LPP_TOM_NTF_UPDATE_ROOM msg )
{
//	g_packetLog.procTomNtfUpdateRoom(msg);

	m_gRoom = msg->gRoom;
	memcpy( m_ltgRUser, msg->ltgrUser, sizeof( GRUSER ) * 4 );

	for( int i = 0; i < 4; i++ )
	{
		// ���� �����̸�
		//
		if( !strcmp( m_myUser.strID, m_ltgRUser[i].user.strID ) && m_ltgRUser[i].byMajor )
		{
			setMajor( TRUE );
			setMajorIndex( i );
		}
	}
}

void 
RGClient::procTomNtfChatRoom( LPP_TOM_NTF_CHAT_ROOM msg )
{
//	g_packetLog.procTomNtfChatRoom(msg);

	SendMessage(m_hWnd , WM_CHAT, (WPARAM)&msg->strMessage, NULL);
}

void 
RGClient::procTomNtfStartGame( LPP_TOM_NTF_START_GAME msg )
{
//	g_packetLog.procTomNtfStartGame(msg);
	//msg->gRoom.dwMap
	////////////////////////�� /////////////////////

	for( int i = 0; i < 4; i++)
	{
		m_ltgRUser[i].bySnakeKind = msg->ltgrUser[i].bySnakeKind;
	}

    /************************************************************************/
    /* 050522(��) ��ŷ ���� A - ��� ������ ����ߴ���, ���´��� �ʱ�ȭ
    /************************************************************************/
	getClient()->isCal = false;
	getClient()->isSend = false;

	////////////////////////�� /////////////////////
	getClient()->sendTosNtfUserState( IN_GAME );	// �������� �������� ���·� ��Ÿ����.
	Sleep(3000);

	/************************************************************************/
	/* ������ : ����                                                        */
	/************************************************************************/
	
	SendMessage(m_hWnd, WM_GAMEMODE, GM_PLAYGAME, (LPARAM)msg->gRoom.dwMap);
	/************************************************************************/
	/* ���� ������ �˸��� ���ν��� �Դϴ�. 
	   �濡���� ������ ������, �� ������ CMainFrame ��ü�� �Ѱ����� ���մϴ�.
	   �׷��� �޼����� �ٶ� LPARAM���� �� ��ȣ�� �Ѱ��ݴϴ�.
	   ���� : CMainFrame::OnGameMode
	/************************************************************************/
	
}

void
RGClient::procTomNtfUpdateState( LPP_TOM_NTF_UPDATE_STATE msg )
{
	for( int i = 0; i < 4 ; i++ )
	{
		if(!strcmp(m_ltgRUser[i].user.strID,msg->user.strID))
		{
			m_ltgRUser[i].user.rgState = msg->user.rgState;
		}
	}
}

void 
RGClient::procTomReqUserState( LPP_TOM_REQ_USER_STATE msg )
{
	sendTomNtfUpdateState();
}
////////////////////////////////////////////////////////050522(��) ��ŷ ���� A - ���
void
RGClient::procTomNtfChangeScore( LPP_TOM_NTF_CHANGE_SCORE msg)
{
	/************************************************************************/
	/* �޾����� Ȯ��
	/************************************************************************/
	isSend = true;	

	for( int i = 0; i < 4; i++)
	{
		memcpy( &m_ltgRUser[i], &(msg->ltgrUser[i]), sizeof(msg->ltgrUser[i]) );		
	}

	/************************************************************************/
	/* �� ������ ����
	/************************************************************************/
	for( i = 0; i < 4; i ++)
	{
		if( !strcmp(m_ltgRUser[i].user.strID, m_myUser.strID) )
			m_myUser.dwScore = m_ltgRUser[i].user.dwScore;
	}

	sendTosReqUpdateScore();
}
////////////////////////////////////////////////////////

void 
RGClient::msgProc(LPP_COMMON lppCommon)
{
	switch( lppCommon->common_hdr.rpType )
	{
	case TOC_ACK_ENTER_LOBBY:	procTocAckEnterLobby	( & lppCommon->p_toc_ack_enter_lobby ); break;
	case TOC_ACK_ENTER_ROOM:	procTocAckEnterRoom		( & lppCommon->p_toc_ack_enter_room );	break;
	case TOC_ACK_MAKE_ROOM:		procTocAckMakeRoom		( & lppCommon->p_toc_ack_make_room );	break;
	case TOC_NTF_ROOM_LIST:		procTocNtfRoomList		( & lppCommon->p_toc_ntf_room_list );	break;
	case TOC_NTF_USER_LIST:		procTocNtfUserList		( & lppCommon->p_toc_ntf_user_list );	break;
	case TOC_NTF_UPDATE_ROOM:	procTocNtfUpdateRoom	( & lppCommon->p_toc_ntf_update_room ); break;
	case TOC_NTF_UPDATE_USER:	procTocNtfUpdateUser	( & lppCommon->p_toc_ntf_update_user ); break;
	case TOC_NTF_SERVER_STATE:	procTocNtfServerState	( & lppCommon->p_toc_ntf_server_state );break;
	case TOC_NTF_CHAT_LOBBY:	procTocNtfChatLobby		( & lppCommon->p_toc_ntf_chat_lobby );	break;
	case TOR_REQ_ENTER_ROOM:	procTorReqEnterRoom		( & lppCommon->p_tor_req_enter_room );	break;
	case TOR_REQ_UPDATE_USER:	procTorReqUpdateUser	( & lppCommon->p_tor_req_update_user ); break;
	case TOR_NTF_EXIT_ROOM:		procTorNtfExitRoom		( & lppCommon->p_tor_ntf_exit_room );	break;
	case TOR_NTF_CHAT_ROOM:		procTorNtfChatRoom		( & lppCommon->p_tor_ntf_chat_room );	break;
	case TOM_ACK_ENTER_ROOM:	procTomAckEnterRoom		( & lppCommon->p_tom_ack_enter_room );	break;
	case TOM_ACK_UPDATE_USER:	procTomAckUpdateUser	( & lppCommon->p_tom_ack_update_user ); break;
	case TOM_NTF_UPDATE_ROOM:	procTomNtfUpdateRoom	( & lppCommon->p_tom_ntf_update_room ); break;
	case TOM_NTF_CHAT_ROOM:		procTomNtfChatRoom		( & lppCommon->p_tom_ntf_chat_room );	break;
	case TOM_NTF_START_GAME:	procTomNtfStartGame		( & lppCommon->p_tom_ntf_start_game );	 break;
	case TOM_NTF_UPDATE_STATE:	procTomNtfUpdateState	( & lppCommon->p_tom_ntf_update_state );break;
	case TOM_REQ_USER_STATE:	procTomReqUserState		( & lppCommon->p_tom_req_user_state	);	break;
	//////////////////////////////////////////////////////// 050522(��) ��ŷ ���� A - ���	
	case TOC_ACK_UPDATE_SCORE:	procTocAckUpdateScore	( & lppCommon->p_toc_ack_update_score );	break;
	case TOC_ACK_TOP10_RANK:	procTocAckTop10Score	( &	lppCommon->p_toc_ack_top10_rank );	break;
	case TOC_ACK_USER_RANK:		procTocAckUserRank		( & lppCommon->p_toc_ack_user_rank	);	break;
	case TOM_NTF_CHANGE_SCORE:	procTomNtfChangeScore	( & lppCommon->p_tom_ntf_change_score );	break;
	/************************************************************************/
	default:
		{
			int i =0;
			i=i;
		}
		break;
	}
}

void 
RGClient::sendTosNtfUserState( RGUSERSTATE state )
{
	m_myUser.rgState = state;

	strcpy( tos_ntf_user_state.strUserID, m_myUser.strID );
	tos_ntf_user_state.rgUserState = m_myUser.rgState;

//	g_packetLog.sendTosNtfUserState( tos_ntf_user_state );
	sendto( m_hSock, (char*)&tos_ntf_user_state, tos_ntf_user_state.hdr.dwLength, 0, (SOCKADDR*)&m_addrServer, sizeof(m_addrServer) );
}

void 
RGClient::sendTosReqEnterRoom( DWORD dwRoomKey )
{
	strcpy( tos_req_enter_room.strUserID,	m_myUser.strID );
	tos_req_enter_room.dwRoomKey = dwRoomKey;

//	g_packetLog.sendTosReqEnterRoom(tos_req_enter_room);
	sendto( m_hSock, (char*)&tos_req_enter_room, tos_req_enter_room.hdr.dwLength, 0, (SOCKADDR*)&m_addrServer, sizeof(m_addrServer) );
}

void 
RGClient::sendTosReqEnterLobby( void )
{
	strcpy( tos_req_enter_lobby.strUserID,		m_myUser.strID );
	strcpy( tos_req_enter_lobby.strUserName,	m_myUser.strName );
	tos_req_enter_lobby.dwScore = m_myUser.dwScore;
	/************************************************************************/
	/* ���������� DB���� �����´� 050521(��) - ���
	/************************************************************************/
	sendTosReqUserRank();

//	g_packetLog.sendTosReqEnterLobby(tos_req_enter_lobby);
	sendto( m_hSock, (char*)&tos_req_enter_lobby, tos_req_enter_lobby.hdr.dwLength, 0, (SOCKADDR*)&m_addrServer, sizeof(m_addrServer) );
}


void 
RGClient::sendTosReqMakeRoom( char* strRoomName )
{
	/*
	strcpy( tos_req_make_room.strUserName, m_myUser.strName );
	strcpy( tos_req_make_room.strRoomName, strRoomName );*/

	/* ���� ���ڼ� ���� : 050502 ��� */
	strcpy( tos_req_make_room.strUserName, m_myUser.strName );

	if( strlen(strRoomName) >= 24 )
		strncpy(tos_req_make_room.strRoomName, strRoomName, 24);
	else	
		strcpy( tos_req_make_room.strRoomName, strRoomName );


	tos_req_make_room.dwMaxUserCount = 4;
	memset( tos_req_make_room.strPassword, 0, sizeof( tos_req_make_room.strPassword ) );

//	g_packetLog.sendTosReqMakeRoom(tos_req_make_room);
	sendto( m_hSock, (char*)&tos_req_make_room, tos_req_make_room.hdr.dwLength, 0, (SOCKADDR*)&m_addrServer, sizeof(m_addrServer) );
}

void 
RGClient::sendTosNtfExitGame( void )
{
	strcpy( tos_ntf_exit_game.strUserID, m_myUser.strID );
	tos_ntf_exit_game.rgUserState = IN_LOBBY;

//	g_packetLog.sendTosNtfExitGame(tos_ntf_exit_game);
	sendto( m_hSock, (char*)&tos_ntf_exit_game, tos_ntf_exit_game.hdr.dwLength, 0, (SOCKADDR*)&m_addrServer, sizeof(m_addrServer) );
}

void 
RGClient::sendTosNtfChatLobby( const char* strMessage )
{
	strcpy( tos_ntf_chat_lobby.strMessage, strMessage );

//	g_packetLog.sendTosNtfChatLobby(tos_ntf_chat_lobby);
	sendto( m_hSock, (char*)&tos_ntf_chat_lobby, tos_ntf_chat_lobby.hdr.dwLength, 0, (SOCKADDR*)&m_addrServer, sizeof(m_addrServer) );
}

void 
RGClient::sendTosNtfUpdateRoom( RGUPDATETYPE type )
{
	tos_ntf_update_room.rgUpdateType = type;
	tos_ntf_update_room.updateRoom = m_gRoom.room;

//	g_packetLog.sendTosNtfUpdateRoom(tos_ntf_update_room);
	sendto( m_hSock, (char*)&tos_ntf_update_room, tos_ntf_update_room.hdr.dwLength, 0, (SOCKADDR*)&m_addrServer, sizeof(m_addrServer) );
}

void
RGClient::sendTorReqEnterRoom( SOCKADDR_IN addrRoom )
{
	tor_req_enter_room.user = m_myUser;

//	g_packetLog.sendTorReqEnterRoom(tor_req_enter_room);
	sendto( m_hSock, (char*)&tor_req_enter_room, tor_req_enter_room.hdr.dwLength, 0, (SOCKADDR*)&addrRoom, sizeof(addrRoom) );
}

void 
RGClient::sendTorReqUpdateUser( GRUSER grUser )
{
	tor_req_update_user.grUser = grUser;
	
	int i; 
	for( i = 0; i < 4; i++ )
	{
		if( m_ltgRUser[i].rgrState != RU_NONE_S && m_ltgRUser[i].byMajor )
		{
//			g_packetLog.sendTorReqUpdateUser(tor_req_update_user);
			sendto( m_hSock, (char*)&tor_req_update_user, tor_req_update_user.hdr.dwLength, 0, 
					(SOCKADDR*)&m_ltgRUser[i].ipaddr, sizeof(m_ltgRUser[i].ipaddr) );
			break;
		}
	}	
}

void
RGClient::sendTorNtfExitRoom( void )
{
	tor_ntf_exit_room.user = m_myUser;

	int i; 
	for( i = 0; i < 4; i++ )
	{
		if( m_ltgRUser[i].rgrState != RU_NONE_S && m_ltgRUser[i].byMajor )
		{
//			g_packetLog.sendTorNtfExitRoom(tor_ntf_exit_room);
			sendto( m_hSock, (char*)&tor_ntf_exit_room, tor_ntf_exit_room.hdr.dwLength, 0, 
					(SOCKADDR*)&m_ltgRUser[i].ipaddr, sizeof(m_ltgRUser[i].ipaddr) );		
			break;
		}
	}
}
	
void 
RGClient::sendTorNtfChatRoom( const char* strMessage )
{
	strcpy( tor_ntf_chat_room.strMessage, strMessage );

	int i; 
	for( i = 0; i < 4; i++ )
	{
		if( m_ltgRUser[i].rgrState != RU_NONE_S && m_ltgRUser[i].byMajor )
		{
//			g_packetLog.sendTorNtfChatRoom(tor_ntf_chat_room);
			sendto( m_hSock, (char*)&tor_ntf_chat_room, tor_ntf_chat_room.hdr.dwLength, 0, 
					(SOCKADDR*)&m_ltgRUser[i].ipaddr, sizeof(m_ltgRUser[i].ipaddr) );		
			break;
		}
	}
}

void
RGClient::sendTomNtfUpdateState( void )
{
	tom_ntf_update_state.user = m_myUser;

	for(int i = 0 ; i < 4 ; i++ )
	{
		sendto( m_hSock, (char*)&tom_ntf_update_state, tom_ntf_update_state.hdr.dwLength, 0,
			(SOCKADDR*)&m_ltgRUser[i].ipaddr, sizeof(m_ltgRUser[i].ipaddr) );		
	}
}

void 
RGClient::sendTomNtfStartGame( void )
{
	/************************************************************************/
	/* 050522(��) ��ŷ ���� A - ��� ������ ����ߴ���, ���´��� �ʱ�ȭ
	/************************************************************************/
	isCal = false;
	isSend = false;
	sendTomNtfChatRoom("...������ �����մϴ�");
	
	int i; 

	////////////////////////�� /////////////////////

	for( i = 0; i < 4; i++ )
	{
		if(m_ltgRUser[i].bySnakeKind == 7 )
            m_ltgRUser[i].bySnakeKind = rand()%7;
	}
	////////////////////////�� /////////////////////
	memcpy( tom_ntf_start_game.ltgrUser, m_ltgRUser, sizeof( GRUSER ) * 4 );
	tom_ntf_start_game.gRoom = m_gRoom;
	
	for( i = 0; i < 4; i++ )
	{
		if( m_ltgRUser[i].rgrState != RU_NONE_S )	// ������ �����߿� �������� �ʴ´ٸ�
		{
//			g_packetLog.sendTomNtfStartGame(tom_ntf_start_game);
			sendto( m_hSock, (char*)&tom_ntf_start_game, tom_ntf_start_game.hdr.dwLength, 0, 
					(SOCKADDR*)&m_ltgRUser[i].ipaddr, sizeof(m_ltgRUser[i].ipaddr) );			

			// recv ��Ŷ�� �б�� �޾� �Ҽ� ���� �ι� ���� 
//			sendto( m_hSock, (char*)&tom_ntf_start_game, tom_ntf_start_game.hdr.dwLength, 0, 
//			(SOCKADDR*)&m_ltgRUser[i].ipaddr, sizeof(m_ltgRUser[i].ipaddr) );			
		}
	}
}
void
RGClient::sendTomNtfChangeScore()
{	
	memcpy( tom_ntf_change_score.ltgrUser, m_ltgRUser, sizeof( GRUSER ) * 4 );

	int i; 
	for( i = 0; i < 4; i++ )
	{
		if( !m_ltgRUser[i].byMajor )
		{
			sendto( m_hSock, (char*)&tom_ntf_change_score, tom_ntf_change_score.hdr.dwLength, 0, 
				(SOCKADDR*)&m_ltgRUser[i].ipaddr, sizeof(m_ltgRUser[i].ipaddr) );			
		}
	}
}

void 
RGClient::sendTomAckEnterRoom( SOCKADDR_IN addrUser, RGERROR err, char* strMessage )
{
	tom_ack_enter_room.err = err;
	if( strMessage )
	{
//		g_packetLog.sendTomAckEnterRoom( tom_ack_enter_room);
		strcpy( tom_ack_enter_room.strMessage, strMessage );
	}
	sendto( m_hSock, (char*)&tom_ack_enter_room, tom_ack_enter_room.hdr.dwLength, 0, (SOCKADDR*)&addrUser, sizeof(addrUser) );
}

void 
RGClient::sendTomAckUpdateUser( SOCKADDR_IN addrUser, RGERROR err, char* strMessage )
{
	tom_ack_update_user.err = err;
	if( strMessage )
	{
		strcpy( tom_ack_update_user.strMessage, strMessage );
	}

//	g_packetLog.sendTomAckUpdateUser(tom_ack_update_user);
	sendto( m_hSock, (char*)&tom_ack_update_user, tom_ack_update_user.hdr.dwLength, 0, (SOCKADDR*)&addrUser, sizeof(addrUser) );
}

void 
RGClient::sendTomNtfUpdateRoom( void )
{
	tom_ntf_update_room.gRoom = m_gRoom;
	memcpy( tom_ntf_update_room.ltgrUser, m_ltgRUser, sizeof( GRUSER ) * 4 );

	int i; 
	for( i = 0; i < 4; i++ )
	{
		if( m_ltgRUser[i].rgrState != RU_NONE_S )
		{
//			g_packetLog.sendTomNtfUpdateRoom(tom_ntf_update_room);
			sendto( m_hSock, (char*)&tom_ntf_update_room, tom_ntf_update_room.hdr.dwLength, 0, 
					(SOCKADDR*)&m_ltgRUser[i].ipaddr, sizeof(m_ltgRUser[i].ipaddr) );			
		}
	}


	if( m_bStartGame == TRUE )		// ������ ���� ���� ������ üũ�Ѵ�.
	{
		m_bStartGame = FALSE;

		if( m_gRoom.dwMap == 10)
		{
			srand( (unsigned)time( NULL ) );
			m_gRoom.dwMap = rand()%10;
		}
		m_gRoom.room.rgState = PLAY_S;

		sendTomNtfStartGame();
		sendTosNtfUpdateRoom( MODIFY_T );
	}
}

void 
RGClient::sendTomNtfChatRoom( const char* strMessage )
{
	strcpy( tom_ntf_chat_room.strMessage, strMessage );

	int i; 
	for( i = 0; i < 4; i++ )
	{
		if( m_ltgRUser[i].rgrState != RU_NONE_S )
		{
//			g_packetLog.sendTorNtfChatRoom(tor_ntf_chat_room);
			sendto( m_hSock, (char*)&tom_ntf_chat_room, tom_ntf_chat_room.hdr.dwLength, 0, 
					(SOCKADDR*)&m_ltgRUser[i].ipaddr, sizeof(m_ltgRUser[i].ipaddr) );		
		}
	}
}

void
RGClient::sendTomReqUserState( void )
{
	if( m_sRNUSCount == 0 )
	{
		for( int i = 0 ; i < 4 ; i++ )
		{
			if( m_ltgRUser[i].rgrState != RU_NONE_S )
			{
				sendto( m_hSock, (char*)&tom_req_user_state, tom_req_user_state.hdr.dwLength, 0, 
						(SOCKADDR*)&m_ltgRUser[i].ipaddr, sizeof(m_ltgRUser[i].ipaddr) );		
			}
		}
	}
	else if( m_sRNUSCount >= 30)
	{
		m_sRNUSCount = 0;
	}
	else
	{
		m_sRNUSCount++;
	}
}
/************************************************************************/
/* 20050521(��) (�뷫)���ϲ� �ý��� �������Ŭ���̾�Ʈ �۾�(Test) - ���
/************************************************************************/
void
RGClient::procTocAckUpdateScore( LPP_TOC_ACK_UPDATE_SCORE msg )
{
	
	//if( msg->err == NO_ERR )
	//{
		/************************************************************************/
		/* ������Ʈ ����
		/************************************************************************/
	//}
	//else
	//{
		/************************************************************************/
		/* ������Ʈ ����
		/************************************************************************/
	//}
}

void
RGClient::procTocAckTop10Score( LPP_TOC_ACK_TOP10_RANK msg )
{
	if( msg->err == NO_ERR )
	{
		/************************************************************************/
		/* msg->Top10User[10] �� �迭�� Top10 ��������(ID, ����)�� ����ִ�. �ʿ�� ����ϼ���~!
		/************************************************************************/	
		/*)for(int i = 0; i < 10; i++)
		{
			cout << msg->Top10User[i].strID << "\t" << msg->Top10User[i].dwScore << endl;
		}*/
	}
}

void
RGClient::procTocAckUserRank( LPP_TOC_ACK_USER_RANK msg )
{
	if( msg->err == NO_ERR)
	{
		/************************************************************************/
		/* msg->dwRank �� �ڱⰡ �������� �����ִ�. �ʿ�� ����ϼ���~!
		/************************************************************************/		
		m_myUser.dwScore = msg->dwScore;
		m_Rank = msg->dwRank;
		/************************************************************************/
	}
}

void
RGClient::sendTosReqUpdateScore()
{
	strcpy(tos_req_update_score.strUserID, m_myUser.strID);
	tos_req_update_score.dwScore = m_myUser.dwScore;

	sendto( m_hSock, (char*)&tos_req_update_score, tos_req_update_score.hdr.dwLength, 0, (SOCKADDR*)&m_addrServer, sizeof(m_addrServer) );
}

void
RGClient::sendTosReqTop10Rank()
{
    strcpy(tos_req_top10_rank.strUserID, m_myUser.strID);

	sendto( m_hSock, (char*)&tos_req_top10_rank, tos_req_top10_rank.hdr.dwLength, 0, (SOCKADDR*)&m_addrServer, sizeof(m_addrServer) );
}

void
RGClient::sendTosReqUserRank()
{
	strcpy( tos_req_user_rank.strUserID, m_myUser.strID);

	sendto( m_hSock, (char*)&tos_req_user_rank, tos_req_user_rank.hdr.dwLength, 0, (SOCKADDR*)&m_addrServer, sizeof(m_addrServer) );
}
/************************************************************************/

void 
RGClient::initPacket(LPP_COMMON lpPacket, RGPCT rpType, DWORD dwLength )
{
	lpPacket->common_hdr.dwLength = dwLength;
	strcpy( lpPacket->common_hdr.strContentName, "yammir" );
	lpPacket->common_hdr.dwKey = 0;
	lpPacket->common_hdr.rpType = rpType;
}

void 
RGClient::initRoom( void )
{
	memset( &m_gRoom, 0, sizeof( GROOM ) );		
	memset( m_ltgRUser, 0, sizeof( GRUSER ) * 4 );

	m_dwUserIndex = 0;
	m_dwMajorIndex = 0;

	m_bMajor = FALSE;
	
	/*>>> for Room <<<*/
//	GROOM	m_gRoom;
//	GRUSER	m_gRUser[4];
//
//	DWORD	m_dwUserIndex; /* �ڽ��� Index */
//
//	memset( m_gRUser, 0, sizeof( GRUSER ) * 4 );
//
//	
//
//	m_vrtgRoom.dwMap = 10;
//
//	m_dwUserIndex
//
//	GROOM	m_gRoom;
//	GRUSER	m_grUser[4];
//
//	GRUSER	m_myRUser;
//
//	m_myRoom = m_pUserData->m_myRoom;
//	
//	memcpy(&m_dtUser[0], &m_pUserData->m_dtMyUser, sizeof(DTUSER));
//	memcpy(&m_pUserData->m_dtUser[0], &m_dtUser[0], sizeof(DTUSER));
//	memcpy(&m_dtUser[0].ipaddr, &m_pUserData->m_dtRoom.ipaddrMajor, sizeof(SOCKADDR_IN));
//
//	for(int i=0; i<4; i++)
//	{
//		if( m_dtUser[i].byUserState == GRS_READY )
//		{
//			m_dtUser[i].byUserState = GRS_NOTREADY;
//		}
//	}
//
//	
//	m_byMapKind = 10;
//
//	SendInfoReq(); // by TA
//	// SendUserInfo();
//
//	SendTosNtfUpdateRoom( INSERT_T );
}

void 
RGClient::resetRoom( void )
{
	for( DWORD dwIndex = 0; dwIndex < 4; dwIndex++ )
	{
		if( getClient()->gruserState(dwIndex) != RU_NONE_S )
		{
			m_ltgRUser[dwIndex].rgrState = RU_NOREADY_S;
		}
	}
	m_gRoom.dwMap = 10;

	if( getClient()->isMajor())
	{
		getClient()->sendTomNtfUpdateRoom();
	}
}

void 
RGClient::initVrtRoom( void )
{
/*
		memset( m_vrtgRUser, 0, sizeof( GRUSER ) * 4 );
	
		// ����
		memcpy( &m_vrtgRoom, &m_gRoom, sizeof( GROOM ) );
		
		// �ʱ� �� ������ �����̴�
		m_vrtgRoom.dwMap = 10;
	
		m_dwUserIndex*/
	
}

BOOL
RGClient::ExitCounting( DWORD count )
{
	m_dwExitCount++;
	if( m_dwExitCount == count )
	{
		m_dwExitCount = 0;
		return TRUE;
	}
	return FALSE;
}

BOOL 
RGClient::checkReady(void)	// ���� �������� ��ũ...
{
	BYTE byCheckColor[7];	// Į��üũ
	BYTE byColorCount = 0;	// Į��� 
	BYTE byUserConut = 0;
	ZeroMemory(byCheckColor, 7);

	for(int i=0; i<4; i++)
	{
		if( m_ltgRUser[i].rgrState != RU_NONE_S )
		{
			byCheckColor[m_ltgRUser[i].byColor]++;
			byUserConut++;
		}
	}

	for(i=0; i<7; i++)
	{
		if(byCheckColor[i])
		{
			byColorCount++;
		}
	}

	switch(byColorCount)
	{
	case 0: // ������ ���ٸ�,
		return FALSE;
	case 1: // ���� ���� �����Ѵٸ�,
		if( byUserConut == 1 )
		{
			sendTomNtfChatRoom("[�˸�] ȥ�ڼ��� �� ���� �����ϴ�");
		}
		else
		{
			sendTomNtfChatRoom("[�˸�] ���� �ϳ��� �ֽ��ϴ�");
		}

		return FALSE;

	case 2: // ������ ���� ���
		for(i=0; i<7; i++)
		{
			if(byCheckColor[i]) 
			{
				for(int j=i+1; j<7; j++)
					if(byCheckColor[j]) // �ٸ� ������ ã�� ����
					{
						if(byCheckColor[i] != byCheckColor[j])
						{
							sendTomNtfChatRoom("[�˸�] ���� ������ ���� �ʽ��ϴ�");
							return FALSE;
						}
					}
			}
		}
		break;
	case 3: // ������ �������
		for(i=0; i<7; i++)
			if(byCheckColor[i] == 2) 
			{
				sendTomNtfChatRoom("[�˸�] �����ϰ�� ������ �θ��� �� �� �����ϴ�");
				return FALSE;
			}
		break;
	case 4:
		break;
	}
	return TRUE;
}

void
RGClient::checkUserCount( void )
{
	DWORD dwCount = 0;
	for( int i = 0; i < 4; i ++ )
	{
		if( m_ltgRUser[i].rgrState != RU_NONE_S )
		{
			dwCount++;
		}
	}
	
	m_gRoom.room.dwJoinUserCount = dwCount;

	if( m_gRoom.room.dwMaxUserCount == m_gRoom.room.dwJoinUserCount )
	{
		m_gRoom.room.rgState = FULL_S;
	}
	else
	{
		m_gRoom.room.rgState = WAIT_S;
	}
}

void
RGClient::changeMajor( void )
{
	// ������ ������ ���ش�
	//
	for( int i = 0; i < 4; i ++ )
	{
		if( m_ltgRUser[i].byMajor ) 
		{
			memset( &m_ltgRUser[i], 0, sizeof( GRUSER ) );
		}
	}

	// ���ο� ���� ź��
	//
	for( i = 0; i < 4; i ++ )
	{
		//��---050522
		//���� �Ѱ� �� �� �ڽ��� �����̹Ƿ� �ڽſ��� �ѱ�� �ȵȴ�.
		//������ �� �濡�� �����ϸ� ������ ������ �Ѱ��ش�.
		//���� �ڽ��� ���̵�� ���� �������Դ� ������ �ѱ��� �ʴ´�.
		if( (m_ltgRUser[i].rgrState != RU_NONE_S) && ( m_ltgRUser[i].user.strID != myUserID() ) ) 
		{
			m_ltgRUser[i].byMajor = 1;
			m_ltgRUser[i].rgrState = RU_NOREADY_S;
			strcpy( m_gRoom.room.strUserName, m_ltgRUser[i].user.strName ); // �ӽ�
			break;
		}
	}

	// �Ѱ��� ����� ���ٸ�
	//
	if( i == 4 )
	{
		sendTosNtfUpdateRoom( DELETE_T );
	}
	else
	{
		checkUserCount();
		sendTosNtfUpdateRoom( MODIFY_T );
		sendTomNtfUpdateRoom();
	}
}

////////////////////////////////////////////////050522(��) ��ŷ ���� A - ���
void RGClient::setgruserChangeScore(int index, DWORD value)
{
	m_ltgRUser[index].user.dwScore += value;
}
void RGClient::setgruserSetScore(int index, DWORD value)
{	
	m_ltgRUser[index].user.dwScore = value;		

}
