#include "TZSocket.h"
#include "../AMLeak.h"
#include "../RGClient.h"

CTZSocket::CTZSocket(void)
{
	// intialization Class Member
	ZeroMemory(&m_Addr,			sizeof(m_Addr));
	ZeroMemory(&m_ServerAddr,	sizeof(m_Addr));
	m_pUserData = NULL;
	m_pQueue	= NULL;
	m_Socket	= INVALID_SOCKET;
	m_pQueue	= NULL;
	m_hSema		= NULL;
}

CTZSocket::~CTZSocket(void)
{
	WSACleanup();
}

int CTZSocket::WSASetup(void)
{
	int Ret = 0;
	WORD	wVersionRequested = MAKEWORD(2,0);

	if( Ret = WSAStartup(wVersionRequested, &m_WsaData) != 0)
	{
		// [ Insert Error Process Routine ]
		return Ret;
	}
	
	if( Ret = LOBYTE(m_WsaData.wVersion) != LOBYTE(wVersionRequested) || 
		HIBYTE(m_WsaData.wVersion) != HIBYTE(wVersionRequested) != 0)
	{
		// [ Insert Error Process Routine ]
		WSACleanup();
		return Ret;
	}
	return Ret;
	// if return value is 0, then no error
}

int CTZSocket::CreateSocket(void)
{
	if( (m_Socket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == INVALID_SOCKET)
	{
		// [ Insert Error Process Routine ]
		WSACleanup();
	}
	return WSAGetLastError();
	// if return value is 0, then no error
}

int CTZSocket::SetupSocket(int arg_Port)
{
	m_Addr.sin_family	= AF_INET;
	m_Addr.sin_port		= htons(arg_Port);
	m_Addr.sin_addr.s_addr = htonl(INADDR_ANY);

	// Associate the address information with the socket using bind.
	if(bind(m_Socket, (SOCKADDR *)&m_Addr, sizeof(m_Addr)) == SOCKET_ERROR)
	{
		// [ Insert Error Process Routine ]
		closesocket(m_Socket);
		WSACleanup();
	}
	return WSAGetLastError();
	// if return value is 0, then no error
}

void CTZSocket::SetQueue(void)
{
	// Allocate the object
	m_pQueue = (CTZQueue*)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(CTZQueue));
	if ( m_pQueue == NULL )
	{
		// [ Insert Error Process Routine ]
		ExitProcess(-1);
	}
	m_hSema = CreateSemaphore(NULL, 0, 0x0FFFFFFF, NULL);
	if( m_hSema == NULL)
	{
		ExitProcess(-1);
	}
	m_pQueue->InitializeCS();
}

void CTZSocket::FreeQueue(CTZQueue *freeQueue)
{
	freeQueue->DeleteCS();
	HeapFree(GetProcessHeap(), 0, freeQueue);
}

int CTZSocket::SendPacketToServer(DATAUNIT *processDataUnit)
{
	// DataUnit Header Initialization
	m_pQueue->DataUnitHeaderInit(processDataUnit);
	int rc;
	rc = sendto(m_Socket,
	&processDataUnit->pPacket->HEADER.buffer[0],
	processDataUnit->packetlen,
	0,
	(SOCKADDR*)&m_ServerAddr,
	sizeof(m_ServerAddr)
	);
	m_pQueue->FreeDataUnit(processDataUnit);
	processDataUnit = NULL;
	return rc;
}

int CTZSocket::SendPacketToRoomMajor(DATAUNIT *processDataUnit)
{
	// DataUnit Header Initialization
	m_pQueue->DataUnitHeaderInit(processDataUnit);
	int rc;
	rc = sendto(m_Socket,
	&processDataUnit->pPacket->HEADER.buffer[0],
	processDataUnit->packetlen,
	0,
	(SOCKADDR*)&getClient()->grmajorAddr(),
	sizeof(getClient()->grmajorAddr())
	);
	m_pQueue->FreeDataUnit(processDataUnit);
	processDataUnit = NULL;
	return rc;
}

int CTZSocket::SendPacketToJoinUser(DATAUNIT *processDataUnit)
{
	// DataUnit Header Initialization
	m_pQueue->DataUnitHeaderInit(processDataUnit);
	int i;
	int rc;
	for(i=0; i<4; i++)
	{
		if(	getClient()->gruserAddr(i).sin_addr.S_un.S_un_b.s_b1 != 0
			&&
			getClient()->gruserState(i) != RU_NONE_S // ���ӷ뿡 ���� ���� 
			&&
			m_pUserData->m_dtSnake[i].byUserState != GUS_NOTEXIST // ���ӿ� �������
			)
		{
			rc = sendto(m_Socket,
				&processDataUnit->pPacket->HEADER.buffer[0],
				processDataUnit->packetlen,
				0,
				(SOCKADDR*)&getClient()->gruserAddr(i),
				sizeof(getClient()->gruserAddr(i))
				);
		}
	}
	m_pQueue->FreeDataUnit(processDataUnit);
	processDataUnit = NULL;
	return rc;
}

int CTZSocket::ServerSetting(char *stripaddr, int arg_Port)
{
	m_ServerAddr.sin_family			= AF_INET;
	m_ServerAddr.sin_port			= htons(arg_Port);
	m_ServerAddr.sin_addr.s_addr	= inet_addr(stripaddr);
	return 0;
}

// teleadam_20050207 [

int 
CTZSocket::SendTOS(LPP_COMMON lpPacket)
{
	int rc;
	rc = sendto(m_Socket,
		(char*)lpPacket,
		lpPacket->common_hdr.dwLength,
		0,
		(SOCKADDR*)&m_ServerAddr,
		sizeof(m_ServerAddr)
		);
	return rc;
}


// ] teleadam_20050207
