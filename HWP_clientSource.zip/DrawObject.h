#ifndef	__DrawObject_h_
#define __DrawObject_h_

#include <d3dx9.h>
#pragma comment(lib, "d3dx9.lib")
#pragma comment(lib, "d3d9.lib")
#include <string>

#include "IDrawObject.h"
#include "TextureManager.h"

using namespace std;

class CDrawObject : public IDrawObject
{
protected:
	D3DXVECTOR3			m_position;
	int					m_width;
	int					m_height;
	RECT				m_textureRect;
	string				m_fileName;
	
	LPD3DXSPRITE		m_sprite;
	IDirect3DDevice9*   m_device;

	bool				m_visible;

public:
	CDrawObject();
	CDrawObject(int _x, int _y, int _w, int _h, string _fileName);
	virtual			~CDrawObject();

	int				getWidth(){return m_width;}
	int				getHeight(){return m_height;}
	POINT			getSize() { POINT point; point.x = m_width; point.y = m_height;  return point; }

	void			setWidth(int _w){m_width = _w;}
	void			setHeight(int _h){m_height = _h;}
	void			setSize(int _w, int _h){ m_width = _w; m_height = _h;}

	void			setPosition(int _x, int _y);
	void			setPosition(POINT _point);
	
	POINT			getPosition();
	
	void			setTextureRect(int _x, int _y);
	void			setTextureRect(RECT _textureRect);

	void			setFileName(string _fileName){ m_fileName = _fileName; }
	string			getFileName(){return m_fileName;}
	
	void			setVisible(bool _visible){m_visible = _visible;}
	bool			getVisible(){return m_visible;}
	void			BitBlt();
	void			BitBlt(int x,int y, int width,int height, int texX, int texY);
	virtual bool	initialize(IDirect3DDevice9* const _device);
	virtual void	release();
	virtual void	draw(DWORD _timeDelta);
};

#endif