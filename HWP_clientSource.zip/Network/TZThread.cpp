#include "TZThread.h"

CTZThread::CTZThread(LPTHREAD_START_ROUTINE ThreadFunc)
{
	hThread = CreateThread(NULL, 0 , ThreadFunc, NULL, 0, &ThreadID);
}

CTZThread::CTZThread(LPTHREAD_START_ROUTINE ThreadFunc, LPVOID oArg)
{
	hThread = CreateThread(NULL, 0 , ThreadFunc, oArg, 0, &ThreadID);
}


CTZThread::~CTZThread(void)
{
	CloseHandle(hThread);
}

DWORD CTZThread::Suspend()
{
	return SuspendThread(hThread);
}

DWORD CTZThread::Resume()
{
	return ResumeThread(hThread);
}

void CTZThread::Exit()
{
	ExitThread(0);
}
