#ifndef	__Timer_h_
#define __Timer_h_

#include <windows.h>

class CTimer {
private :
	long				m_nStartTime;
public:
	CTimer(void);
	void				Start(void);
	long				Time(void);
	bool				Elapsed(long &start, long interval);
};

#endif