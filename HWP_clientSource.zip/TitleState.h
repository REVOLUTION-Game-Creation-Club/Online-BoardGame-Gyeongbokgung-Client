#ifndef __TitleState_h__
#define __TitleState_h__
#include "IGameState.h"
#include "GameManager.h"

class titleLisner;

class CTitleState : public IGameState
{
private:
	CGameManager*				m_gameManager;
	titleLisner*				m_listener;
	bool						m_connected;
public:
	CTitleState(CGameManager* _gameManager);
	virtual						~CTitleState();

	bool						initialize();
	void						release();

	void						onUpdate();
	void						onKeyboard(WPARAM _wParam);
	void						processMouseMove();
	void						onMouseLClick();
};

#endif