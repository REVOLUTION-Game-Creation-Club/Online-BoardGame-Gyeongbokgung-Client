#include "stdafx.h"
#include "CUIDialogbox.h"

#define VIEW_RANGE 10

CUIDialogbox::CUIDialogbox(void)
{
	kind	= "dialogbox";
	m_ListSize = 0;
	m_viewRange = VIEW_RANGE;
}

CUIDialogbox::~CUIDialogbox(void)
{
	int size = m_stringList.size();

	for( int i = 0; i < size; ++ i )
	{
		m_stringList[i].clear();
	}

	m_stringList.clear();
}

CUIDialogbox::CUIDialogbox(string _name)
{
	kind	= "dialogbox";
	name	= _name;
	m_ListSize = 0;
	m_viewRange = VIEW_RANGE;
}

CUIDialogbox::CUIDialogbox(string _name, int _x, int _y, int _width, int _height)
{
	kind	= "dialogbox";
	name	= _name;
	x		= _x;
	y		= _y;
	width	= _width;
	height	= _height;
	m_ListSize = 0;
	m_viewRange = VIEW_RANGE;
}

CUIDialogbox::CUIDialogbox(string _name, int _x, int _y, int _width, int _height, int _texX, int _texY, char* _fileName)
{
	kind	= "dialogbox";
	name	= _name;
	x		= _x;
	y		= _y;
	width	= _width;
	height	= _height;
	m_ListSize = 0;
	m_viewRange = VIEW_RANGE;

	tex_x	= _texX;
	tex_y	= _texY;
	setFileNavi(_fileName);


	m_temp[0]=_x;
	m_temp[1]=_y;
	m_temp[2]=_width;
	m_temp[3]=_height;
}

void CUIDialogbox::insertString(string _sentence)
{
	m_stringList.push_back(_sentence);
	m_ListSize++;

	if( m_ListSize > m_maxString )
	{		
		m_stringList.erase(m_stringList.begin());
	}
}

void CUIDialogbox::insertString(char* _sentence) 
{ 
	string temp = _sentence;

	m_stringList.push_back(temp);
	m_ListSize++;

	if( m_ListSize > m_maxString )
	{		
		m_stringList.erase(m_stringList.begin());
	}
}

void CUIDialogbox::refreshString(int _where, string _sentence)
{	
	m_stringList[_where] = _sentence;
}

void CUIDialogbox::refreshString(int _where, char* _sentence)
{
	m_stringList[_where] = _sentence;
}

string CUIDialogbox::getString(int _which)
{
	return m_stringList[_which];
}

void CUIDialogbox::eraseString(int _which)
{
	m_stringList.erase(m_stringList.begin() + _which);
	m_ListSize--;
}

string CUIDialogbox::operator [] (int _which)
{
	return m_stringList[_which];
}

void CUIDialogbox::setRange(int _range)
{
	m_viewRange = _range;
}

void CUIDialogbox::setLineSpace(int _space)
{
	m_lineSpace = _space;
}

void CUIDialogbox::setValue(int _x, int _y)
{
	x = _x;
	y = _y;

	m_fontPos_x = x;
	m_fontPos_y = y;	
}

void CUIDialogbox::setValue(int _x, int _y, int _width, int _height)
{
	x = _x;
	y = _y;
	width = _width;
	height = _height;	

	m_fontPos_x = x;
	m_fontPos_y = y;
}

void CUIDialogbox::setValue(int _x, int _y, int _width, int _height, int _texX, int _texY, char* _fileName)
{
	x = _x;
	y = _y;
	width = _width;
	height = _height;
	tex_x = _texX;
	tex_y = _texY;
	m_fileName = _fileName;

	m_fontPos_x = x;
	m_fontPos_y = y;
}

void CUIDialogbox::setMaxString(int _max)
{
	m_maxString = _max;

	if( m_ListSize > m_maxString )
	{
		for( int i = 0 ; i < m_ListSize - m_maxString ; i++ )
		{			
			m_stringList.erase(m_stringList.begin());
		}		
	}

}

void CUIDialogbox::setStringLength(int _Length)
{
	/*
	int temp;

	m_stringLength = _Length;

	for( int i = 0; i < m_ListSize ; i++ )
	{
		temp = m_stringList[i].Length() ;
		if( temp > m_stringLength )
		{
			m_stringList[i].replace(0, temp - 1, m_stringList[i].substr(0, m_stringLength));
		}
	}
	*/
}

void CUIDialogbox::reset()
{
	m_stringList.clear();
	m_ListSize = 0;
	this->release();
}


void CUIDialogbox::insertString( char* _sentence, int _nLineCount )
{
	int nSizeStr = strlen( _sentence );

	int nReadBytes = 0;
	char buf[256] = {0};
	int sizeChar;
	int i = 0;
	while( nSizeStr > _nLineCount )
	{
		// �ѱ�
		if( IsDBCSLeadByte( *( _sentence + i + nReadBytes ) ) )
		{
			sizeChar = 2;
		}
		// �ѱ� �ƴ�
		else 
		{
			sizeChar = 1;
		}

		// ��� ���ۼ��� �ø���
		if( i + sizeChar <= _nLineCount )
		{
			i += sizeChar;
		}
		// insertString
		else
		{
			memset( buf, 0, 256 );
			memcpy( buf, _sentence + nReadBytes, i )	;
			insertString( buf );
			nSizeStr -= i;
			nReadBytes += i;
			i = 0;
		}
	}

	insertString( _sentence + strlen( _sentence ) - nSizeStr );
}

void CUIDialogbox::changeString( char* _sentence, int _nLineCount )
{

}