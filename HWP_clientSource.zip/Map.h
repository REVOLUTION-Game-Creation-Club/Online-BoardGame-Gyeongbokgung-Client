#ifndef __Map_h__
#define __Map_h__
#include "SpriteObject.h"
#include "Item.h"

#include <vector>

const int 	TILE_ROW = 30;
const int 	TILE_COL = 40;
const int 	TILE_WIDTH = 50;
const int 	TILE_HEIGHT = 50;

const int 	BG_WIDTH = 2000;
const int 	BG_HEIGHT = 1500;
const int	BGVIEW_WIDTH = 1024;
const int	BGVIEW_HEIGHT = 768;
const int	SCROLL_MOVE_AMOUNT_X = 50;
const int	SCROLL_MOVE_AMOUNT_Y = 50;
const int	SCROLL_MOVE_MARGIN_X = 10;
const int	SCROLL_MOVE_MARGIN_Y = 10;

//{{ bakky ����ź ����
const int	WATER_BALL_RANGE	= 3;
const int	START_POINT	= 2;	// ���� Ÿ�� ���̵�
const int	END_POINT	= 3;	// �� Ÿ�� ���̵�
//}}

using namespace std;
enum TILE_KIND{ NORMAL = 0, SHORT_ROAD, CROSS_ROAD, ITEM_TILE, START_TILE, END_TILE, JUMP_TILE, BALOON_TILE, OBJECT_TILE};

typedef struct _TileInfo{
	int				m_index;
	int				m_subIndex;
	int				m_id;
	int				m_point;
	int				m_type;
	int				m_x;
	int				m_y;
	int				m_select;
	int				m_waterball;
	ITEM_KIND		m_item;
	int				m_prevTile;
	int				m_nextTile;
	int				m_gotoTile;

	_TileInfo()
	{
		m_index = 0;
		m_subIndex = 0;
		m_id = 0;
		m_point = 0;
		m_type = 0;
		m_x = 0;
		m_y = 0;
		m_select = 0;
		m_waterball = 0;
		m_item = ITEM_NO;
		m_prevTile = 0;
		m_nextTile = 0;
		m_gotoTile = 0;
	}
}TileInfo;

class CCharacter;

class CMap: public CDrawObject{
private:
	POINT				m_screenPoint;
	POINT				m_scrollPoint;
	vector<TileInfo>	m_listTile;

	void				drawBackGround();
	void				drawTile();

public:
						CMap();
	virtual				~CMap();

	bool				initialize(IDirect3DDevice9* const _device);
	void				draw(DWORD _timeDelta);
	bool				loadTile();
	TileInfo			getTile(int _index){return m_listTile[_index];}
	void				setTile(TileInfo _tile,int _index){m_listTile[_index] = _tile;}
	int					getTileListSize(){ return (int)m_listTile.size();}

	POINT				getScreenPoint(){return m_screenPoint;}
	void				setScreenPoint(POINT _screenPoint){ m_screenPoint = _screenPoint; }

	POINT				getScrollPoint(){return m_scrollPoint;}
	void				setScrollPoint(POINT _scrollPoint){ m_scrollPoint = _scrollPoint; }

	void				setScreenPointAtCharacter(CCharacter* _character);
	bool				emptyTileLIst(){ return (int)m_listTile.empty();}

	//{{ bakky
	// ĳ������ Ÿ�� �ε����� �Ѱ��ָ� ����ź ��ġ ���� Ÿ���ε����� �迭�� �Ѱ��ش�.
	// ��ġ������ Ÿ���� ����
	void	getCanWaterBallTiles( int nCharTileIndex, vector<int>& vecWaterBallTile );
	int		isLeaveShortPath( int nTileIndex );	// �ƴϴ�~
	void	setTileFromId( int _tileId, TileInfo& tileInfo );
	//}}
};

#endif