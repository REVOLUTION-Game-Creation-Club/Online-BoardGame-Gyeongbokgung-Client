#ifndef _TZThread_
#define _TZThread_
#include <windows.h>

class CTZThread
{
private:
	DWORD	ThreadID;

public:
	HANDLE	hThread;

	CTZThread(LPTHREAD_START_ROUTINE ThreadFunc);
	CTZThread(LPTHREAD_START_ROUTINE ThreadFunc, LPVOID oArg);
    ~CTZThread(void);

	DWORD	Suspend();
	DWORD	Resume();
	void	Exit();
};

#endif