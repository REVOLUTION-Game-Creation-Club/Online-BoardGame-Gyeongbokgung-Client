#include "stdafx.h"
#include "SpriteObject.h"

CSpriteObject::CSpriteObject() :CDrawObject()
{
	m_spriteType	=	0;
	m_spriteNo		=	0;
}
CSpriteObject::CSpriteObject(int _x, int _y, int _w, int _h, string _fileName)
:CDrawObject(_x,_y,_w,_h,_fileName)
{
	m_spriteType	=	0;
	m_spriteNo		=	0;
}

CSpriteObject::~CSpriteObject()
{
}

void CSpriteObject::setSpriteType(int _type)
{ 
	m_spriteType = _type;

	m_textureRect.top = (LONG)(m_spriteType*m_height);
	m_textureRect.bottom = (LONG)((m_spriteType+1)*m_height);
	m_textureRect.left = (LONG)(m_spriteNo*m_width);
	m_textureRect.right = (LONG)((m_spriteNo+1)*m_width);
}

int CSpriteObject::getSpriteType()
{ 
	return m_spriteType;
}

void CSpriteObject::setSpriteNo(int _no)
{ 
	m_spriteNo = _no;

	m_textureRect.top = (LONG)(m_spriteType*m_height);
	m_textureRect.bottom = (LONG)((m_spriteType+1)*m_height);
	m_textureRect.left = (LONG)(m_spriteNo*m_width);
	m_textureRect.right = (LONG)((m_spriteNo+1)*m_width);
}

int CSpriteObject::getSpriteNo()
{ 
	return m_spriteNo;
}