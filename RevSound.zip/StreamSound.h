#ifndef __STREAM_SOUND_H__
#define __STREAM_SOUND_H__

#include "sound.h"
#include "SoundFileLoader.h"

namespace rev
{

class CStreamSound : public CSound
{
protected :
	CSoundFileLoader*		m_pSoundFile;		// CSoundFileLoader pointer
	DWORD					m_dwBytesPlayed;	// �󸶸�ŭ �÷��� �ߴ���.
	DWORD					m_dwDataPos;		// �󸶸�ŭ �����
	DWORD					m_dwLastReadPos;	

public :
	CStreamSound( TCHAR* _szFileName );
	virtual ~CStreamSound();

public :
	bool	initialize();
	bool	destroy();

	bool	isStream() const	{	return true;	}
	bool	isPlaying() const	{	return ( m_dwBytesPlayed < m_pSoundFile->getSize() ) ? true : false;	}

	bool	play( bool _bLoop = false );

	void	load( CSoundFileLoader* pSoundFileLoader );

	bool	update();
};

}
#endif	// __STREAM_SOUND_H__