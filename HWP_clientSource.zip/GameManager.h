#ifndef __GameManager_h__
#define __GameManager_h__
#include "Map.h"
#include "Character.h"
#include "Rullet.h"
#include "PrintObject.h"
#include "FPS.h"
#include "IGameState.h"

enum GAME_STATE {GAME_STATE_NOW = 0, GAME_STATE_PLAY, GAME_STATE_LOBBY, GAME_STATE_ROOM,
				 GAME_STATE_TITLE, GAME_STATE_LOADING, GAME_STATE_RESULT, GAME_STATE_END,
				 GAME_STATE_OPENNING};

class CGameManager
{
private:
	POINT						m_mousePoint;
	static	CGameManager*		selfInstance;

	IGameState*					m_playState;
	IGameState*					m_lobbyState;
	IGameState*					m_roomState;
	IGameState*					m_titleState;
	IGameState*					m_loadingState;
	IGameState*					m_resultState;
	IGameState*					m_endState;
	IGameState*					m_openningState;

	IGameState*					m_nowState;

	GAME_STATE					m_gameState;
private:
								CGameManager();
	virtual						~CGameManager();

public:
	static CGameManager*		getInstance();

	bool						initialize();
	void						release();

	void						onUpdate();
	void						onKeyboard(WPARAM _wParam);
	void						processMouseMove();

	POINT						getMousePoint(){return m_mousePoint;}
	void						setMousePoint(int _x, int _y){m_mousePoint.x = _x; m_mousePoint.y = _y;}
	void						setMousePoint(POINT _point){m_mousePoint = _point;}
	
	IGameState*					getState(GAME_STATE _gameState);
	void						setState(GAME_STATE _gameState);
	GAME_STATE					getGameState();

	void	setNoticeString( char* msg, float r, float g, float b, float a );
};

#endif