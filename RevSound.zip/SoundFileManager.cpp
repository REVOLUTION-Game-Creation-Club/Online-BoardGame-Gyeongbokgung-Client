#include "StdAfx.h"
#include "SoundFileManager.h"
#include "WaveFileLoader.h"

#include <fstream>

namespace rev
{

CSoundFileManager::CSoundFileManager(void)
{
	m_nBgmCurrentGroup	= 0;
	m_nBgmCurrentPos	= 0;
	m_nEffectCurrentPos	= 0;
	m_nGroupCount		= 0;

	m_pBgmList = NULL;

	initialize();
}

CSoundFileManager::~CSoundFileManager(void)
{
	destroy();
}

bool	
CSoundFileManager::initialize()
{
	m_nBgmCurrentGroup	= 0;
	m_nBgmCurrentPos	= 0;
	m_nEffectCurrentPos	= 0;
	m_pBgmList = NULL;

	return true;
}

bool	
CSoundFileManager::destroy()
{
	if( m_pBgmList )
		delete [] m_pBgmList;

	return true;
}

int	
CSoundFileManager::getIntFromBuffer( TCHAR* buf )
{
#ifdef _UNICODE
	int temp = _wtoi( buf );
#else
	int temp = atoi( buf );
#endif

	return temp;
}

bool	
CSoundFileManager::loadSoundList( TCHAR* _szFileName )
{
#ifdef _UNICODE
	std::wfstream	file;
#else
	std::fstream	file;
#endif

	file.open( _szFileName, ios_base::in );
	if( file.is_open() == false )
		return false;

	TCHAR buf[1024]={0};

	file.getline(buf, 1024);	// effect
	file.getline(buf, 1024);	// effect ����

	int nEffectCount = getIntFromBuffer( buf );
	

	for( int i=0 ; i<nEffectCount ; i++ )
	{
		file.getline( buf, 1024 );

		m_vecEffect.push_back( tstring( buf ) );
	}

	file.getline( buf, 1024 );	// ����
	file.getline( buf, 1024 );	// bgm
	file.getline( buf, 1024 );	// bgm ����
	int nBgmCount = getIntFromBuffer( buf );

	BGMNODE		bgm;
	vector<BGMNODE>			vecBgm;
	vector<unsigned int>	vecBgmGroup;

	for( int i=0 ; i<nBgmCount ; i++ )
	{
		file.getline( buf, 1024 );
		bgm.group = getIntFromBuffer( buf );

		file.getline( buf, 1024 );
		bgm.strFilePath = tstring( buf );

		vecBgm.push_back( bgm );

		//
		if( vecBgmGroup.size() <= bgm.group )
		{
			vecBgmGroup.push_back( bgm.group );
		}
	}
	file.close();

	if( nBgmCount > 0 )
	{
		m_nGroupCount = (int)vecBgmGroup.size();
		m_pBgmList = new vector<BGMNODE>[ m_nGroupCount ];

		for( unsigned int i=0 ; i<vecBgm.size() ; i++ )
		{
			m_pBgmList[ vecBgm.at( i ).group ].push_back( vecBgm.at( i ) );
		}
	}

	vecBgm.clear();
	vecBgmGroup.clear();

	return true;
}

void
CSoundFileManager::setBgmGroup( unsigned int _group )
{
	m_nBgmCurrentGroup	= _group;
	m_nBgmCurrentPos	= 0;
}

tstring*
CSoundFileManager::currentBgm()
{
	return NULL;
}

tstring*
CSoundFileManager::nextBgm()
{
	if( !m_pBgmList )
		return NULL;

	if( m_nBgmCurrentPos >= (int)m_pBgmList[ m_nBgmCurrentGroup ].size() )
		m_nBgmCurrentPos = 0;

	return &m_pBgmList[ m_nBgmCurrentGroup ].at( m_nBgmCurrentPos++ ).strFilePath;
}

tstring*	
CSoundFileManager::nextEffect()
{
	if( isEmpty() )
	{
		m_vecEffect.clear();
		return NULL;
	}

	return &m_vecEffect.at( m_nEffectCurrentPos++ );
}

bool	
CSoundFileManager::isEmpty()
{
	return ( m_vecEffect.size() - 1 < (unsigned int)m_nEffectCurrentPos ) ? true : false;
}

tstring*	
CSoundFileManager::findBgm( tstring& strName )
{
	for( int i=0 ; i<m_nGroupCount ; i++ )
	{
		for( int k=0 ; k<(int)m_pBgmList[i].size() ; k++ )
		{
			if( m_pBgmList[i].at( k ).strFilePath.find( strName ) != tstring::npos )
			{
				setBgmGroup( m_pBgmList[i].at( k ).group );
				return &m_pBgmList[i].at( k ).strFilePath;
			}
		}
	}

	return NULL;
}

}