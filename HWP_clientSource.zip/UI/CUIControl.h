#pragma once
#include <string>
#include "Clistener.h"
#include "UIDefine.h"


using namespace std;

class CUIControl
{
protected:	
	Clistener* m_listener;
	CUIControl(void);

	string m_fileName;

	int m_state;
	int m_imageFlag;

	int tex_x_normal;
	int tex_x_rollover;
	int tex_x_pressed;
	int tex_x_inactive;

	BOOL	m_bEnable;

public:
	//������
	string kind;

	//�ĺ��� �̸�
	string name;

	//ũ�� : int
	int height;
	int width;

	//��ǥ : int
	int x, y;

	//�׸��� ������ �׸����Ͽ��� �ش� ��ư�� ��ġ
	int tex_x, tex_y;

	//Ȱ��ȭ ����
	bool focus;

	//visible : boolean
	bool visible;	

	int mouseClicked_x;
	int mouseClicked_y;

	//�Լ���	
	virtual ~CUIControl(void);

	string getFileNavi();
	void setFileNavi(string _file);

	virtual void addListener(Clistener *_listener);
	virtual void deleteListener();

	virtual void activeControl(int _state);
	virtual void deactivate();

	void setValue(int _x, int _y);
	void setValue(int _x, int _y, int _width, int _height);
	void setValue(int _x, int _y, int _width, int _height, int _texX, int _texY, string _fileName);
	void setValue(int _texX, int _texY, string _fileName);

	void moveControl(int _xterm, int _yterm );

	virtual void setImageFlag(int _flag = REV_NORMAL);
	virtual void setImageState(int _flag);

	void setMouseClickPos(int _x, int _y) { mouseClicked_x = _x - x; mouseClicked_y = _y - y; }

	void setState(int _state) { m_state = _state;}
	int getState() { return m_state; }


	//{{ �� �߰�
	void setVisible( bool bVisible )	{ visible = bVisible;}
	BOOL isVisible() { return BOOL(visible); }

	void setEnable( BOOL bEnable )		{ m_bEnable = bEnable; visible = (bool)bEnable; }
	BOOL isEnable()	{ return m_bEnable;	}

	void setPosition( int _x, int _y )	{ x = _x; y = _y; }
	//}}		
};