#ifndef __IMessageState__h_
#define __IMessageState__h_

#include "Packet.h"

class IMessageState{
public:
	virtual bool		initialize() = 0;
	virtual void		cleanup() = 0;
	virtual void		broadcast(Packet& _packet) = 0;
	virtual void 		sendMessageToClientServer(Packet& _packet) = 0;
	virtual void		sendMessageToMainServer(Packet& _packet) = 0;
	virtual bool		connectServer(char* _addr) = 0;
	virtual void		processPacket() = 0;

	virtual ~IMessageState()	{}
};
#endif