// RGClient.h: interface for the RGClient class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _RGClinet_H_
#define _RGClinet_H_

#include "RGProtocol.h"

//������ũ
//�̹���
//�밡��
//�巡��

class RGClient  
{
private:

	RGClient();
	static RGClient*	m_pThis;
	
	HWND	m_hWnd;

	/*>>> for Lobby <<<*/
	USER	m_ltUser[MAX_USER];	/*Lobby User:*/
	ROOM	m_ltRoom[MAX_ROOM];	/*Lobby Room:*/

	DWORD m_dwUserCount;		/*Lobby User Count:*/
	DWORD m_dwRoomCount;		/*Lobby Room Count:*/

	DWORD m_sRNUSCount;

	/*>>> for Room <<<*/
	GROOM	m_gRoom;

	BOOL	m_bMajor; // �����ΰ�?

	SOCKET		m_hSock;
	SOCKADDR_IN	m_addrServer;

	DWORD m_dwUserIndex;
	DWORD m_dwMajorIndex;
	BYTE  m_byGameMode;

	BOOL	m_bStartGame;
	DWORD   m_dwExitCount;

	P_TOS_REQ_ENTER_LOBBY	tos_req_enter_lobby;
	P_TOS_REQ_ENTER_ROOM	tos_req_enter_room;
	P_TOS_REQ_MAKE_ROOM		tos_req_make_room;
	P_TOS_NTF_EXIT_GAME		tos_ntf_exit_game;
	P_TOS_NTF_USER_STATE	tos_ntf_user_state;
	P_TOS_NTF_UPDATE_ROOM	tos_ntf_update_room;
	P_TOS_NTF_CHAT_LOBBY	tos_ntf_chat_lobby;
	P_TOR_REQ_ENTER_ROOM	tor_req_enter_room;
	P_TOR_REQ_UPDATE_USER	tor_req_update_user;
	P_TOR_NTF_EXIT_ROOM		tor_ntf_exit_room;
	P_TOR_NTF_CHAT_ROOM		tor_ntf_chat_room;
	P_TOM_ACK_ENTER_ROOM	tom_ack_enter_room;
	P_TOM_ACK_UPDATE_USER	tom_ack_update_user;
	P_TOM_NTF_UPDATE_ROOM	tom_ntf_update_room;
	P_TOM_NTF_CHAT_ROOM		tom_ntf_chat_room;
	P_TOM_NTF_START_GAME	tom_ntf_start_game;
	//�� -- 050522 �ڽ��� ���� �˸�
	P_TOM_NTF_UPDATE_STATE	tom_ntf_update_state;
	P_TOM_REQ_USER_STATE	tom_req_user_state;
	////////////////////////////////////////////////////////050522(��) ��ŷ ���� A - ���
	P_TOM_NTF_CHANGE_SCORE	tom_ntf_change_score;	//������ ����鿡�� �ٲ� ������ ����
	P_TOS_REQ_UPDATE_SCORE	tos_req_update_score;
	//P_TOC_ACK_UPDATE_SCORE	toc_ack_update_score;
	P_TOS_REQ_TOP10_RANK	tos_req_top10_rank;
	//P_TOC_ACK_TOP10_RANK	toc_ack_top10_rank;
	P_TOS_REQ_USER_RANK		tos_req_user_rank;
	//P_TOC_ACK_USER_RANK		toc_ack_user_rank;
	/************************************************************************/
	
private: /* Method */

	void procTocAckEnterLobby	( LPP_TOC_ACK_ENTER_LOBBY msg );	
	void procTocAckEnterRoom	( LPP_TOC_ACK_ENTER_ROOM msg );
	void procTocAckMakeRoom		( LPP_TOC_ACK_MAKE_ROOM msg );
	void procTocNtfRoomList		( LPP_TOC_NTF_ROOM_LIST msg );
	void procTocNtfUserList		( LPP_TOC_NTF_USER_LIST msg );
	void procTocNtfUpdateRoom	( LPP_TOC_NTF_UPDATE_ROOM msg );
	void procTocNtfUpdateUser	( LPP_TOC_NTF_UPDATE_USER msg );
	void procTocNtfServerState	( LPP_TOC_NTF_SERVER_STATE msg );
	void procTocNtfChatLobby	( LPP_TOC_NTF_CHAT_LOBBY msg );

	void procTorReqEnterRoom	( LPP_TOR_REQ_ENTER_ROOM msg );
	void procTorReqUpdateUser	( LPP_TOR_REQ_UPDATE_USER msg );
	void procTorNtfExitRoom		( LPP_TOR_NTF_EXIT_ROOM msg );
	void procTorNtfChatRoom		( LPP_TOR_NTF_CHAT_ROOM msg );

	void procTomAckEnterRoom	( LPP_TOM_ACK_ENTER_ROOM msg );
	void procTomAckUpdateUser	( LPP_TOM_ACK_UPDATE_USER msg );
	void procTomNtfUpdateRoom	( LPP_TOM_NTF_UPDATE_ROOM msg );
	void procTomNtfChatRoom		( LPP_TOM_NTF_CHAT_ROOM msg );

	void procTomNtfStartGame	( LPP_TOM_NTF_START_GAME msg );
	//�� -- 050522 �ڽ��� ���� �˸�
	void procTomNtfUpdateState	( LPP_TOM_NTF_UPDATE_STATE	msg );
	void procTomReqUserState	( LPP_TOM_REQ_USER_STATE	msg );

	/************************************************************************/
	/* 20050521(��) (�뷫)���ϲ� �ý��� �������Ŭ���̾�Ʈ �۾�(Test) - ���
	/************************************************************************/
	void procTocAckUpdateScore	( LPP_TOC_ACK_UPDATE_SCORE msg );
	void procTocAckTop10Score	( LPP_TOC_ACK_TOP10_RANK msg );
	void procTocAckUserRank		( LPP_TOC_ACK_USER_RANK msg );
	void procTomNtfChangeScore ( LPP_TOM_NTF_CHANGE_SCORE msg );	//050522(��) ��ŷ ���� A - ���
	/************************************************************************/
	void checkUserCount( void );
	static void CreateInstance( void );

public:

	virtual ~RGClient();
	static RGClient* GetInstance( void );
	static void DeleteInstance( void );
	
	void msgProc(LPP_COMMON lppCommon);

	void init( HWND hWnd, SOCKET hSock, SOCKADDR_IN	addr );
	void initUser( char* strID, char* strName, DWORD dwScore );
	void initPacket(LPP_COMMON lpPacket, RGPCT rpType, DWORD dwLength );
	void initRoom( void );
	void initVrtRoom( void );

	void sendTosNtfUserState( RGUSERSTATE state );
	void sendTosReqEnterRoom( DWORD dwRoomKey );
	void sendTosReqEnterLobby( void );
	void sendTosReqMakeRoom( char* strRoomName );
	void sendTosNtfExitGame( void ); 
	void sendTosNtfChatLobby( const char* strMessage );
	void sendTosNtfUpdateRoom( RGUPDATETYPE type );

	void sendTorReqEnterRoom( SOCKADDR_IN addrRoom );
	void sendTorReqUpdateUser( GRUSER grUser );
	void sendTorNtfExitRoom( void );
	void sendTorNtfChatRoom( const char* strMessage );

	void sendTomAckEnterRoom( SOCKADDR_IN addrUser, RGERROR err, char* strMessage );
	void sendTomAckUpdateUser( SOCKADDR_IN addrUser, RGERROR err, char* strMessage );
	void sendTomNtfUpdateRoom( void );
	void sendTomNtfChatRoom( const char* strMessage );
	//�� -- 050522 
	void sendTomNtfUpdateState( void );
	void sendTomReqUserState( void );

	void sendTomNtfStartGame( void );
	/************************************************************************/
	/* 20050521(��) (�뷫)���ϲ� �ý��� �������Ŭ���̾�Ʈ �۾�(Test) - ���
	/************************************************************************/
	void sendTosReqUpdateScore( void );
	void sendTosReqTop10Rank( void );
	void sendTosReqUserRank( void );
	/************************************************************************/

	void sendTomNtfChangeScore( void );	//050522(��) ��ŷ ���� A - ���
	DWORD roomKey( DWORD dwIndex ) { return m_ltRoom[dwIndex].dwKey; }
	RGROOMSTATE roomState( DWORD dwIndex ) { return  m_ltRoom[dwIndex].rgState; }
	char* roomName( DWORD dwIndex ) { return m_ltRoom[dwIndex].strName; }
	DWORD roomJoinUserCount( DWORD dwIndex ) { return m_ltRoom[dwIndex].dwJoinUserCount; }
	DWORD roomMaxUserCount( DWORD dwIndex ) { return m_ltRoom[dwIndex].dwMaxUserCount; }

	char* userID( DWORD dwIndex ) { return m_ltUser[dwIndex].strID;  }
	char* userName( DWORD dwIndex ) { return m_ltUser[dwIndex].strName;  }
	DWORD userScore( DWORD dwIndex ) { return m_ltUser[dwIndex].dwScore; }
	RGUSERSTATE userState( DWORD dwIndex ) { return m_ltUser[dwIndex].rgState; }

	char* myUserName( void ) { return m_myUser.strName; }
	char* myUserID( void ) { return m_myUser.strID; }
	DWORD myUserScore( void ) { return m_myUser.dwScore; }
	RGUSERSTATE myUserState( void ) { return m_myUser.rgState; }

	DWORD roomCount( void ) { return m_dwRoomCount; }
	DWORD userCount( void ) { return m_dwUserCount; }

	DWORD groomKey( void )				{ return m_gRoom.room.dwKey; }
	char* groomName( void )				{ return m_gRoom.room.strName; }
	DWORD groomJoinUserCount( void )	{ return m_gRoom.room.dwJoinUserCount; }
	DWORD groomMaxUserCount( void )		{ return m_gRoom.room.dwMaxUserCount; }
	char* groomUserName( void )			{ return m_gRoom.room.strUserName; }
	DWORD groomMap( void )				{ return m_gRoom.dwMap; }
	DWORD groomIFID( DWORD dwIndex )	{ return m_gRoom.dwIFID[dwIndex];}

	void setGRoomIFID( DWORD dwIndex, DWORD dwValue )	{ m_gRoom.dwIFID[ dwIndex ] = dwValue; }

	DWORD gameMode( void )				{ return m_gRoom.dwGameMode; }
	

	char*	gruserID( DWORD dwIndex )			{ return m_ltgRUser[dwIndex].user.strID; }
	char*	gruserName( DWORD dwIndex )			{ return m_ltgRUser[dwIndex].user.strName; }
	DWORD	gruserScore( DWORD dwIndex )		{ return m_ltgRUser[dwIndex].user.dwScore; }
	/////////////////////////////////////////////////////////////////////////////////////////////////////////
	//DWORD	gruserChangeScore( DWORD dwIndex )		{ return m_ltgRUser[dwIndex].user.dwChangeScore; }	//050522(��) ��ŷ ���� A - ���
	RGROOMUSERSTATE	gruserState( DWORD dwIndex ){ return m_ltgRUser[dwIndex].rgrState; }
	RGUSERSTATE ruserState( DWORD dwIndex )		{ return m_ltgRUser[dwIndex].user.rgState; }//�� -- 050523

	void setGRUserState( DWORD dwIndex, RGROOMUSERSTATE state ) 
	{ 
		m_ltgRUser[dwIndex].rgrState = state; 
	}

	BOOL	gruserMajor( DWORD dwIndex )		{ return m_ltgRUser[dwIndex].byMajor; }
	BYTE	gruserSnakeKind( DWORD dwIndex )	{ return  m_ltgRUser[dwIndex].bySnakeKind; }
	BYTE	gruserColor( DWORD dwIndex )		{ return  m_ltgRUser[dwIndex].byColor; }
	SOCKADDR_IN gruserAddr( DWORD dwIndex )		{ return  m_ltgRUser[dwIndex].ipaddr; }

	void setUserIndex( DWORD dwUserIndex ) { m_dwUserIndex = dwUserIndex; }
	void setMajorIndex( DWORD dwMajorIndex ) { m_dwMajorIndex = dwMajorIndex; }


	SOCKADDR_IN grmajorAddr( void ) { return  m_ltgRUser[m_dwMajorIndex].ipaddr; }
	DWORD gruserIndex( void ) { return m_dwUserIndex; }
	DWORD grmajorIndex( void ) { return m_dwMajorIndex; }

	BOOL isMajor( void ) { return m_bMajor;	}
	void setMajor( BOOL bMajor ) { m_bMajor = bMajor; }
	DWORD setGameMode( DWORD dwGameMode ) { return m_gRoom.dwGameMode = dwGameMode; }

	BOOL myRGUser( GRUSER* myRGUser )
	{
		for( int i = 0; i < 4; i++ )
		{
			if( !strcmp( m_ltgRUser[i].user.strID, m_myUser.strID ) )
			{
				*myRGUser = m_ltgRUser[i];
				m_dwUserIndex = i;
				return TRUE;
			}
		}

		return FALSE;
	}

	BOOL updateUserIndex( void )
	{
		for( int i = 0; i < 4; i++ )
		{
			if( !strcmp( m_ltgRUser[i].user.strID, m_myUser.strID ) )
			{
				m_dwUserIndex = i;
				return TRUE;
			}

			if( m_ltgRUser[i].byMajor )
			{
				m_dwMajorIndex = i;
			}
		}
		return FALSE;
	}

	void setRoomMap( DWORD dwMap )
	{
		m_gRoom.dwMap = dwMap;
	}

	void setMyRGUser( GRUSER* updateUser )
	{
		for( int i = 0; i < 4; i++ )
		{
			if( !strcmp( m_ltgRUser[i].user.strID, updateUser->user.strID ) )
			{
				m_ltgRUser[i] = *updateUser;
				break;
			}
		}
	}

	void changeMajor( void );

	void resetRoom( void );

	BOOL checkReady( void );
	BOOL GetIsStartGame( void ) { return m_bStartGame; }
	void setStartGame(BOOL startState) { m_bStartGame = startState;}
	BOOL ExitCounting( DWORD count );
	/************************************************************************/
	/* 050522(��) ��ŷ ���� A - ���
	/************************************************************************/	
	void setgruserChangeScore(int index, DWORD value);
	void setgruserSetScore(int index, DWORD value);
	DWORD	m_dwPlusScore[4];
	DWORD	m_Rank;
	/************************************************************************/

	USER	m_myUser;
	GRUSER	m_ltgRUser[4];
	bool isCal;
	bool isSend;
	void setmMyUser(int index, DWORD score)
	{
		m_myUser.dwScore = m_ltgRUser[index].user.dwScore;
	}
};

inline RGClient* getClient()
{ 
	return RGClient::GetInstance(); 
}

#endif // _RGClinet_H_
