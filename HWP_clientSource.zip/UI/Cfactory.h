#pragma once
#include <string>
#include "CUIControl.h"
#include "CUIButton.h"
#include "CUIDialogbox.h"
#include "TextBox.h"
#include "UIImagebox.h"

using namespace std;

class Cfactory
{
public:
	Cfactory(void);
public:
	~Cfactory(void);
	CUIControl* createControl(string _type, string _name);
	CUIControl* createControl(string _type, string _name, int _x, int _y, int _height, int _width);
};
