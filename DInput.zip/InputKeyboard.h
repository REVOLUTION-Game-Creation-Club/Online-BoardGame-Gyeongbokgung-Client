#ifndef __INPUT_KEYBOARD_H__
#define __INPUT_KEYBOARD_H__

#include "InputData.h"

namespace rev {

	class CInputKeyboard
	{
	private :
		LPDIRECTINPUT			m_lpDI;
		LPDIRECTINPUTDEVICE		m_lpDevice;

		CallBackImmediateKeyboard	m_pfImmediate;
		CallBackBufferedKeyboard	m_pfBuffered;


	protected :
		// Keyboard Data
		int		m_nBufferSize;
		int		m_nReadDataMode;	// 0 - immediate, 1 - buffered
		bool	m_bWinKeyEnable;

		LPDIDEVICEOBJECTDATA	m_lpdidod;
		
		// Keyboard Method
		bool createDirectInputDevice();
		bool setDataFormat();
		bool setBehavior( HWND _hWnd, DWORD _dwFlags );
		bool gainAccess();

		void readImmediateData();
		void readBufferedData();

	public :
		CInputKeyboard();
		virtual ~CInputKeyboard();

		bool initialize( LPDIRECTINPUT _lpDI );
		void setImmediateFunc( CallBackImmediateKeyboard _pfImmediate )	{ m_pfImmediate = _pfImmediate;	}
		void setBufferedFunc( CallBackBufferedKeyboard _pfBuffered )	{ m_pfBuffered	= _pfBuffered;	}
		bool create( HWND _hWnd, DWORD _dwFlags, DWORD _dwMode, int _nBufferSize, bool _bWinKeyEnable );
		bool destroy();
		void process();
		void active( bool _bActive );
	};

};

#endif	//__INPUT_KEYBOARD_H__