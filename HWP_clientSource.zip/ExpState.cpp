#include "stdafx.h"
#include "ExpState.h"
#include "Map.h"
#include "../RevSound/SoundManager.h"
#include "GameManager.h"
#include "PlayState.h"
#include "DrawManager.h"

using namespace rev;

CExpState::CExpState(CCharacter* _character)
{
	this->m_character	= _character;
	m_count				= 0;
	m_effectCount		= 0;
}

CExpState::~CExpState()
{
}

void CExpState::stateStart()
{
}

void CExpState::stateEnd()
{
}

void CExpState::draw(DWORD _timeDelta)
{
	UNREFERENCED_PARAMETER(_timeDelta);
	CPlayState* playState = (CPlayState*)CGameManager::getInstance()->getState(GAME_STATE_PLAY);

	// ĳ���� �Ѹ�
	if(m_count == 0)
	{
		getSoundManager()->play("����ġ ȹ��");
		drawExpCharacter();
		m_count++;
	}
	else if(m_count < SPRITE_NUM_DELAY*SPRITE_NUM_EXP )
	{
		drawExpCharacter();
		m_count++;
	}
	else if(m_count == SPRITE_NUM_DELAY*SPRITE_NUM_EXP )
	{
		playState->getEffect()->setVisible(true);
		CDrawManager::getInstance()->makeCharacterTopLayer(playState->getEffect()->getOrder());
		m_effectCount++;
		m_count++;
		drawExpCharacter();
	}

	// ����Ʈ �Ѹ�
	else if(m_effectCount < SPRITE_NUM_DELAY*SPRITE_NUM_EFFECT )
	{
		drawExpCharacter();
		drawExpEffect();
		m_effectCount++;
	}

	else if(m_effectCount == SPRITE_NUM_DELAY*SPRITE_NUM_EFFECT)
	{
		drawExpCharacter();
		drawExpEffect();
		playState->getEffect()->setVisible(false);
		m_effectCount = 0;
		m_count = 0;
		// ������ ��������Ʈ ��� �Ŀ� CHARACTER_STATE_WALK�� ��ȯ
		m_character->setCharacterState(CHARACTER_STATE_WALK);
	}
	else
	{
		drawExpCharacter();
		drawExpEffect();
		m_effectCount = 0;
		m_count = 0;
	}
}

void CExpState::drawExpCharacter()
{
	CPlayState* playState = (CPlayState*)CGameManager::getInstance()->getState(GAME_STATE_PLAY);
	m_character->setSize(150,150);

	POINT position;
	position.x = m_character->getCenterPoint().x - 75 - playState->getMap()->getScreenPoint().x;
	position.y = m_character->getCenterPoint().y - 125 - playState->getMap()->getScreenPoint().y;
	m_character->setPosition(position);

	m_character->setSpriteType(SPRITE_TYPE_EXP);

	m_character->setSpriteNo(m_count/SPRITE_NUM_DELAY%SPRITE_NUM_EXP);
	m_character->BitBlt();
}

void CExpState::drawExpEffect()
{
	CPlayState* playState = (CPlayState*)CGameManager::getInstance()->getState(GAME_STATE_PLAY);

	POINT position;
	position.x = m_character->getCenterPoint().x - 100 - playState->getMap()->getScreenPoint().x;
	position.y = m_character->getCenterPoint().y - 150 - playState->getMap()->getScreenPoint().y;

	playState->getEffect()->setPosition(position);
	playState->getEffect()->setSpriteType(2); // ����ġȹ��
	playState->getEffect()->setSpriteNo(m_effectCount/SPRITE_NUM_DELAY%SPRITE_NUM_EFFECT);
}
