#ifndef __WalkState_h__
#define __WalkState_h__
#include "ICharacterState.h"
#include "Character.h"
#include "Map.h"
class CWalkState : public ICharacterState
{
private:
	CCharacter*				m_character;
	POINT					m_termPoint;
	int						m_count;

	int						m_walkCount;
	int						m_tileIndex;
	TileInfo				m_nowTile;
	TileInfo				m_nextTile;

	POINT					m_centerPoint;
	POINT					m_targetPoint;

	CMap*					m_map;
	bool					m_firstItemFlag;
	bool					m_bUseItem;
public:
							CWalkState(CCharacter* _character);
	virtual					~CWalkState();
	void					initialize();
	void					release();
	void					stateStart();
	void					stateEnd();
	void					draw(DWORD _timeDelta);
	void					drawWalkCharacter();
	void					finish();

	
private :
	BOOL walkCountZero();
	void walkCountMinus();
	void walkCountPlus();

	void passTile();
	void stopTile();
	void startTile();
	void endTile();

	void turnOut();

	BOOL checkCharOnTile(ITEM_KIND _selectItem);
	BOOL checkWaterOnTile();
	ITEM_KIND selectItem();
};

#endif