#include "TZQueue.h"
#include "../AMLeak.h"

CTZQueue::CTZQueue(void)
{
	m_pHead = NULL;
	m_pTail = NULL;
	InitializeCriticalSection(&m_Critical);

	m_count = 0;

}

CTZQueue::~CTZQueue(void)
{

}

void CTZQueue::InitializeCS(void)
{
	InitializeCriticalSection(&m_Critical);
}

void CTZQueue::DeleteCS(void)
{
	DeleteCriticalSection(&m_Critical);
}

DATAUNIT* CTZQueue::GetDataUnit(int packetlen)
{
	DATAUNIT *newDataUnit = NULL;
	
	// Allocate the object
	newDataUnit = (DATAUNIT*)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(DATAUNIT));
	if(newDataUnit == NULL)
	{
		// [ Insert Error Process Routine ]
		ExitProcess(-1);
	}

	// Allocate the buffer
	newDataUnit->pPacket = (SNAKE_PACKET*)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(BYTE)*packetlen);
	if(newDataUnit->pPacket == NULL)
	{
		// [ Insert Error Process Routine ]
		ExitProcess(-1);
	}

	newDataUnit->packetlen = packetlen;
	newDataUnit->addrlen = sizeof(newDataUnit->addr);

	return newDataUnit;
}

void CTZQueue::FreeDataUnit(DATAUNIT *freeDataUnit)
{
	HeapFree(GetProcessHeap(), 0, freeDataUnit->pPacket);
	HeapFree(GetProcessHeap(), 0, freeDataUnit);
}

void CTZQueue::EnqueueDataUnit(DATAUNIT *addDataUnit)
{

	EnterCriticalSection(&m_Critical);
	if(m_pHead == NULL)
	{
		// Queue is empty
		m_pHead = m_pTail = addDataUnit;
		m_count++;
	}
	else
	{
		// put new object at the end
		m_pTail->pNext = addDataUnit;
		m_pTail = addDataUnit;

		m_count++;
	}
	LeaveCriticalSection(&m_Critical);

}

DATAUNIT *CTZQueue::DequeueDataUnit(void)
{
	DATAUNIT *deleteDataUnit = NULL;

	EnterCriticalSection(&m_Critical);
	if(m_pTail != NULL)
	{
		// Queue is non empty
		deleteDataUnit = m_pHead;
		m_pHead = m_pHead->pNext;

		if(m_pTail == deleteDataUnit)
		{
			// Item is the only item in the queue
			m_pTail = NULL;
		}
		m_count--;
	}
	LeaveCriticalSection(&m_Critical);	

//	g_packetLog.printString("LeaveCriticalSection");
//	g_packetLog.lockCount(&m_Critical);
//	g_packetLog.QueueCount(m_count);

	return deleteDataUnit;
}

void CTZQueue::DequeueAll( void )
{

	while( m_count == 1)
	{
		DequeueDataUnit();
	}
}

void CTZQueue::DataUnitHeaderInit(DATAUNIT *initDataUnit)
{
	// Setting Header Packet
	strcpy(initDataUnit->pPacket->HEADER.HEAD.pr_name, "snakeon");
	initDataUnit->pPacket->HEADER.HEAD.version	= 100;
	initDataUnit->pPacket->HEADER.HEAD.key		= 0;
	//
	//initDataUnit->pPacket->HEADER.HEAD.length	= 26;
	//
}
