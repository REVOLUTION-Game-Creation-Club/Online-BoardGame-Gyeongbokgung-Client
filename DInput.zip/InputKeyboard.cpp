#include "InputKeyboard.h"

namespace rev {
CInputKeyboard::CInputKeyboard()
{
	m_lpDI			= 0;
	m_lpDevice		= 0;
	m_lpdidod		= 0;

	m_pfImmediate	= 0;
	m_pfBuffered	= 0;
}

CInputKeyboard::~CInputKeyboard()
{
}

bool CInputKeyboard::initialize( LPDIRECTINPUT _lpDI )
{
	m_lpDI = _lpDI;

	return true;
}

bool CInputKeyboard::create( HWND _hWnd, DWORD _dwFlags, DWORD _dwMode, int _nBufferSize, bool _bWinKeyEnable  )
{
	HRESULT hr;

	//------------------------------------//
	//
	m_nBufferSize	= _nBufferSize;
	m_nReadDataMode	= _dwMode;
	m_bWinKeyEnable = _bWinKeyEnable;
	//------------------------------------//

	if( !createDirectInputDevice() )
		return false;

	else if( !setDataFormat() )
		return false;

	else if( !setBehavior( _hWnd, _dwFlags ) )
		return false;
	
	// buffered mode
	if( m_nReadDataMode )
	{
		DIPROPDWORD dipdw;

		dipdw.diph.dwSize       = sizeof(DIPROPDWORD);
		dipdw.diph.dwHeaderSize = sizeof(DIPROPHEADER);
		dipdw.diph.dwObj        = 0;
		dipdw.diph.dwHow        = DIPH_DEVICE;
		dipdw.dwData            = m_nBufferSize;

		if( FAILED( hr = m_lpDevice->SetProperty( DIPROP_BUFFERSIZE, &dipdw.diph ) ) )
			return false;

		m_lpdidod = new DIDEVICEOBJECTDATA[m_nBufferSize];
	}

	
	if( !gainAccess() )
		return false;
	
	return true;
}

bool CInputKeyboard::destroy()
{
	if( m_lpdidod )
		delete m_lpdidod;
	
	if( m_lpDevice )
	{
		m_lpDevice->Unacquire();
		m_lpDevice->Release();
		m_lpDevice = NULL;
	}

	return true;
}

void CInputKeyboard::readImmediateData()
{
    char     buffer[256]; 
    HRESULT  hr; 
    hr = m_lpDevice->GetDeviceState(sizeof(buffer),(LPVOID)&buffer); 

	if( FAILED( hr ) )
	{
		hr = m_lpDevice->Acquire();

		while( hr == DIERR_INPUTLOST )
			hr = m_lpDevice->Acquire();

		return;
	}

    (*m_pfImmediate)( buffer );
}

void CInputKeyboard::readBufferedData()
{
	HRESULT	hr;
	DWORD	dwElements = m_nBufferSize;

	hr = m_lpDevice->GetDeviceData( sizeof( DIDEVICEOBJECTDATA ), m_lpdidod, &dwElements, 0 );

	if( FAILED( hr ) )
	{
		hr = m_lpDevice->Acquire();

		while( hr == DIERR_INPUTLOST )
			hr = m_lpDevice->Acquire();

		return;
	}

	char buf[128]={0};
	for( DWORD i = 0 ; i < dwElements ; i++ )
	{
		(*m_pfBuffered)( m_lpdidod[i].dwOfs, m_lpdidod[i].dwData & 0x80 );
	}
}

void CInputKeyboard::process()
{
	if( m_nReadDataMode )
		readBufferedData();
	else
		readImmediateData();
}

void CInputKeyboard::active( bool _bActive )
{
	if( _bActive )
		m_lpDevice->Acquire();
	else
		m_lpDevice->Unacquire();
}

bool CInputKeyboard::createDirectInputDevice()
{
	HRESULT hr = m_lpDI->CreateDevice(GUID_SysKeyboard, &m_lpDevice, NULL); 
	if( FAILED(hr) )
	{
		return false;
	} 

	return true;
}

bool CInputKeyboard::setDataFormat()
{
	HRESULT hr;

	hr = m_lpDevice->SetDataFormat( &c_dfDIKeyboard );
	if( FAILED( hr ) )
	{
		return false;
	}

	return true;
}

bool CInputKeyboard::setBehavior( HWND _hWnd, DWORD _dwFlags )
{
	HRESULT hr;

	if( m_bWinKeyEnable == false && _dwFlags == FLAG_NONEXCLUSIVE_FOREGROUND )
	{
		_dwFlags |= DISCL_NOWINKEY;
	}

	hr = m_lpDevice->SetCooperativeLevel( _hWnd, _dwFlags );
	if( FAILED( hr ) )
	{
		return false;
	}

	return true;
}


bool CInputKeyboard::gainAccess()
{
	m_lpDevice->Acquire();
	
	return true;
}


};