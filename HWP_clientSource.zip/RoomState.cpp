#include "StdAfx.h"
#include "RoomState.h"
#include "UserManager.h"
#include "DrawManager.h"
#include "UI/CUIManager.h"
#include "MessageManager.h"
#include "PrintObject.h"

/*

"room"
	+ "CharInfoShowBoy"
	+ "CharInfoShowGirl"
	+ "CharInfoShowGiant"

	+ "CharInfoBoy"
	+ "CharInfoGirl"
	+ "CharInfoGiant"

	+ "CharSelect11"
	+ "CharSelect12"

	+ "CharSelect21"
	+ "CharSelect22"

	+ "CharSelect31"
	+ "CharSelect32"

	+ "CharSelect41"
	+ "CharSelect42"

	+ "Ready"
	+ "Exit"

	+ "Map"

	+ "ChatList"
	+ "ChatInput"
*/

static char*	ROOM_IMAGE_BACK_PATH = "image/room_background.bmp";
static char*	ROOM_IMAGE_BTN_PATH = "image/room_button.bmp";

// int _x, int _y, int _width, int _height, int _texX, int _texY


// �� ������ ����Ű�� ��ǥ.... ���� �� ������ ����Ű�� �ִ�.
static int		ROOM_MY_FLAG_POINTS[]
= { 579, 59, 66, 70, 958, 800 };

static int		READY_SLOT_POINTS_1[]
= { 904, 45, 116, 30, 908, 870 };

static int		READY_SLOT_POINTS_2[]
= { 904, 187, 116, 30, 908, 870 };

static int		READY_SLOT_POINTS_3[]
= { 904, 322, 116, 30, 908, 870 };

static int		READY_SLOT_POINTS_4[]
= { 904, 457, 116, 30, 908, 870 };

static int		ROOM_POINTS[]				= { 0, 0, 
												1024, 768, 
												0, 0 };

// ���ʾƷ��� ū â
static int		CHAR_INFO_SHOW_BOY_POINTS[]
= { 0, 413, 340, 355, 684, 0 };

static int		CHAR_INFO_SHOW_GIRL_POINTS[]
= { 0, 411, 340, 355, 684, 355 };

static int		CHAR_INFO_SHOW_GIANT_POINTS[]
= { 0, 414, 340, 355, 2, 668 };

// ĳ�� ���� ��ư
static int		CHAR_INFO_BOY_POINTS[]		
= { 304, 569, 120,  40, 0, 0 };

static int		CHAR_INFO_GIRL_POINTS[]		
= { 304, 607, 120,  40, 0, 40 };

static int		CHAR_INFO_GIANT_POINTS[]	
= { 304, 645, 120,  40, 0, 80 };

static int		CHAR_SEL_11_POINTS[]		
= { 661, 29, 117, 122, 0, 450 };


static int		CHAR_SEL_12_POINTS[]		= { 781, 29, 
												117, 122,
												0, 450 };

static int		CHAR_SEL_21_POINTS[]		= { 659, 164, 
												117, 122,
												0, 450 };

static int		CHAR_SEL_22_POINTS[]		= { 779, 164, 
												117, 122,
												0, 450 };

static int		CHAR_SEL_31_POINTS[]		= { 661, 299, 
												117, 122,
												0, 450 };

static int		CHAR_SEL_32_POINTS[]		= { 781, 299, 
												117, 122,
												0, 450 };

static int		CHAR_SEL_41_POINTS[]		= { 660, 431, 
												117, 122,
												0, 450 };

static int		CHAR_SEL_42_POINTS[]		= { 780, 431, 
												117, 122,
												0, 450 };

static int		START_POINTS[]
= { 407, 670, 94, 95, 0, 572 };

static int		READY_POINTS[]	
= { 407, 670, 94, 95, 0, 260 };

// exit button
static int		EXIT_POINTS[]	
= { 8, 359, 72, 72, 0, 120 };

static int		MAP[]
= { 154, 352, 68, 68, 0, 192 };


static int		CHAT_LIST_POINTS[]	
= { 535, 598, 0, 0, 0, 0 };

static int		CHAT_INPUT_POINTS[]	
= { 540, 717, 0, 0, 0, 0 };

CRoomState::CRoomState(CGameManager* _gameManager)
{
	this->m_gameManager = _gameManager;

	m_pMyInfo = NULL;
	m_printRoomName = NULL;

	for( int i=0 ; i<MAX_ROOM_USER ; i++ )
	{
		m_printID[i] = NULL;
	}

	resetData();
}

CRoomState::~CRoomState()
{
	resetData();
}

bool	CRoomState::initialize()

{
	m_nCountConnectedClient = 0;
	m_bStarted = FALSE;
	makeUI();
	processNetwork();
	UpdateUI();

	// �� �������
	getSoundManager()->play( "��", true );

	return true;
}
void 
CRoomState::release()
{
	CUIManager& manager = CUIManager::getInstance();

	CDrawManager::getInstance()->eraseObject(DRAW_OBJECT_INTERFACE, manager.getUIDraw(0)->getOrder());
	CDrawManager::getInstance()->eraseObject(DRAW_OBJECT_INTERFACE, manager.getUIDraw(1)->getOrder());
	CDrawManager::getInstance()->eraseObject(DRAW_OBJECT_INTERFACE, manager.getUIDraw(2)->getOrder());
	for( int i=0 ; i<MAX_ROOM_USER ; i++ )
	{
		CDrawManager::getInstance()->eraseObject( DRAW_OBJECT_INTERFACE, m_printID[i]->getOrder() );
	}

	CDrawManager::getInstance()->eraseObject( DRAW_OBJECT_INTERFACE, m_printRoomName->getOrder() );

	CDrawManager::getInstance()->eraseList();

	CUIManager::getInstance().destroyAllContainer();

	getSoundManager()->stop( "��" );

	return;
}

void	
CRoomState::onKeyboard(WPARAM _wParam)
{
	if( _wParam == VK_RETURN )
	{
		CUIManager::getInstance().on_Enter_KeyDown();
	}
}

void	
CRoomState::processMouseMove()
{
	return;
}


void	
CRoomState::onUpdate()
{
	return;
}

void	
CRoomState::onButtonExit()
{
	// lobby �� ������
	Packet packet( REQ_LEAVE_ROOM );

	packet << CUserManager::getInstance()->getMyUserName() << m_nRoomNumber;
	CMessageManager::getInstance()->sendMessageToMainServer( packet );

	//CGameManager::getInstance()->setState( GAME_STATE_PLAY );
}


void	
CRoomState::onButtonReady()
{
	Packet packet;

	if( !m_pMyInfo )
		return;

	if( m_pMyInfo->bMaster )
	{
		int nUserCount = numPlayer();
		// ���� ������ �����ϵ��� ĳ���� ������ ���� ���� ���� ����
		if( nUserCount > 2 )
		{
			// ĳ�� �ϳ�
			if( m_pMyInfo->character[0] == NONE )
			{
				CUIManager::getInstance()["room"].getDialogBox("ChatList").insertString( "ĳ���͸� �����ϼž��� ������ ���� �մϴ�", 40 );

				return;
			}
		}
		else if( nUserCount == 2 )
		{
			// ĳ�� �ΰ�
			// ĳ�� �ϳ�
			if( m_pMyInfo->character[0] == NONE 
				|| m_pMyInfo->character[1] == NONE )
			{
				CUIManager::getInstance()["room"].getDialogBox("ChatList").insertString( "ĳ���͸� �����ϼž��� ������ ���� �մϴ�", 40 );

				return;
			}
		}
		else 
		{
			CUIManager::getInstance()["room"].getDialogBox("ChatList").insertString( "2�� �̻� �濡 �ְ� ��� ��������̸� ������ ���� �մϴ�.", 40 );
			return;
		}

		// 
		// �ٸ� ������ ��� ready�� �ؾ��Ѵ�.
		for( int i=0 ; i<MAX_ROOM_USER ; i++ )
		{
			if( strlen( m_roomUserInfo[i].id ) == 0 )
				continue;

			if( m_roomUserInfo[i].bMaster == false
				&& m_roomUserInfo[i].bReady == false )
			{
				return;
			}
		}

		m_pMyInfo->bReady = true;

		packet.id( REQ_GAME_STARTUP );
		packet << m_nRoomNumber;
	}
	else
	{
		// ready �϶�
		if( !m_pMyInfo->bReady )
		{
			// ���� ������ �����ϵ��� ĳ���� ������ ���� ���� ���� ����
			if( numPlayer() > 2 )
			{
				// ĳ�� �ϳ�
				if( m_pMyInfo->character[0] == NONE )
				{
					CUIManager::getInstance()["room"].getDialogBox("ChatList").insertString( "ĳ���͸� �����ϼž��� ���� ���� �մϴ�" );

					return;
				}
			}
			else
			{
				// ĳ�� �ΰ�
				// ĳ�� �ϳ�
				if( m_pMyInfo->character[0] == NONE 
					|| m_pMyInfo->character[1] == NONE )
				{
					CUIManager::getInstance()["room"].getDialogBox("ChatList").insertString( "ĳ���͸� �����ϼž��� ���� ���� �մϴ�" );

					return;
				}
			}

			packet.id( REQ_IM_READY );
			packet << m_pMyInfo->id << m_nRoomNumber;
		}
		// wait�϶�
		else 
		{
			packet.id( REQ_WAIT_PLZ );		
			packet << m_pMyInfo->id << m_nRoomNumber;
		}
	}

	CMessageManager::getInstance()->sendMessageToMainServer( packet );
}


// ĳ���� ��ȣ�� ������ ���� �ο���
// 0:����, 1:����, 2:����, 3:����
void	
CRoomState::OnButtonChar1()
{
	// button�� ���¸� ���´�.
	// �� button�� ���°� pressed�̸� �� ĳ���� ������ �Ѵ�.
	// �� button�� ���°� 

	//if( m_nSelectCharInfo == NONE )

	if( !m_pMyInfo )
		return;
		

	if( m_nSelectCharInfo == BOY )
	{
		// �� ������ ������ ĳ������ �ε����� ���� �ִ´�
		m_pMyInfo->character[ m_nSelectColumn ] = BOY;

		// ĳ���� ����
		Packet	packet( REQ_CHARACTOR_CHANGE );

		packet << m_pMyInfo->id << m_nRoomNumber << m_pMyInfo->character[0] << m_pMyInfo->character[1];
		CMessageManager::getInstance()->sendMessageToMainServer( packet );

		if( hasSecond() )
			m_nSelectColumn ^= SECOND;

		return;
	}

	m_nSelectCharInfo = BOY;
}

void	
CRoomState::OnButtonChar2()
{
	// button�� ���¸� ���´�.
	// �� button�� ���°� pressed�̸� �� ĳ���� ������ �Ѵ�.
	// �� button�� ���°� 

	//if( m_nSelectCharInfo == NONE )

	if( !m_pMyInfo )
		return;

	if( m_nSelectCharInfo == GIRL )
	{
		// �� ������ ������ ĳ������ �ε����� ���� �ִ´�
		m_pMyInfo->character[ m_nSelectColumn ] = GIRL;

		// ĳ���� ����
		Packet	packet( REQ_CHARACTOR_CHANGE );

		packet << m_pMyInfo->id << m_nRoomNumber << m_pMyInfo->character[0] << m_pMyInfo->character[1];
		CMessageManager::getInstance()->sendMessageToMainServer( packet );

		if( hasSecond() )
			m_nSelectColumn ^= SECOND;

		return;
	}

	m_nSelectCharInfo = GIRL;
}

void	
CRoomState::OnButtonChar3()
{
	// button�� ���¸� ���´�.
	// �� button�� ���°� pressed�̸� �� ĳ���� ������ �Ѵ�.
	// �� button�� ���°� 

	//if( m_nSelectCharInfo == NONE )


	if( !m_pMyInfo )
		return;

	if( m_nSelectCharInfo == GIANT )
	{
		// �� ������ ������ ĳ������ �ε����� ���� �ִ´�
		m_pMyInfo->character[ m_nSelectColumn ] = GIANT;

		// ĳ���� ����
		Packet	packet( REQ_CHARACTOR_CHANGE );

		packet << m_pMyInfo->id << m_nRoomNumber << m_pMyInfo->character[0] << m_pMyInfo->character[1];
		CMessageManager::getInstance()->sendMessageToMainServer( packet );

		if( hasSecond() )
			m_nSelectColumn ^= SECOND;

		return;
	}

	m_nSelectCharInfo = GIANT;
}

bool	
CRoomState::isCharSelectButtonPressed( char* szButtonName )
{
	CUIManager& manager = CUIManager::getInstance();
	CUIContainer& roomContainer = manager["room"];

	if( roomContainer[ szButtonName ].getState() & REV_PRESSED )
		return true;

	return false;
}


void	
CRoomState::addUser( char* id, int nUserPoint )
{
	// �ٸ� ������ �濡 ���� �ߴٰ� ä��â�� �˷��ش�
	char buf[256];
	wsprintf( buf, "%s���� �����ϼ̽��ϴ�", id );
	CUIManager::getInstance()["room"].getDialogBox("ChatList").insertString( buf, 40 );

	UpdateUI();
}

void	
CRoomState::removeUser( char* removeid, char* masterid )
{
	char buf[256];
	wsprintf( buf, "%s���� �����ϼ̽��ϴ�", removeid );
	CUIManager::getInstance()["room"].getDialogBox("ChatList").insertString( buf, 40 );

	if( strcmp(masterid, "0") )
	{
		wsprintf( buf, "������ %s������ ����Ǿ����ϴ�", masterid );
		CUIManager::getInstance()["room"].getDialogBox("ChatList").insertString( buf, 40 );
	}

	for( int i=0 ; i<MAX_ROOM_USER ; i++ )
	{
		// ���� ����� �����̿�����
		// ���� ������ �˷��ش�
		// ������ �ƴϸ� masterid�� �ƹ� �͵� �� �´�
		// ù ����Ʈ�� 0�̸� ����
		if( !strcmp(masterid, "0") )
		{
			if( !strcmp( masterid, m_roomUserInfo[i].id ) )
			{
				m_roomUserInfo[i].bMaster = true;
				m_roomUserInfo[i].bReady = false;
			}
			else
			{
				m_roomUserInfo[i].bMaster = false;
			}
		}

		// user list ���� removeid�� ã�Ƽ� �����Ѵ�.
		if( !strcmp( removeid, m_roomUserInfo[i].id ) )
		{
			//m_vecRoomUserInfo.erase( m_vecRoomUserInfo.begin() + i );
			memset( &m_roomUserInfo[i], 0, sizeof( ROOMUSERINFO ) );
		}
	}

	UpdateUI();
}

void	
CRoomState::changeReady( char* id, bool bReady )
{
	for( int i=0 ; i<MAX_ROOM_USER ; i++ )
	{
		if( !strcmp( m_roomUserInfo[i].id, id ) )
		{
			m_roomUserInfo[i].bReady = bReady;
		}
	}

	UpdateUI();
}

LPROOMUSERINFO	
CRoomState::findRoomUserInfo( char* id )
{
	return NULL;
}


void 
CRoomState::action()
{


	// ���� ������ Ȯ�� ��ư
	if(getEvented().compare("disconnectedAcceptButton") == 0)
	{
		getSoundManager()->play( "��ưŬ��1" );
		PostQuitMessage(0);
	}

	if( !m_pMyInfo )
		return;

	// ������ ���� �Ǿ����� ��� �Է��� ���´�.
	if( m_bStarted )
		return;

	// ������ ������ ���
	if( getEvented().compare("Exit") == 0)
	{
		getSoundManager()->play( "��ưŬ��1" );
		onButtonExit();
		return;
	}

	if( getEvented().compare( "Ready" ) == 0)
	{
		getSoundManager()->play( "��ưŬ��3" );
		onButtonReady();
		UpdateUI();
		return;
	}

	if( getEvented().compare( "CharInfoBoy" ) == 0)
	{
		getSoundManager()->play( "��ưŬ��2" );
		if( m_pMyInfo->bReady )
			return;

		OnButtonChar1();
		UpdateUI();
		return;
	}

	if( getEvented().compare( "CharInfoGirl" ) == 0)
	{
		getSoundManager()->play( "��ưŬ��2" );
		if( m_pMyInfo->bReady )
			return;

		OnButtonChar2();
		UpdateUI();
		return;
	}

	if( getEvented().compare( "CharInfoGiant" ) == 0)
	{
		getSoundManager()->play( "��ưŬ��2" );
		if( m_pMyInfo->bReady )
			return;

		OnButtonChar3();
		UpdateUI();
		return;
	}

	if( getEvented().compare( "CharSelect11" ) == 0)
	{
		OnButtonCharSelect( 0, 0 );
		return;
	}

	if( getEvented().compare( "CharSelect12" ) == 0)
	{
		OnButtonCharSelect( 0, 1 );
		return;
	}

	if( getEvented().compare( "CharSelect21" ) == 0)
	{
		OnButtonCharSelect( 1, 0 );
		return;
	}

	if( getEvented().compare( "CharSelect22" ) == 0)
	{
		OnButtonCharSelect( 1, 1 );
		return;
	}

	if( getEvented().compare( "CharSelect31" ) == 0)
	{
		OnButtonCharSelect( 2, 0 );
		return;
	}

	if( getEvented().compare( "CharSelect32" ) == 0)
	{
		OnButtonCharSelect( 2, 1 );
		return;
	}

	if( getEvented().compare( "CharSelect41" ) == 0)
	{
		OnButtonCharSelect( 3, 0 );
		return;
	}

	if( getEvented().compare( "CharSelect42" ) == 0)
	{
		OnButtonCharSelect( 3, 1 );
		return;
	}

	// �� ����
	// ���� ��
	if( getEvented().compare("Map") == 0)
	{
		UpdateUI();
		return;
	}

	// ä�� �޽��� ó��
}

void 
CRoomState::textChanged()
{
	// ������ ���� �Ǿ����� ��� �Է��� ���´�.
	if( m_bStarted )
		return;

	getIME()->setPos(540, 720);
	
	char temp[128] = {0};
	getIME()->GetStr( temp, 128 );

	CUIManager::getInstance()["room"].getTextBox("ChatInput").changeString(temp);
}

void 
CRoomState::pressReturn() 
{
	// ������ ���� �Ǿ����� ��� �Է��� ���´�.
	if( m_bStarted )
		return;

	CUIDialogbox& chatlist = CUIManager::getInstance()["room"].getDialogBox("ChatList");
	CTextBox& chat = CUIManager::getInstance()["room"].getTextBox("ChatInput");	

	char* text = chat.getString();
	if( *text == 0 )
		return;

	Packet packet(REQ_CHAT);
	packet << CUserManager::getInstance()->getMyUserName() << m_nRoomNumber << text;
	CMessageManager::getInstance()->sendMessageToMainServer(packet);

	getIME()->ClearBufstr();
}

// data �ʱ�ȭ
void	
CRoomState::resetData()
{
	m_nCountConnectedClient = 0;
	m_nSelectCharInfo = NONE;
	m_nSelectColumn	= FIRST;
	m_bStarted		= FALSE;

	for( int i=0 ; i<MAX_ROOM_USER ; i++ )
	{
		if( m_printID[i] )
		{
			delete m_printID[i];
			m_printID[i] = NULL;
		}
	}

	if( m_printRoomName )
	{
		delete m_printRoomName;
		m_printRoomName = NULL;
	}
	
	m_nRoomNumber	= 0;

	m_pMyInfo = NULL;
	memset( m_roomUserInfo, 0, sizeof( ROOMUSERINFO ) * MAX_ROOM_USER );
	memset( m_szRoomName, 0, ROOM_ID_LENGTH );
}

void	
CRoomState::changeChar( char* id, int char1, int char2 )
{
	LPROOMUSERINFO pUser = findRoomUserInfo( id );

	if( !pUser )
		return;

	pUser->character[0] = char1;
	pUser->character[1] = char2;

	UpdateUI();
}

void	
CRoomState::OnButtonCharSelect( int row, int column )
{

	if( !m_pMyInfo )
		return;
	if( m_pMyInfo->bReady )
		return;

	if( m_pMyInfo->row != row )
		return;

	getSoundManager()->play( "��ưŬ��3" );

	if( hasSecond() == TRUE )
		m_nSelectColumn = column;

	UpdateUI();
}

void	
CRoomState::UpdateUI()
{
	if( !m_pMyInfo )
		return;


	CUIManager& manager = CUIManager::getInstance();
	CUIContainer& roomContainer = manager["room"];

	// ������ ȭ�鿡 ���
	m_printRoomName->setString( m_szRoomName );

	//CUIContainer& roomContainer = CUIManager::getInstance()["room"];
	// �� ���¸� �˾ƿͼ� UI������Ʈ
	// ��ư 8���� �濡 �ִ� �ο��� 2�������̸� ĳ���� 2��, �ƴϸ� 1���̴�.
	// �̶� 2��° ĳ���� ��ư�� ��Ȱ��ȭ�� ��Ų��

	const char* READY_SLOT[] = { "SlotReady1", "SlotReady2", "SlotReady3", "SlotReady4" };
	const char* CHAR_SLOT[MAX_ROOM_USER][2] = { {"CharSelect11", "CharSelect12"}, {"CharSelect21", "CharSelect22"},
								  {"CharSelect31", "CharSelect32"}, {"CharSelect41", "CharSelect42"}};

	// �� ������ ������� �˾ƿͼ� ȭ�鿡 ��� ��Ų��.
	const static int FLAG_POINTS[] = { 59, 199, 332, 468 };
	roomContainer.getImageBox( "SlotFlag" ).setPosition( 579, FLAG_POINTS[m_pMyInfo->row] );

	int nPlayerCount = numPlayer();

	// 3�� �̻��� ������ ���ù�ư�� ó������ �ٲ۴�
	if( nPlayerCount > 2 )
		m_nSelectColumn = FIRST;

	// ���° ĳ���͸� �����ߴ��� �����ش�
	const static int SELECT_FLAG_X[] = { 710, 831 };		// ��ǥ ����
	const static int SELECT_FLAG_Y[] = { 19, 153, 288, 421 };// ��ǥ ����
	//{ 579, 59, 20, 15, 938, 855 };
	roomContainer.getImageBox( "SelectFlag" ).setPosition( SELECT_FLAG_X[ m_nSelectColumn ], SELECT_FLAG_Y[m_pMyInfo->row] );
	roomContainer.getImageBox( "SelectFlag" ).setVisible( true );

	for( int i=0 ; i<MAX_ROOM_USER ; i++ )
	{
		// ��ư ������ ���̵� ����� ��Ų��.
		//if( strlen( m_roomUserInfo[i].id ) )
		//{
			m_printID[i]->setString( m_roomUserInfo[i].id );
		//}


		// ������ ǥ�� �� �Ѵ�
		// ready ���¿� ���� ��ư �ٲٱ�->wait
		// ready�̸� ��� �ƴϸ� visible = false
		if( m_roomUserInfo[i].bReady && m_roomUserInfo[i].bMaster == FALSE )
		{
			roomContainer.getImageBox( READY_SLOT[i] ).setVisible( true );
		}
		else
			roomContainer.getImageBox( READY_SLOT[i] ).setVisible( false );

		// ĳ���� ������ �о�ͼ� ȭ�鿡 ���
		// 3�� �̻��̸�......2��° ĳ�� ��Ȱ��ȭ�� ǥ��
		for( int k=0 ; k<2 ; k++ )
		{
			roomContainer.getButton( CHAR_SLOT[i][k] ).setVisible( true );

			if( k == 1 && nPlayerCount > 2 )
			{
				switch( m_roomUserInfo[i].character[k] )
				{
				case NONE :
					roomContainer.getButton( CHAR_SLOT[i][k] ).setVisible( false );
					break;

				case BOY :
					roomContainer.getButton( CHAR_SLOT[i][k] ).setValue( 288, 120, ROOM_IMAGE_BTN_PATH );
					break;

				case GIRL :
					roomContainer.getButton( CHAR_SLOT[i][k] ).setValue( 405, 120, ROOM_IMAGE_BTN_PATH );
					break;

				case GIANT :
					roomContainer.getButton( CHAR_SLOT[i][k] ).setValue( 522, 120, ROOM_IMAGE_BTN_PATH );
					break;
				}
			}
			else
			{
				switch( m_roomUserInfo[i].character[k] )
				{
				case NONE :
					roomContainer.getButton( CHAR_SLOT[i][k] ).setVisible( false );
					break;

				case BOY :
					roomContainer.getButton( CHAR_SLOT[i][k] ).setValue( 0, 450, ROOM_IMAGE_BTN_PATH );
					break;

				case GIRL :
					roomContainer.getButton( CHAR_SLOT[i][k] ).setValue( 117, 450, ROOM_IMAGE_BTN_PATH );
					break;

				case GIANT :
					roomContainer.getButton( CHAR_SLOT[i][k] ).setValue( 234, 450, ROOM_IMAGE_BTN_PATH );
					break;
				}
			}
		}
	}

	// �����̸� start��ư ���
	if( m_pMyInfo->bMaster )
	{
		// �ٸ� ������ ��� ���� ������ Ȱ��ȭ ǥ��....
		//
		int countReady = 0;
		for( int i=0 ; i<MAX_ROOM_USER ; i++ )
		{
			if( strlen( m_roomUserInfo[i].id ) && m_roomUserInfo[i].bReady )
				countReady++;
		}

		// Ȱ��ȭǥ��
		if( (countReady == (this->numPlayer() - 1) )
			&& (numPlayer() > 1) )
		{
			roomContainer.getButton("Ready").setValue( START_POINTS[0], START_POINTS[1], 94, 
				95, 282, 572, ROOM_IMAGE_BTN_PATH );			
		}
		else
		{
			roomContainer.getButton("Ready").setValue( START_POINTS[0], START_POINTS[1], START_POINTS[2], 
				START_POINTS[3], START_POINTS[4], START_POINTS[5], ROOM_IMAGE_BTN_PATH );
		}
	}
	else
	{
		int* p = READY_POINTS;
		roomContainer.getButton("Ready").setValue( p[0], p[1], p[2], p[3], p[4], p[5], ROOM_IMAGE_BTN_PATH );
	}



	// ready�� �Ǹ� ĳ���� ���ù�ư ��Ȱ��ȭ

	// m_nSelectCharInfo ���� ����â�� �׸� �׷��ֱ�
	switch( m_nSelectCharInfo )
	{
	case NONE :
		roomContainer.getImageBox( "CharInfoShowBoy" ).setVisible( false );
		roomContainer.getImageBox( "CharInfoShowGirl" ).setVisible( false );
		roomContainer.getImageBox( "CharInfoShowGiant" ).setVisible( false );
		break;

	case BOY :
		roomContainer.getImageBox( "CharInfoShowBoy" ).setVisible( true );
		roomContainer.getImageBox( "CharInfoShowGirl" ).setVisible( false );
		roomContainer.getImageBox( "CharInfoShowGiant" ).setVisible( false );
		break;
	case GIRL :
		roomContainer.getImageBox( "CharInfoShowGirl" ).setVisible( true );
		roomContainer.getImageBox( "CharInfoShowBoy" ).setVisible( false );
		roomContainer.getImageBox( "CharInfoShowGiant" ).setVisible( false );
		break;
	case GIANT :
		roomContainer.getImageBox( "CharInfoShowGiant" ).setVisible( true );
		roomContainer.getImageBox( "CharInfoShowBoy" ).setVisible( false );
		roomContainer.getImageBox( "CharInfoShowGirl" ).setVisible( false );
		break;
	}
}

void	
CRoomState::setRoomInformation( int nRoomNumber, LPROOMUSERINFO pUserInfo, char* szRoomName )
{
	m_nRoomNumber = nRoomNumber;

	memcpy( m_roomUserInfo, pUserInfo, sizeof( ROOMUSERINFO ) * MAX_ROOM_USER );

	for( int i=0 ; i<MAX_ROOM_USER ; i++ )
	{
		//�� ������ ���� ����
		if( m_roomUserInfo[i].bMe )
		{
			m_pMyInfo = &m_roomUserInfo[i];
			m_pMyInfo->row = i;
		}
	}

	strcpy( m_szRoomName, szRoomName );

	UpdateUI();
}

void	
CRoomState::setupStartGame( CClientSocket* pClientSocket, char* masterIP )
{
	m_bStarted	= TRUE;

	//{{
	int charid = 0;
	int userid = 0;

	for( int i=0 ; i<MAX_ROOM_USER ; i++ )
	{
		if( strlen( m_roomUserInfo[i].id ) == 0 )
			continue;

		CUser* user = new CUser(userid,m_roomUserInfo[i].id, (USER_TEAM_COLOR)i);

		CCharacter* character1 = new CCharacter(userid, charid++, (CHARACTER_TEAM)i, CHARACTER_KIND(m_roomUserInfo[i].character[0] - 1) );
		character1->setCharacterState(CHARACTER_STATE_NOTEXIST);
		user->insertCharacter(character1);

		CCharacter* character2 = character1;

		if( hasSecond() )
		{
			character2 = new CCharacter(userid, charid++, (CHARACTER_TEAM)i, CHARACTER_KIND(m_roomUserInfo[i].character[1] - 1) );
		}

		user->insertCharacter(character2);
		if( hasSecond() )
		{
			user->setCharacterNum(2);
		}
		else
			user->setCharacterNum(1);

		CUserManager::getInstance()->insertUser(user);

		if( m_roomUserInfo[i].bMe )
			CUserManager::getInstance()->setMyUserId( userid );

		if( m_roomUserInfo[i].bMaster )
			CUserManager::getInstance()->getMyUser()->setMajor(true);

		userid++;
	}
	//}}

	//{{ client server�� connect �Ѵ�
	pClientSocket->connectServer( masterIP, USER_CLIENT_SEND );

	Packet packet( REQ_UserServer_Connect );
	packet << m_pMyInfo->id;
	pClientSocket->sendPacket( packet, USER_CLIENT_SEND );
	//}}

	CUIManager::getInstance()["room"].getDialogBox("ChatList").insertString( "������ �����մϴ�" );
}

void	
CRoomState::chat( char* id, char* msg )
{
	char buf[256];
	wsprintf( buf, "%s : %s", id, msg );
	CUIManager::getInstance()["room"].getDialogBox("ChatList").insertString( buf );
}


BOOL
CRoomState::connectedClient()
{
	m_nCountConnectedClient++;

	if( numPlayer() == m_nCountConnectedClient )
	{
		return TRUE;
	}

	return FALSE;
}

void
CRoomState::disconnect()
{
	CUIManager::getInstance()["roomBackground"].setEnable(FALSE);
	CUIManager::getInstance()["room"].setEnable(FALSE);

	CUIManager::getInstance()["mainDisconnected"].setEnable(TRUE);
}


void	
CRoomState::makeUI()
{
	CUIManager& manager = CUIManager::getInstance();

	int* p = 0;

	// room container
	p = ROOM_POINTS;
	manager.makeContainer("roomBackground", p[0], p[1], p[2], p[3], p[4], p[5], ROOM_IMAGE_BACK_PATH );

	manager.makeContainer("room", 0, 0, 1024, 768, 1020, 1020, ROOM_IMAGE_BTN_PATH );
	CUIContainer& roomContainer = manager["room"];

	// �� ���� ��ư
	// ��
	p = MAP;
	roomContainer.add("button", "Map", p[0], p[1], p[2], p[3], p[4], p[5],ROOM_IMAGE_BTN_PATH );
	roomContainer["Map"].addListener(this);
	roomContainer.getButton("Map").setImageFlag(REV_NORMAL|REV_ROLLOVER|REV_PRESSED|REV_INACTIVE);
	roomContainer.getButton("Map").setVisible( false );
	roomContainer.getButton("Map").setEnable( FALSE );

	// ������
	p = EXIT_POINTS;
	roomContainer.add("button", "Exit", p[0], p[1], p[2], p[3], p[4], p[5],ROOM_IMAGE_BTN_PATH );
	roomContainer["Exit"].addListener(this);
	roomContainer.getButton("Exit").setImageFlag(REV_NORMAL|REV_ROLLOVER|REV_PRESSED|REV_INACTIVE);

	// ready / start
	p = READY_POINTS;
	roomContainer.add( "button", "Ready", p[0], p[1], p[2], p[3], p[4], p[5], ROOM_IMAGE_BTN_PATH );
	roomContainer[ "Ready" ].addListener( this );
	roomContainer.getButton("Ready").setImageFlag(REV_NORMAL|REV_ROLLOVER|REV_PRESSED|REV_INACTIVE);

	// select ����
	p = CHAR_INFO_BOY_POINTS;
	roomContainer.add( "button", "CharInfoBoy", p[0], p[1], p[2], p[3], p[4], p[5], ROOM_IMAGE_BTN_PATH );
	roomContainer[ "CharInfoBoy" ].addListener( this );
	roomContainer.getButton("CharInfoBoy").setImageFlag(REV_NORMAL|REV_ROLLOVER|REV_PRESSED|REV_INACTIVE);

	// select �γ�
	p = CHAR_INFO_GIRL_POINTS;
	roomContainer.add( "button", "CharInfoGirl", p[0], p[1], p[2], p[3], p[4], p[5], ROOM_IMAGE_BTN_PATH );
	roomContainer[ "CharInfoGirl" ].addListener( this );
	roomContainer.getButton("CharInfoGirl").setImageFlag(REV_NORMAL|REV_ROLLOVER|REV_PRESSED|REV_INACTIVE);

	// select ����
	p = CHAR_INFO_GIANT_POINTS;
	roomContainer.add( "button", "CharInfoGiant", p[0], p[1], p[2], p[3], p[4], p[5], ROOM_IMAGE_BTN_PATH );
	roomContainer[ "CharInfoGiant" ].addListener( this );
	roomContainer.getButton("CharInfoGiant").setImageFlag(REV_NORMAL|REV_ROLLOVER|REV_PRESSED|REV_INACTIVE);

	//
	p = CHAR_SEL_11_POINTS;
	roomContainer.add( "button", "CharSelect11",  p[0], p[1], p[2], p[3], p[4], p[5], ROOM_IMAGE_BTN_PATH );
	roomContainer[ "CharSelect11" ].addListener( this );
	roomContainer.getButton("CharSelect11").setVisible( false );

	p = CHAR_SEL_12_POINTS;
	roomContainer.add( "button", "CharSelect12",  p[0], p[1], p[2], p[3], p[4], p[5], ROOM_IMAGE_BTN_PATH );
	roomContainer[ "CharSelect12" ].addListener( this );
	roomContainer.getButton("CharSelect12").setVisible( false );

	p = CHAR_SEL_21_POINTS;
	roomContainer.add( "button", "CharSelect21",  p[0], p[1], p[2], p[3], p[4], p[5], ROOM_IMAGE_BTN_PATH );
	roomContainer[ "CharSelect21" ].addListener( this );
	roomContainer.getButton("CharSelect21").setVisible( false );

	p = CHAR_SEL_22_POINTS;
	roomContainer.add( "button", "CharSelect22",  p[0], p[1], p[2], p[3], p[4], p[5], ROOM_IMAGE_BTN_PATH );
	roomContainer[ "CharSelect22" ].addListener( this );
	roomContainer.getButton("CharSelect22").setVisible( false );

	p = CHAR_SEL_31_POINTS;
	roomContainer.add( "button", "CharSelect31",  p[0], p[1], p[2], p[3], p[4], p[5], ROOM_IMAGE_BTN_PATH );
	roomContainer[ "CharSelect31" ].addListener( this );
	roomContainer.getButton("CharSelect31").setVisible( false );

	p = CHAR_SEL_32_POINTS;
	roomContainer.add( "button", "CharSelect32",  p[0], p[1], p[2], p[3], p[4], p[5], ROOM_IMAGE_BTN_PATH );
	roomContainer[ "CharSelect32" ].addListener( this );
	roomContainer.getButton("CharSelect32").setVisible( false );

	p = CHAR_SEL_41_POINTS;
	roomContainer.add( "button", "CharSelect41",  p[0], p[1], p[2], p[3], p[4], p[5], ROOM_IMAGE_BTN_PATH );
	roomContainer[ "CharSelect41" ].addListener( this );
	roomContainer.getButton("CharSelect41").setVisible( false );

	p = CHAR_SEL_42_POINTS;
	roomContainer.add( "button", "CharSelect42",  p[0], p[1], p[2], p[3], p[4], p[5], ROOM_IMAGE_BTN_PATH );
	roomContainer[ "CharSelect42" ].addListener( this );
	roomContainer.getButton("CharSelect42").setVisible( false );


	// ä��â
	p = CHAT_LIST_POINTS;
	roomContainer.add("dialogbox", "ChatList", p[0], p[1], p[2], p[3], p[4], p[5], ROOM_IMAGE_BTN_PATH);
	CUIDialogbox& chatlist = roomContainer.getDialogBox("ChatList");
	chatlist.setFontPosition(65, 10);
	chatlist.setFontColor(1.0f,1.0f,1.0f,0.8f);
	chatlist.setFontSize(10);
	chatlist.setLineSpace(7);
	chatlist.setRange(5);
	chatlist.setMaxString( 5 );

	p = CHAT_INPUT_POINTS;
	roomContainer.add("textbox","ChatInput", p[0], p[1], p[2], p[3], p[4], p[5], ROOM_IMAGE_BTN_PATH );
	roomContainer.getTextBox("ChatInput").setFontColor(1.0f,1.0f,1.0f,0.8f);
	roomContainer.getTextBox("ChatInput").setFontSize(10);
	roomContainer.getTextBox("ChatInput").setFontPosition(540, 720);
	roomContainer.getTextBox("ChatInput").addListener(this);

	CTextBox& chat = roomContainer.getTextBox("ChatInput");
	CUIManager::getInstance().setActiveTextbox(&chat);

	// ���� ǥ�� �׸�
	p = CHAR_INFO_SHOW_BOY_POINTS;
	roomContainer.add( "imagebox", "CharInfoShowBoy", p[0], p[1], p[2], p[3], p[4], p[5], ROOM_IMAGE_BTN_PATH );
	roomContainer.getImageBox( "CharInfoShowBoy" ).setVisible( false );

	p = CHAR_INFO_SHOW_GIRL_POINTS;
	roomContainer.add( "imagebox", "CharInfoShowGirl", p[0], p[1], p[2], p[3], p[4], p[5], ROOM_IMAGE_BTN_PATH );
	roomContainer.getImageBox( "CharInfoShowGirl" ).setVisible( false );

	p = CHAR_INFO_SHOW_GIANT_POINTS;
	roomContainer.add( "imagebox", "CharInfoShowGiant", p[0], p[1], p[2], p[3], p[4], p[5], ROOM_IMAGE_BTN_PATH );
	roomContainer.getImageBox( "CharInfoShowGiant" ).setVisible( false );


	// �� ���� ǥ��
	p = ROOM_MY_FLAG_POINTS;
	roomContainer.add( "imagebox", "SlotFlag", p[0], p[1], p[2], p[3], p[4], p[5], ROOM_IMAGE_BTN_PATH );

	// ���° ĳ���͸� �����ߴ��� �����ִ� imagebox, ��ö������ �̹��� ������ ��ǥ����
	static int SELECT_FLAG_POINT[] = { 579, 59, 20, 15, 938, 855 };
	p = SELECT_FLAG_POINT;
	roomContainer.add( "imagebox", "SelectFlag", p[0], p[1], p[2], p[3], p[4], p[5], ROOM_IMAGE_BTN_PATH );
	roomContainer.getImageBox( "SelectFlag" ).setVisible( false );

	// ready�ߴ��� ǥ��
	p = READY_SLOT_POINTS_1;
	roomContainer.add( "imagebox", "SlotReady1", p[0], p[1], p[2], p[3], p[4], p[5], ROOM_IMAGE_BTN_PATH );
	roomContainer.getImageBox( "SlotReady1" ).setVisible( false );

	p = READY_SLOT_POINTS_2;
	roomContainer.add( "imagebox", "SlotReady2", p[0], p[1], p[2], p[3], p[4], p[5], ROOM_IMAGE_BTN_PATH );
	roomContainer.getImageBox( "SlotReady2" ).setVisible( false );

	p = READY_SLOT_POINTS_3;
	roomContainer.add( "imagebox", "SlotReady3", p[0], p[1], p[2], p[3], p[4], p[5], ROOM_IMAGE_BTN_PATH );
	roomContainer.getImageBox( "SlotReady3" ).setVisible( false );

	p = READY_SLOT_POINTS_4;
	roomContainer.add( "imagebox", "SlotReady4", p[0], p[1], p[2], p[3], p[4], p[5], ROOM_IMAGE_BTN_PATH );
	roomContainer.getImageBox( "SlotReady4" ).setVisible( false );



	// ���� ������ �˾� ������ �����̳�
	manager.makeContainer("mainDisconnected", 257, 304, 510, 160, 0, 480, "image/lError.bmp");
	CUIContainer& mainDisconnected = manager["mainDisconnected"];

	// ���� ������ Ȯ�� ��ư
	mainDisconnected.add("button", "disconnectedAcceptButton", 476, 423, 72, 42, 0, 1024-42, "image/lError.bmp");
	mainDisconnected.getButton("disconnectedAcceptButton").setImageFlag(REV_NORMAL|REV_ROLLOVER);
	mainDisconnected["disconnectedAcceptButton"].addListener(this);

	mainDisconnected.setEnable(FALSE);



	manager.getUIDraw(0)->setFileName(ROOM_IMAGE_BACK_PATH);
	manager.getUIDraw(1)->setFileName(ROOM_IMAGE_BTN_PATH);
	manager.getUIDraw(2)->setFileName("image/lError.bmp");

	CDrawManager::getInstance()->insertObject(DRAW_OBJECT_INTERFACE, (IDrawObject*)manager.getUIDraw(0));
	CDrawManager::getInstance()->insertObject(DRAW_OBJECT_INTERFACE, (IDrawObject*)manager.getUIDraw(1));
	CDrawManager::getInstance()->insertObject(DRAW_OBJECT_INTERFACE, (IDrawObject*)manager.getUIDraw(2));

	// ���̵� ��¿�
	const int X = 900;
	const int Y = 98;
	int printIdPos[MAX_ROOM_USER][2] = { {X, Y }, {X, Y + 139 }, {X, Y + 139 + 135}, {X, Y + 139 + 135 + 134} };
	for( int i=0 ; i<MAX_ROOM_USER ; i++ )
	{
		m_printID[i] = new CPrintObject;
		m_printID[i]->setSize(15);
		m_printID[i]->setColor(0.9,0.9,0.9,1.0);
		m_printID[i]->setPosition( printIdPos[i][0], printIdPos[i][1] );

		CDrawManager::getInstance()->insertObject( DRAW_OBJECT_INTERFACE, m_printID[i] );
	}
	//

	// ���� ��¿�
	m_printRoomName = new CPrintObject;
	m_printRoomName->setSize(13);
	m_printRoomName->setColor( 0.0f ,0.0f ,0.0f ,1.0f);
	m_printRoomName->setPosition( 270, 57 );

	CDrawManager::getInstance()->insertObject( DRAW_OBJECT_INTERFACE, m_printRoomName );
	//

}

void	
CRoomState::processNetwork()
{
	if( !m_pMyInfo )
		return;

	// ��� �������� ���������� Ŀ�ؼ� ����
	CMessageManager::getInstance()->cleanup();

	//	���μ����� �� �������̼� �ٽ� �� (REQ_ROOM_INFORMATION : id(userid), �� ��ȣ  )
	Packet packet( REQ_ROOM_INFORMATION );
	packet << m_pMyInfo->id << m_nRoomNumber;
	CMessageManager::getInstance()->sendMessageToMainServer( packet );
}