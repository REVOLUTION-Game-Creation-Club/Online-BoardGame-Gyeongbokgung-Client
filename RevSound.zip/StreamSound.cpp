#include "stdafx.h"
#include "StreamSound.h"


namespace rev
{

CStreamSound::CStreamSound( TCHAR* _szFileName ) 
: CSound( _szFileName )
{

}

CStreamSound::~CStreamSound()
{
	destroy();
}

bool	
CStreamSound::initialize()
{
	CSound::initialize();

	m_pSoundFile	= NULL;	
	m_bLoop			= false;		
	m_dwBytesPlayed	= 0;
	m_dwDataPos		= 0;	
	m_dwLastReadPos	= 0;

	return true;
}

bool	
CStreamSound::destroy()
{
	if( m_pSoundFile )
	{
		delete m_pSoundFile;
		m_pSoundFile	= NULL;
	}

	CSound::destroy();

	return true;
}

void	
CStreamSound::load( CSoundFileLoader* pSoundFileLoader )
{
	if( !pSoundFileLoader )
		return;

	m_pSoundFile = pSoundFileLoader;
}


bool	
CStreamSound::play( bool _bLoop )
{
	m_bLoop	= _bLoop;

	CSound::load( m_pSoundFile );
	createSoundBuffer( m_waveFormat.nAvgBytesPerSec );

	m_lpSoundBuffer->Play( 0, 0, DSBPLAY_LOOPING );

	return true;
}

bool	
CStreamSound::update()
{
	if( !m_lpSoundBuffer || !m_pSoundFile )
		return true;

	DWORD dwReadPos;
	DWORD dwWritePos;

	HRESULT hr;

	hr = m_lpSoundBuffer->GetCurrentPosition( &dwReadPos, &dwWritePos );

	if( dwReadPos > m_dwLastReadPos )
		m_dwBytesPlayed += dwReadPos - m_dwLastReadPos;
	else
		m_dwBytesPlayed += ( m_caps.dwBufferBytes - m_dwLastReadPos ) + dwReadPos;

	if( m_dwBytesPlayed >= m_pSoundFile->getSize() )
	{
		if( m_bLoop )
			m_dwBytesPlayed -= m_pSoundFile->getSize();

		return false;
	}

	// ���� ������ ũ����
	DWORD dwDataToCopy;
	if( m_dwDataPos < dwReadPos )
		dwDataToCopy = dwReadPos - m_dwDataPos;
	else
		dwDataToCopy = ( m_caps.dwBufferBytes - m_dwDataPos ) + dwReadPos;

	if( dwDataToCopy > ( m_caps.dwBufferBytes / 2 ) )
		dwDataToCopy = m_caps.dwBufferBytes / 2;

	void*	ptr1;
	DWORD	dwBytes1;
	void*	ptr2;
	DWORD	dwBytes2;

	hr = m_lpSoundBuffer->Lock( m_dwDataPos, dwDataToCopy, &ptr1, &dwBytes1, &ptr2, &dwBytes2, 0 );
	if( FAILED( hr ) )
	{
		debugDXError( hr );
		return true;
	}

	// ���� ���̺� ������ �������̶��
	if( m_pSoundFile->isEof() )
	{
		memset( ptr1, getSilenceData(), dwBytes1 );
		if( ptr2 )
			memset( ptr2, getSilenceData(), dwBytes2 );

		m_dwDataPos += dwBytes1 + dwBytes2;
	}
	else
	{
		DWORD	dwBytesRead = 0;
		if( !m_pSoundFile->read( (BYTE*)ptr1, dwBytes1, &dwBytesRead ) )
		{
			debug( "sound file read failed\n" );
			return true;
		}

		m_dwDataPos += dwBytesRead;

		if( ptr2 && ( dwBytes1 == dwBytesRead ) )
		{
			if( !m_pSoundFile->read( (BYTE*)ptr2, dwBytes2, &dwBytesRead ) )
			{
				debug( "sound file read failed\n" );
				return  true;
			}

			m_dwDataPos += dwBytesRead;
		}
	}

	hr = m_lpSoundBuffer->Unlock( ptr1, dwBytes1, ptr2, dwBytes2 );
	if( FAILED( hr ) )
	{
		if( hr == DSERR_INVALIDCALL )
			return  true;
		debugDXError( hr );
		return  true;
	}

	// ��Ʈ���� �ݺ��ϰ� ������ ������ ���������� �缳��
	if( m_bLoop && m_pSoundFile->isEof() )
		m_pSoundFile->reset();

	m_dwDataPos %= m_caps.dwBufferBytes;

	m_dwLastReadPos = dwReadPos;

	return  true;
}


}