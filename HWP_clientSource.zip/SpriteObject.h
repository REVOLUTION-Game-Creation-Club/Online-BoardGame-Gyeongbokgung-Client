#ifndef	__SpriteObject_h_
#define __SpriteObject_h_
#include "DrawObject.h"

class CSpriteObject: public CDrawObject
{
protected:
	int					m_spriteType;
	int					m_spriteNo;

public:
						CSpriteObject();
						CSpriteObject(int _x, int _y, int _w, int _h, string _fileName);
	virtual				~CSpriteObject();
public:

	void				setSpriteType(int _type);
	int					getSpriteType();
	void				setSpriteNo(int _no);
	int					getSpriteNo();
};

#endif