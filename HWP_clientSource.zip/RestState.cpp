#include "stdafx.h"
#include "RestState.h"
#include "Map.h"
#include "MessageManager.h"
#include "UserManager.h"
#include "GameManager.h"
#include "PlayState.h"

CRestState::CRestState(CCharacter* _character)
{
	this->m_character	= _character;
	m_count				= 0;
}

CRestState::~CRestState()
{
}

void CRestState::stateStart()
{
}

void CRestState::stateEnd()
{
}

void CRestState::draw(DWORD _timeDelta)
{
	UNREFERENCED_PARAMETER(_timeDelta);
	CPlayState* playState = (CPlayState*)CGameManager::getInstance()->getState(GAME_STATE_PLAY);

	if(m_count == 0)
	{
		m_count++;
	}
	// �ִϸ��̼� ��
	else if(m_count < SPRITE_NUM_DELAY*SPRITE_NUM_REST )
		m_count++;
	else 
	{
		m_count = 0;
		// ���� �ִϸ��̼� �Ŀ� TURN_OUT �޼����� ������.
		if(m_character->isTurnOutFlag() == true)
		{
			//if(CUserManager::getInstance()->getMyUser()->isMajor())
			{
				Packet packet(REQ_TURN_OUT);
				packet << CUserManager::getInstance()->getMyUserId();
				CMessageManager::getInstance()->sendMessageToClientServer(packet);
			}
			m_character->setTurnOutFlag(false);
		}
	}

	drawRestCharacter();
	m_character->drawOption();
}

void CRestState::drawRestCharacter()
{
	CPlayState* playState = (CPlayState*)CGameManager::getInstance()->getState(GAME_STATE_PLAY);

	m_character->setSpriteType(SPRITE_TYPE_REST);

	POINT position;
	position.x = m_character->getCenterPoint().x - 75 - playState->getMap()->getScreenPoint().x;
	position.y = m_character->getCenterPoint().y - 125 - playState->getMap()->getScreenPoint().y;
	m_character->setPosition(position);

	m_character->setSpriteNo(m_count/SPRITE_NUM_DELAY%SPRITE_NUM_REST);
	m_character->BitBlt();
}