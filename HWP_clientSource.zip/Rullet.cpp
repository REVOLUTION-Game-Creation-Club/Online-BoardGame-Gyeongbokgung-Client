#include "stdafx.h"
#include "Rullet.h"
#include "DrawManager.h"
#include "MessageManager.h"
#include "UserManager.h"
#include <stdio.h>

CRullet::CRullet(int _x,int _y) : CSpriteObject(_x, _y, 238, 238,"image/rullet.bmp")
{
	m_selectedNumber	= -1;
	m_computeNumber		= 0;
	m_timeStart			= false;
	m_rulletStart		= false;
	m_elapsedTime		= 0;
}

CRullet::~CRullet()
{
}

void CRullet::rulletStart()
{
	//{{ sound
	rev::getSoundManager()->play( "�귿���ư��� ��" );
	//}}
	m_rulletStart = true; 
}

bool CRullet::rulletStop(int _num)
{
	//{{ sound
	rev::getSoundManager()->stop( "�귿���ư��� ��" );
	//}}

	m_computeNumber = _num;
	m_rulletStart = false;

	return m_computeNumber == m_selectedNumber ? true : false;
}

void CRullet::timeStart()
{
	rev::getSoundManager()->play( "�ð�(10��)" );
	m_timeStart = true; 
}
void CRullet::timeStop()
{
	rev::getSoundManager()->stop( "�ð�(10��)" );
	m_timeStart = false; 
}


// �귿�� �ð��� 0���� �ʱ�ȭ �ϰ� 

void CRullet::timeout()
{
	CCharacter* character = CUserManager::getInstance()->getNowTurnUser()->getSelectCharacter();
	m_computeNumber = 0;
	m_timeStart = false;
	m_elapsedTime = 0;

	if(character->getCharacterState() == CHARACTER_STATE_WAIT)
	{
		character->setTurnOutFlag(true);
		character->setCharacterState(CHARACTER_STATE_REST);
	}
}

void CRullet::draw(DWORD _timeDelta)
{
	float delay[5] = { 0.6f, 0.8f, 1.0f, 1.2f, 1.4f };

	if(m_timeStart == true)
		m_elapsedTime += _timeDelta;
	else
		m_elapsedTime = 0;

	if(m_rulletStart == true)
	{
		int delay_index = m_elapsedTime/1000%5;
		m_computeNumber = (int)(m_elapsedTime*delay[delay_index])/30%6-1;
	}

	setPosition(775,522);
	setSize(238,238);
	for(int i = 0; i< 6; i++)
	{
		if( i == m_computeNumber + 1)
		{
			setSpriteType(i/4);
			setSpriteNo(i%4);
		}
	}
	BitBlt();

	for(int i = 0; i <= 10; i++)
	{
		if((int)(m_elapsedTime/1000) == i)
		{
			setPosition(872,622);
			setSize(45,45);
			setTextureRect(i*45,238*2);
			BitBlt();
		}
	}


	if(m_elapsedTime >= 10000)
	{
		timeout();
	}
}