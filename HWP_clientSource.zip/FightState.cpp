#include "stdafx.h"
#include "FightState.h"
#include "../RevSound//SoundManager.h"
#include "UserManager.h"
#include "MessageManager.h"
#include "GameManager.h"
#include "PlayState.h"
#include "DrawManager.h"

#define FIGHT_RESULT_SHOW_TIME	2000

using namespace rev;

CFightState::CFightState(CCharacter* _character)
{
	this->m_character	= _character;
	m_fightedCharacter  = NULL;
	m_count				= 0;
	m_fightResult		= false;
	m_item				= ITEM_NO;
	m_dwStartTime = 0;
}

CFightState::~CFightState()
{
}

void CFightState::stateStart()
{
}

void CFightState::stateEnd()
{

}

void CFightState::draw(DWORD _timeDelta)
{
	UNREFERENCED_PARAMETER(_timeDelta);
	if(m_fightedCharacter == NULL)
		return;

	if(m_count == 0)
	{
		getSoundManager()->play("����");

		
		m_fightResult = CUserManager::getInstance()->getFightResult(m_fightedCharacter, m_fightedCharacter1, this->m_nFightCharCount);

		CFightImage* fightImage = ((CPlayState*)CGameManager::getInstance()->getState(GAME_STATE_PLAY))->getFightImage();
		//CDrawManager::getInstance()->makeInterfaceTopLayer(fightImage->getOrder());
		fightImage->setKind(m_character->getKind(),m_fightedCharacter->getKind());
		fightImage->setWin(m_fightResult);
		fightImage->setVisible(true);
		m_count++;

		m_dwStartTime = timeGetTime();
	}
	else if(m_count < FIGHT_SPRITE_SPEED*SPRITE_NUM_FIGHT*FIGHT_DELAY)
	{
		m_count++;
	}
	else// if( m_count == 1 && ((timeGetTime() - m_dwStartTime) > FIGHT_RESULT_SHOW_TIME) )
	{
		m_count = 0;
		m_dwStartTime = 0;

		getSoundManager()->stop("����");

		CFightImage* fightImage = ((CPlayState*)CGameManager::getInstance()->getState(GAME_STATE_PLAY))->getFightImage();
		fightImage->setVisible(false);

		if(m_fightResult)
		{
			CUserManager::getInstance()->winFightUser(m_character->getUserId());
			m_fightedCharacter->goback();
			m_fightedCharacter->setItemSlot(ITEM_NO);

			if( m_nFightCharCount == 2 )
			{
				m_fightedCharacter1->goback();
				m_fightedCharacter1->setItemSlot(ITEM_NO);
			}

			m_character->getItem(m_item);

			//{{
			char buf[32];
			char* id = CUserManager::getInstance()->getUser(m_character->getUserId())->getName();
			wsprintf( buf, "%s���� �¸��ϼ̽��ϴ�.", id );
			CGameManager::getInstance()->setNoticeString( buf, 0.1f, 0.3f, 0.8f, 1.0f );
			//}}
		}
		else
		{
			CUserManager::getInstance()->winFightUser(m_fightedCharacter->getUserId());
			m_character->goback();
			m_character->setItemSlot(ITEM_NO);

			//{{
			char buf[32];
			char* id = CUserManager::getInstance()->getUser(m_fightedCharacter->getUserId())->getName();
			wsprintf( buf, "%s���� �¸��ϼ̽��ϴ�.", id );
			CGameManager::getInstance()->setNoticeString( buf, 0.1f, 0.3f, 0.8f, 1.0f );
			//}}
		}
		
		m_character->setTurnOutFlag(true);
		m_character->setCharacterState(CHARACTER_STATE_REST);
	}
	//m_count++;

	drawFightCharacter();
}

void CFightState::drawFightCharacter()
{
	m_character->setSpriteType(SPRITE_TYPE_FIGHT);
	m_character->setSize(150,150);
	CPlayState* playState = (CPlayState*)CGameManager::getInstance()->getState(GAME_STATE_PLAY);

	POINT position;
	position.x = m_character->getCenterPoint().x - 75 - playState->getMap()->getScreenPoint().x;
	position.y = m_character->getCenterPoint().y - 125 - playState->getMap()->getScreenPoint().y;
	m_character->setPosition(position);

	int num = m_count/FIGHT_SPRITE_SPEED%SPRITE_NUM_FIGHT;
	m_character->setSpriteNo(num);
	m_character->BitBlt();
}

void CFightState::setFightedCharacter(CCharacter* _fightedCharacter)
{
	m_fightedCharacter = _fightedCharacter;
}