#ifndef __CDrawManager_h__
#define __CDrawManager_h__

#include "IDrawObject.h"
#include "TextureManager.h"
#include <vector>
#include <algorithm> // for find ()

#define WINDOW_WIDTH 1024
#define	WINDOW_HEIGHT 768

using namespace std;

class CDrawObject;

enum	DRAW_OBJECT_TYPE{ DRAW_OBJECT_MAP = 0, DRAW_OBJECT_CHARACTER, DRAW_OBJECT_INTERFACE };

class CDrawManager{
private:
	HWND						m_hwnd;
	IDirect3DDevice9*			m_device;
	
	vector<IDrawObject*>		m_mapList;
	vector<IDrawObject*>		m_characterList;
	vector<IDrawObject*>		m_interfaceList;
	CDrawObject*				m_pMouse;
	CDrawObject*				m_pCastle;

	bool						m_stateFlag;
	static	CDrawManager*		selfInstance;
								CDrawManager();
	virtual						~CDrawManager();

private:
	bool						InitD3D( HINSTANCE hInstance, int width, int height, bool windowed, D3DDEVTYPE deviceType, 
										IDirect3DDevice9** device);
	bool						draw(DWORD _timeDelta);
public:
	static CDrawManager*		getInstance();
	void						release();

	bool						createD3DWindow(HINSTANCE _hInstance);
	void						initialize();

	void						setHWnd(HWND _hwnd){m_hwnd = _hwnd;}
	HWND						getHWnd(){return m_hwnd;}

	void						setDevice(IDirect3DDevice9* _device){m_device = _device;}
	IDirect3DDevice9*			getDevice(){return m_device;}

	void						setStateFlag(bool _stateFlag){m_stateFlag = _stateFlag;}
	bool						getStateFlag(){return m_stateFlag;}

	bool						display(DWORD _timeDelta);

	int							insertObject(DRAW_OBJECT_TYPE _type, IDrawObject* _obj);
	void						eraseObject(DRAW_OBJECT_TYPE _type, int _where);
	void						eraseList();

	//IDrawObject*				operator[] (int _where);

	void						makeCharacterTopLayer(int _where);
	void						makeInterfaceTopLayer(int _where);

	//{{
	void	createMouse();
	void	setMousePoint( int x, int y );

	void	createCastle();
	void	releaseCastle();
	//}}
};

#endif