#include "stdafx.h"
#include "Packet.h"

Packet::Packet()
	: dataField( 0 ), readPosition( 0 ), writePosition( 0 ), receivedSize( 0 )
{
	clear();
}

Packet::Packet( unsigned short idValue )
	: dataField( 0 ), readPosition( 0 ), writePosition( 0 ), receivedSize( 0 )
{
	clear();
	id( idValue );
}

//#pragma warning (disable:4311)
Packet::Packet( const Packet& source )
	: dataField( 0 ), readPosition( 0 ), writePosition( 0 ),
	 receivedSize( 0 )
{
	clear();

	::CopyMemory( packetBuffer, source.packetBuffer, PACKETBUFFERSIZE );

	receivedSize = source.receivedSize;


	DWORD_PTR offset;

	offset = ( DWORD_PTR )source.readPosition - ( DWORD_PTR )source.dataField;
	readPosition += offset;

	offset = ( DWORD_PTR )source.writePosition - ( DWORD_PTR )source.dataField;
	writePosition += offset;
}
//#pragma warning (default:4311)

Packet::~Packet()
{
}

bool Packet::isValidHeader()
{
	return ( getPacketSize() >= PACKETHEADERSIZE );
}

bool Packet::isValidPacket()
{
	if( isValidHeader() == false )
		return false;

	return ( getPacketSize() <= receivedSize );
}

void Packet::clear()
{
	::ZeroMemory( packetBuffer, PACKETBUFFERSIZE );

	packetHeader.dataSize	= ( unsigned short* )packetBuffer + 0;					//  packetSize size = 2
	packetHeader.protocolID = ( unsigned short* )( ( char* )packetBuffer + 2 );		//  protocolID size	= 2

	dataField      = &packetBuffer[4];
	readPosition   = writePosition = dataField;
	endOfDataField = &dataField[PACKETBUFFERSIZE - 1];

	id( 0 );

	receivedSize = 0;

	//{{ bakky
	::ZeroMemory( logBuffer, LOGBUFFERSIZE );
	writedLogSize = 0;
	//}}
}

Packet& Packet::id( unsigned short ID )
{
	*packetHeader.protocolID = ID;

	return *this;	
}

unsigned short Packet::id()
{
	return *packetHeader.protocolID;
}

unsigned short Packet::getDataFieldSize()
{
	return *packetHeader.dataSize;
}

void Packet::copyToBuffer( char* buff, int size )
{
	clear();
	::CopyMemory( packetBuffer, buff, size );
	receivedSize += size;
}

void Packet::readData( void* buffer, int size )
{
	if( readPosition + size > dataField + getDataFieldSize() || readPosition + size > endOfDataField )
		return;

	::CopyMemory( buffer, readPosition, size );
	readPosition += size;
}

void Packet::writeData( void* buffer, int size )
{
	if( writePosition + size > endOfDataField )
		return;

	::CopyMemory( writePosition, buffer, size );
	writePosition += size;
	receivedSize += size;

	*packetHeader.dataSize += size;
}


////////////////////////////////////////////////////////////////////////////
//  Operators

Packet& Packet::operator = ( Packet& packet )
{
	::CopyMemory( dataField, packet.dataField, packet.getDataFieldSize() );

	*packetHeader.protocolID = packet.id();
	*packetHeader.dataSize   = packet.getDataFieldSize();

	return *this;
}

Packet& Packet::operator << ( float arg )
{
	writeData( &arg, sizeof(float));

	//{{ bakky
	int size = wsprintf( logBuffer + writedLogSize, "%f ", arg );
	writedLogSize += size;
	//}}

	return *this;
}

Packet& Packet::operator >> ( float& arg )
{
	readData( &arg, sizeof(float));

	//{{ bakky
	int size = wsprintf( logBuffer + writedLogSize, "%f ", arg );
	writedLogSize += size;
	//}}

	return *this;
}

Packet& Packet::operator << ( LPSTR arg )
{
	writeData( arg, (int)strlen( arg ) * sizeof( CHAR ) + sizeof( CHAR ) );

	//{{ bakky
	int size;
	int len = strlen( arg );
	if( len == 0 )
		size = wsprintf( logBuffer + writedLogSize, "NULL " );
	else
		size = wsprintf( logBuffer + writedLogSize, "%s ", arg );
	writedLogSize += size;
	//}}

	return *this;
}

Packet& Packet::operator >> ( LPSTR arg )
{
	readData( arg, (int)strlen( ( LPSTR )readPosition ) * sizeof( CHAR ) + sizeof( CHAR ) );

	//{{ bakky
	int size;
	int len = strlen( arg );
	if( len == 0 )
		size = wsprintf( logBuffer + writedLogSize, "NULL " );
	else
		size = wsprintf( logBuffer + writedLogSize, "%s ", arg );
	writedLogSize += size;
	//}}
	
	return *this;
}

Packet& Packet::operator << ( Packet& arg )
{
	unsigned int idValue = arg.id();
	unsigned int size = arg.getDataFieldSize();

	writeData( &idValue, sizeof( unsigned int ) );
	writeData( &size, sizeof( unsigned int ) );
	writeData( arg.dataField, size );

	return *this;
}

Packet& Packet::operator >> ( Packet& arg )
{
	int idValue, size;
	char buffer[PACKETBUFFERSIZE];

	readData( &idValue, sizeof( int ) );
	readData( &size, sizeof( int ) );

	readData( buffer, size );

	arg.id( idValue );
	arg.writeData( buffer, size );

	return *this;
}

Packet& Packet::operator << ( bool arg )
{
	writeData( &arg, sizeof( bool ) );

	//{{ bakky
	int size = wsprintf( logBuffer + writedLogSize, "%d ", arg );
	writedLogSize += size;
	//}}

	return *this;
}

Packet& Packet::operator >> ( bool& arg )
{
	readData( &arg, sizeof( bool ) );

	//{{ bakky
	int size = wsprintf( logBuffer + writedLogSize, "%d ", arg );
	writedLogSize += size;
	//}}

	return *this;
}


Packet& Packet::operator << ( int arg )
{
	writeData( &arg, sizeof( int ) );

	//{{ bakky
	int size = wsprintf( logBuffer + writedLogSize, "%d ", arg );
	writedLogSize += size;
	//}}

	return *this;
}

Packet& Packet::operator >> ( int& arg )
{
	readData( &arg, sizeof( int ) );

	//{{ bakky
	int size = wsprintf( logBuffer + writedLogSize, "%d ", arg );
	writedLogSize += size;
	//}}

	return *this;
}

Packet& Packet::operator << ( long arg )
{
	writeData( &arg, sizeof( long ) );

	//{{ bakky
	int size = wsprintf( logBuffer + writedLogSize, "%d ", arg );
	writedLogSize += size;
	//}}

	return *this;
}

Packet& Packet::operator >> ( long& arg )
{
	readData( &arg, sizeof( long ) );

	//{{ bakky
	int size = wsprintf( logBuffer + writedLogSize, "%d ", arg );
	writedLogSize += size;
	//}}

	return *this;
}

Packet& Packet::operator << ( DWORD arg )
{
	writeData( &arg, sizeof( DWORD ) );

	//{{ bakky
	int size = wsprintf( logBuffer + writedLogSize, "%d ", arg );
	writedLogSize += size;
	//}}

	return *this;
}

Packet& Packet::operator >> ( DWORD& arg )
{
	readData( &arg, sizeof( DWORD ) );

	//{{ bakky
	int size = wsprintf( logBuffer + writedLogSize, "%d ", arg );
	writedLogSize += size;
	//}}

	return *this;
}

Packet& Packet::operator << ( __int64 arg )
{
	writeData( &arg, sizeof( __int64 ) );

	//{{ bakky
	int size = wsprintf( logBuffer + writedLogSize, "%d ", arg );
	writedLogSize += size;
	//}}

	return *this;
}

Packet& Packet::operator >> ( __int64& arg )
{
	readData( &arg, sizeof( __int64 ) );

	//{{ bakky
	int size = wsprintf( logBuffer + writedLogSize, "%d ", arg );
	writedLogSize += size;
	//}}

	return* this;
}
