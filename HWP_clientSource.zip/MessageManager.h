#ifndef __MessageManager_h__
#define __MessageManager_h__

#include "ClientSocket.h"
#include "GameProtocol.h"
#include "IMessageState.h"

enum MESSAGE_STATE{MESSAGE_STATE_NOW = 0, MESSAGE_STATE_NETWORK, MESSAGE_STATE_LOCAL };

class CMessageManager
{
	IMessageState*					m_networkState;
	IMessageState*					m_localState;
	IMessageState*					m_nowState;

	static	CMessageManager*		selfInstance;
	CMessageManager();
	virtual ~CMessageManager();
public:

	static CMessageManager*			getInstance();
	void 							release();

	bool 							initialize();
	void 							cleanup();
	
	bool							connectServer(char* _addr);
	void							connectToUserServer();
	void 							broadcast(Packet& _packet);
	void 							sendMessageToClientServer(Packet& _packet);
	void							sendMessageToMainServer(Packet& _packet);

	void							processPacket();

	IMessageState*					getState(MESSAGE_STATE _messageState);
	void							setState(MESSAGE_STATE _messageState);
};

#endif
