#include "stdafx.h"
#include "FrogState.h"
#include "MessageManager.h"
#include "UserManager.h"
#include "Map.h"
#include "GameManager.h"
#include "PlayState.h"

CFrogState::CFrogState(CCharacter* _character)
{
	this->m_character	= _character;
	m_count				= 0;
}

CFrogState::~CFrogState()
{
}

void CFrogState::stateStart()
{
}

void CFrogState::stateEnd()
{
}

void CFrogState::draw(DWORD _timeDelta)
{
	UNREFERENCED_PARAMETER(_timeDelta);

	if(m_count < SPRITE_NUM_DELAY*SPRITE_NUM_FROG )
		m_count++;
	else
	{
		if( m_character->isTurnOutFlag() )
		{
			m_character->setTurnOutFlag( false );
			Packet packet( REQ_TURN_OUT );
			packet << CUserManager::getInstance()->getMyUserId();
			CMessageManager::getInstance()->sendMessageToClientServer( packet );
		}
		m_count = 0;
	}

	drawFrogCharacter();
	m_character->drawOption();
}

void CFrogState::drawFrogCharacter()
{
	CPlayState* playState = (CPlayState*)CGameManager::getInstance()->getState(GAME_STATE_PLAY);
	m_character->setSize(150,150);
	POINT position;
	position.x = m_character->getCenterPoint().x - 75 - playState->getMap()->getScreenPoint().x;
	position.y = m_character->getCenterPoint().y - 125 - playState->getMap()->getScreenPoint().y;
	m_character->setPosition(position);
	m_character->setSpriteType(SPRITE_TYPE_FROG);
	m_character->setSpriteNo(m_count/SPRITE_NUM_DELAY%SPRITE_NUM_FROG);
	m_character->BitBlt();
}