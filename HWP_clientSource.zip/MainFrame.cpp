#include "stdafx.h"
#include "MainFrame.h"
#include "MessageManager.h"
#include "UI/CUIManager.h"
#include "UserManager.h"
#include "GameManager.h"
#include "DrawManager.h"
#include "PlayState.h"
#include <WindowsX.h>
#include "../RevIMEKorean/RevIMEKorean.h"
#include "../RevSound/SoundManager.h"
#include "TextureManager.h"
#include "Mmsystem.h"
#define _CRTDBG_MAP_ALLOC 
#include <stdlib.h> 
#include <crtdbg.h> 

//{{ ����
#include "MiniDump/MiniDump.h"
#pragma comment(lib, "dbghelp")
//}

#include "OpenningState.h"

// ime���� ó�������� �ִ� ����
const int MAX_IME_LEN	= 1024;
const TCHAR*	FONT_FILE_NAME	= TEXT("Font\\typoenter.net_����+��å10_beta1.0_20060115.ttf");

using namespace rev;
using namespace MainFrame;

LRESULT CALLBACK MainFrame::WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	int x = 0, y = 0;

	switch( msg )
	{
	case WM_CREATE :
		{
			//{{ bakky ���콺 Ŀ�� �Ⱥ��̰�..
			ShowCursor( FALSE );
			AddFontResource( FONT_FILE_NAME );
/*
			HDC hDC = GetDC( hwnd );
			int nLogPixelsY = GetDeviceCaps(hDC, LOGPIXELSY);
			ReleaseDC( hwnd, hDC );

			int nHeight = -13 * nLogPixelsY / 72;	


			HFONT hFont = 
			CreateFont( 0, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET, 
					OUT_DEFAULT_PRECIS, 2, DEFAULT_QUALITY, DEFAULT_PITCH|FF_DONTCARE, "����+��å10" );

			HFONT hOldFont = (HFONT)SelectObject( hDC, hFont );*/

			getIME()->Init( hwnd, 0, 0, TRUE, MAX_IME_LEN );
			getIME()->ShowCaret( FALSE );
			//}}
		}
		break;

	case WM_CHAR :
		HANDLE_WM_CHAR( hwnd, wParam, lParam, getIME()->OnChar );
		CUIManager::getInstance().onKeyDown();
		break;

	case WM_SETFOCUS :
		HANDLE_WM_SETFOCUS( hwnd, wParam, lParam, getIME()->OnSetFocus );
		break;

	case WM_KILLFOCUS :
		HANDLE_WM_KILLFOCUS( hwnd, wParam, lParam, getIME()->OnKillFocus );
		break;

	case WM_IME_STARTCOMPOSITION :
		HANDLE_WM_IME_STARTCOMPOSITION( hwnd, wParam, lParam, getIME()->OnImeStartComposition );
		break;

	case WM_IME_COMPOSITION :
		HANDLE_WM_IME_COMPOSITION( hwnd, wParam, lParam, getIME()->OnImeComposition );
		CUIManager::getInstance().onKeyDown();
		break;

	case WM_TIMER :
		break;

	case WM_ACTIVATEAPP :
		break;

	case WM_DESTROY:
		getIME()->ReleasedIME();
		::PostQuitMessage(0);
		break;
	case WM_MOUSEMOVE:
		{
			x = (int)(short)LOWORD(lParam);
			y = (int)(short)HIWORD(lParam);

			CDrawManager::getInstance()->setMousePoint( x, y );
			CGameManager::getInstance()->setMousePoint(x, y);
			CUIManager::getInstance().onMouseMove(x, y);
		}
		break;
	case WM_LBUTTONDOWN:
		x = (int)(short)LOWORD(lParam);
		y = (int)(short)HIWORD(lParam);
		if( CGameManager::getInstance()->getGameState() == GAME_STATE_PLAY )
			((CPlayState*)CGameManager::getInstance()->getState(GAME_STATE_PLAY))->onMouseLClick();
		CUIManager::getInstance().onMousePress(x, y);
		break;
	case WM_LBUTTONUP:
		x = (int)(short)LOWORD(lParam);
		y = (int)(short)HIWORD(lParam);
		CUIManager::getInstance().onMouseRelese(x, y);
		break;
	case MCIWNDM_NOTIFYMODE: 
		if (lParam == MCI_MODE_STOP)  // device stopped
		{ 
			//MessageBox(hWnd,"������ ��� ����...","Closing Device",MB_OK); 
			//MCIWndClose(g_hwndMCIWnd);
			((COpenningState*)CGameManager::getInstance()->getState(GAME_STATE_OPENNING))->onStop();
		} 
		break; 

	case WM_KEYDOWN:

		if( wParam == VK_ESCAPE )
			::DestroyWindow(hwnd);

		CGameManager::getInstance()->onKeyboard(wParam);

		break;

	default:
		return DefWindowProc(hwnd, msg, wParam, lParam);
	}

	return 0;
}

int MainFrame::MessageLoop()
{
	MSG msg;
	::ZeroMemory(&msg, sizeof(MSG));

	static long lastTime = timeGetTime();

	CGameManager* pGameManager = CGameManager::getInstance();

	while( pGameManager->getGameState() == GAME_STATE_OPENNING && GetMessage(&msg, NULL, 0, 0) )
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}


	//DWORD				m_frameCount = 0;
	//float				m_timeElapsed= 0.0f;
	//float				m_FPS = 0.0f;

	while(msg.message != WM_QUIT)
	{
		if(::PeekMessage(&msg, 0, 0, 0, PM_REMOVE))
		{
			::TranslateMessage(&msg);
			::DispatchMessage(&msg);
		}
		else
		{
			long currTime  = timeGetTime();
			long timeDelta = currTime - lastTime;

			CMessageManager::getInstance()->processPacket();

			if(timeDelta >= 15)
			{

				//m_frameCount++;
				//m_timeElapsed += (float)(timeDelta/1000.0f);
				//if(m_timeElapsed >= 0.5f)
				//{
				//	char str[128];

				//	m_FPS = (float)m_frameCount / m_timeElapsed;

				//	sprintf_s(str, "%f", m_FPS);
				//	str[8] = '\0'; // mark end of string

				//	//setString(str);
				//	OutputDebugString( str );
				//	OutputDebugString( "\n" );

				//	m_timeElapsed = 0.0f;
				//	m_frameCount    = 0;
				//}

				CGameManager::getInstance()->processMouseMove();
				CDrawManager::getInstance()->display(timeDelta);
				lastTime = currTime;
			}
		}
	}
	return msg.wParam;
}


int WINAPI WinMain(HINSTANCE hinstance, HINSTANCE prevInstance, PSTR cmdLine, int showCmd)
{
	UNREFERENCED_PARAMETER(prevInstance);
	UNREFERENCED_PARAMETER(cmdLine);
	UNREFERENCED_PARAMETER(showCmd);


//{{ ����
//	cMiniDump::Install(cMiniDump::DUMP_LEVEL_LIGHT);
//}}

	/* �ڱ� ���� �����ϴ� �κ� */
	char* strID;
	strID = strtok(cmdLine, " ");
	CUserManager::getInstance()->setMyUserName(strID);

	CDrawManager::getInstance()->createD3DWindow(hinstance);
	CDrawManager::getInstance()->createMouse();

	//{{ sound
	getSoundManager()->initialize( CDrawManager::getInstance()->getHWnd() );
	getSoundManager()->load( "sound\\soundlist.txt" );
	//// test
	//getSoundManager()->setVolumeBackgroundMusic( 0.0f );
	//getSoundManager()->setVolumeEffectSound( 0.0f );
	//////}}

	CMessageManager::getInstance()->initialize();
	CUIManager::getInstance().initialize();
	CUserManager::getInstance()->initialize();
	CGameManager::getInstance()->initialize();

	MainFrame::MessageLoop();

	CGameManager::getInstance()->release();
	CDrawManager::getInstance()->release();
	CUserManager::getInstance()->release();
	CUIManager::getInstance().release();
	CMessageManager::getInstance()->release();
	CTextureManager::getInstance()->release();
	getIME()->release();
	getSoundManager()->release();

	_CrtDumpMemoryLeaks();

	return 0;
}
