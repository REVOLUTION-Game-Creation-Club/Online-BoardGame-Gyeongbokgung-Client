#pragma once
#include <vector>
#include "CUIControl.h"
#include "UIContainer.h"

using namespace std;


class CDrawControl
{
protected:
	CDrawControl(void);

	vector<CUIContainer*> drawContainerList;
public:		
	virtual ~CDrawControl(void);

	void insertList(CUIControl& _control);	

	virtual void setValues(int _x, int _y, int _height, int _width, int _texX, int _texY, string fileName) = 0;
	virtual void setValues( int _texX, int _texY ) = 0;
};
