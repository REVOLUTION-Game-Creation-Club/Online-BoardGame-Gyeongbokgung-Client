#ifndef __EndState_h__
#define __EndState_h__
#include "IGameState.h"
#include "GameManager.h"

class CEndState : public IGameState
{
private:
	CGameManager*				m_gameManager;
public:
	CEndState(CGameManager* _gameManager);
	virtual						~CEndState();

	bool						initialize();
	void						release();

	void						onUpdate();
	void						onKeyboard(WPARAM _wParam);
	void						processMouseMove();
};

#endif