#include "stdafx.h"
#include "ClientSocket.h"
#include "LobbyState.h"


CClientSocket::CClientSocket(CallbackRoutine callback) : m_nWritePosToBuffer(0)
{
	callbackFunc = callback;

	m_threadRun = true;

	WSADATA wsaData;
	DWORD dwThreadID;

	WSAStartup(MAKEWORD(2,2), &wsaData);

	m_socket = socket(PF_INET, SOCK_STREAM, 0);

	memset(&m_addr, 0, sizeof(m_addr));
	m_addr.sin_family= AF_INET;
	m_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	m_addr.sin_port = htons(atoi("9190"));

	bind(m_socket, (SOCKADDR*) &m_addr, sizeof(m_addr));
	listen(m_socket, MAX_ACCEPT);

	m_newSocket.socket=m_socket;
	m_newSocket.categori = USER_SERVER_ACCEPT;
	m_socketList.push_back(m_newSocket); // ���������� ���� ���� ����, list�� 0���� ��ġ

	InitializeCriticalSection(&m_criticalSection);

	//{{ bakky
	memset( m_recvBuffer, 0, MAX_BUFFER_SIZE );

	TCHAR	timeBuffer[64] = {0};
	SYSTEMTIME SystemTime;
	GetLocalTime( &SystemTime );
	GetTimeFormat( LOCALE_USER_DEFAULT, TIME_FORCE24HOURFORMAT, 
		&SystemTime, "H'-'mm'" , timeBuffer, 64 );

	char month[64];
	wsprintf( month, "%d.%d ", SystemTime.wMonth, SystemTime.wDay );
	strcat( month, timeBuffer );

	TCHAR logPath[256];
	strcpy( logPath, "Log\\" );
	strcat( logPath, month );
	strcat( logPath, ".log" );
	m_fileLog.open( logPath, ios_base::out | ios_base::trunc );

	makeProtocolMap();
	//}}

	m_hThread = (HANDLE)_beginthreadex(NULL, 0, &CClientSocket::ServerRecvThread,(void*)this, 0, (unsigned *)&dwThreadID);
}

CClientSocket::~CClientSocket(void)
{
	m_threadRun = false;
	WaitForSingleObject(m_hThread, INFINITE);

	CloseHandle( m_hThread );
	closeSocket();
	DeleteCriticalSection(&m_criticalSection);


	if( m_fileLog.is_open() )
	{
		m_fileLog.close();
	}

	m_protocolMap.clear();
		
}

bool CClientSocket::connectServer(char* _hostAddr, int target)
{
	m_socket = socket(PF_INET, SOCK_STREAM, 0);
	m_addr.sin_addr.s_addr = inet_addr(_hostAddr);

	EnterCriticalSection(&m_criticalSection);

	if(connect(m_socket, (SOCKADDR*)&m_addr, sizeof(m_addr)) == SOCKET_ERROR)
	{

		// log
		if( m_fileLog.is_open() )
		{
			// log���Ͽ� ����..����
			// 
			static char bufLog[64];
			wsprintf( bufLog, "connect is SOCKET_ERROR, code(%d)", WSAGetLastError() );
			m_fileLog.write( bufLog, strlen( bufLog ) );
			m_fileLog.write( "\r\n\r\n", strlen( "\r\n\r\n" ) );

			m_fileLog.flush();
		}
		//}}

		return FALSE;
	}

	m_newSocket.socket = m_socket;
	m_newSocket.categori = target;

	m_socketList.push_back(m_newSocket);
	LeaveCriticalSection(&m_criticalSection);
	return TRUE;
}

void CClientSocket::sendPacket(Packet& _packet, int target)
{
	EnterCriticalSection(&m_criticalSection);
	for(m_socketList_Iter=m_socketList.begin(); m_socketList_Iter != m_socketList.end(); m_socketList_Iter++)
	{
		m_newSocket = *m_socketList_Iter;
		m_socket = m_newSocket.socket;
		if(m_newSocket.categori == target)
		{
			if( send(m_socket, _packet.getPacketBuffer(), _packet.getPacketSize(), 0) 
				== SOCKET_ERROR )
			{
				int nGetLastError = WSAGetLastError();

				// log
				if( m_fileLog.is_open() )
				{
					// log���Ͽ� ����..����
					// 
					static char bufLog[64];
					wsprintf( bufLog, "send is SOCKET_ERROR, code(%d)", nGetLastError );
					m_fileLog.write( bufLog, strlen( bufLog ) );
					m_fileLog.write( "\r\n\r\n", strlen( "\r\n\r\n" ) );

					m_fileLog.flush();
				}
			}

			// log
			if( m_fileLog.is_open() )
			{
				// log���Ͽ� ����..����
				// packet id : 
				static char bufLog[64];
				wsprintf( bufLog, "send %s( packetSize : %d ) : ", m_protocolMap[_packet.id()], _packet.getPacketSize() );
				m_fileLog.write( bufLog, strlen( bufLog ) );
				//m_fileLog.write( _packet.getPacketBuffer(), _packet.getPacketSize() );
				m_fileLog.write( _packet.getLogBuffer(), _packet.getLogBufferSize() );
				m_fileLog.write( "\r\n\r\n", strlen( "\r\n\r\n" ) );

				m_fileLog.flush();
			}
			//}}
		}
	}
	LeaveCriticalSection(&m_criticalSection);
}

unsigned __stdcall CClientSocket::ServerRecvThread(void *arg)
{
	CClientSocket* _this = (CClientSocket*)arg;

	_this->recvPacket();
	return 0;
}

void CClientSocket::recvPacket()
{
	int strLen=0;

	while(true)
	{
		EnterCriticalSection(&m_criticalSection);

		if(!m_threadRun)
		{
			LeaveCriticalSection(&m_criticalSection);
			return;
		}

		FD_ZERO(&m_fdread);

		for(m_socketList_Iter=m_socketList.begin(); m_socketList_Iter != m_socketList.end(); m_socketList_Iter++)
		{
			m_newSocket = *m_socketList_Iter;
			FD_SET(m_newSocket.socket, &m_fdread);
		}

		m_timeout.tv_sec = 0;
		m_timeout.tv_usec = 1000;

		if(select(0, &m_fdread, 0,0, &m_timeout) == SOCKET_ERROR)
		{
			OutputDebugString( "select error\n" );
			LeaveCriticalSection(&m_criticalSection);
			return;
		}

		for(int arrIndex=0; arrIndex<m_fdread.fd_count; arrIndex++)
		{
			if(FD_ISSET(m_fdread.fd_array[arrIndex], &m_fdread))
			{
				m_socketList_Iter = m_socketList.begin();
				m_newSocket = *m_socketList_Iter;
				m_socket = m_newSocket.socket;

				if(m_fdread.fd_array[arrIndex] == m_socket)
				{
					SOCKADDR_IN addr;
					int addrSize = sizeof(addr);
					memset(&addr, 0, addrSize);

					m_socket = accept(m_fdread.fd_array[arrIndex], (SOCKADDR*)&addr, &addrSize);
					m_newSocket.socket = m_socket;
					m_newSocket.categori = USER_SERVER_SEND;
					m_socketList.push_back(m_newSocket); // ���ӿ�û�� ������ ����
				}
				else
				{
					//strLen=recv(m_fdread.fd_array[arrIndex], m_packet.getPacketBuffer(), PACKETSIZE, 0);
					//{{ bakky
					strLen=recv(m_fdread.fd_array[arrIndex], &m_recvBuffer[ m_nWritePosToBuffer ], PACKETSIZE, 0);
					//}}

					int nGetLastError = WSAGetLastError();

					if( strLen == -1 )
					{
						// log
						if( m_fileLog.is_open() )
						{
							// log���Ͽ� ����..����
							// 
							static char bufLog[64];
							wsprintf( bufLog, "recv is SOCKET_ERROR, code(%d)", nGetLastError );
							m_fileLog.write( bufLog, strlen( bufLog ) );
							m_fileLog.write( "\r\n\r\n", strlen( "\r\n\r\n" ) );

							m_fileLog.flush();
						}
						//}}
					}


				//	if(strLen==-1)
					if(strLen==0 || nGetLastError == WSAECONNRESET)
					{
						if ( CGameManager::getInstance()->getGameState() == GAME_STATE_LOBBY && arrIndex == 0)
						{
							CLobbyState* pLobby = (CLobbyState*)CGameManager::getInstance()->getState( GAME_STATE_LOBBY );
							pLobby->disconnected();
						}

						for(m_socketList_Iter=m_socketList.begin(); m_socketList_Iter != m_socketList.end(); m_socketList_Iter++)
						{
							if(m_socketList_Iter->socket == m_fdread.fd_array[arrIndex])
							{
								m_socketList.erase(m_socketList_Iter);
								FD_CLR(m_fdread.fd_array[arrIndex], &m_fdread);
								closesocket(m_fdread.fd_array[arrIndex]);
								LeaveCriticalSection(&m_criticalSection);
								return;
							}
						}
					}
					else
					{
						// �޼��� �ޱ� ����...
						//{{ bakky
						unsigned short packetSize	= PACKETHEADERSIZE + *( ( unsigned short* )&m_recvBuffer[ m_nWritePosToBuffer ] );//  packetSize size = 2

						if( packetSize != strLen )
						{
							::OutputDebugString( "packetSize != strLen\n" );
						}

						m_nWritePosToBuffer += strLen;
						if( m_nWritePosToBuffer >= MAX_BUFFER_SIZE )
						{
							::OutputDebugString( "���� ũ�⸦ �Ѿ��\n" );
							break;
						}
						//}}
						//m_packetQueue.push(m_packet);
					}
				}
			} // if-FD_ISSET end
		} // for end

		LeaveCriticalSection(&m_criticalSection);

	} // while end
}

bool CClientSocket::processPacket()
{
	EnterCriticalSection(&m_criticalSection);
	Packet packet;

	packet.clear();

	//{{ bakky
	unsigned short packetSize	= PACKETHEADERSIZE + *( ( unsigned short* )m_recvBuffer );					//  packetSize size = 2
	unsigned short protocolID	= *( ( unsigned short* )( m_recvBuffer + 2 ));		//  protocolID size	= 2


	// ����Ÿ �����ŭ ���۰� ���� �ʾҴ�.
	if( packetSize == 0 || packetSize > m_nWritePosToBuffer )
	{
		LeaveCriticalSection(&m_criticalSection);
		return false;		
	}

	packet.copyToBuffer( m_recvBuffer, packetSize );
	memmove( m_recvBuffer, m_recvBuffer + packetSize, m_nWritePosToBuffer - packetSize );
	m_nWritePosToBuffer -= packetSize;
	if( m_nWritePosToBuffer < 0 )
	{
		::OutputDebugString( "���ۿ��� Ÿ��Ÿ ���µ� �̻��ϴ�.����Ÿ �̻�~\n" );
		m_nWritePosToBuffer = 0;
	}

	// log
	if( m_fileLog.is_open() )
	{
		// log���Ͽ� ����..����
		// packet id : 
		static char bufLog[64];
		wsprintf( bufLog, "recv %s( packetSize : %d ) : ", m_protocolMap[protocolID], packetSize );
		m_fileLog.write( bufLog, strlen( bufLog ) );
		//m_fileLog.write( m_recvBuffer, packetSize );
		m_fileLog.write( packet.getLogBuffer(), packet.getLogBufferSize() );
		m_fileLog.write( "\r\n\r\n", strlen( "\r\n\r\n" ) );

		m_fileLog.flush();
	}

	(*callbackFunc)(packet);

	//}}
	
	//if(m_packetQueue.empty())
	//{
	//	LeaveCriticalSection(&m_criticalSection);
	//	return false;
	//}

	//packet.clear();
	//packet = m_packetQueue.front();
	//m_packetQueue.pop();

	//(*callbackFunc)(packet);

	LeaveCriticalSection(&m_criticalSection);
	return true;
}

void CClientSocket::closeSocket()
{
	EnterCriticalSection(&m_criticalSection);

	list<newSocket>::iterator temp_Iter;

	for(m_socketList_Iter=m_socketList.begin(); m_socketList_Iter != m_socketList.end();m_socketList_Iter=temp_Iter)
	{
		if(m_socketList_Iter != m_socketList.end())
		{
			temp_Iter = ++m_socketList_Iter;
			--m_socketList_Iter;
		}

		if(m_socketList_Iter->categori == USER_SERVER_SEND || m_socketList_Iter->categori == USER_CLIENT_SEND)
		{
			m_socketList.erase(m_socketList_Iter);
		}
	}

	LeaveCriticalSection(&m_criticalSection);
}

char* CClientSocket::getHostByName()
{
/*	char name[255];
	memset(name, 0, sizeof(name));

	char* strLocalIP;
	PHOSTENT hostinfo; 

	if( gethostname (name, sizeof(name)) == 0) 
		if((hostinfo = gethostbyname(name)) != NULL) 
			strLocalIP = inet_ntoa (*(struct in_addr *)*hostinfo->h_addr_list);

	return strLocalIP;
*/
/*
	char szHostname[100]; 
	HOSTENT* pHostEnt; 
	int nAdapter = 0;
	char* strLocalIP;

	gethostname( szHostname, sizeof( szHostname )); 
	pHostEnt = gethostbyname( szHostname );

	while ( pHostEnt->h_addr_list[nAdapter] ) 
	{ 
		strLocalIP = inet_ntoa(*(struct in_addr*)pHostEnt->h_addr_list[nAdapter]);
		nAdapter++;
	};

	return strLocalIP;
*/

	SOCKADDR_IN sockAddr;
	char* strLocalIP = NULL;
	memset(&sockAddr, 0, sizeof(sockAddr)); 

	int nSockAddrLen = sizeof(sockAddr);
	EnterCriticalSection(&m_criticalSection);
	m_socketList_Iter = m_socketList.begin();
	++m_socketList_Iter;
	BOOL bResult = (getsockname(m_socketList_Iter->socket,(SOCKADDR*)&sockAddr,&nSockAddrLen) == 0);
	LeaveCriticalSection(&m_criticalSection);
	if( bResult ) 
	{ 
//		socketPort = ntohs(sockAddr.sin_port); 
//		socketAddress = inet_ntoa(sockAddr.sin_addr); 
		strLocalIP = inet_ntoa(sockAddr.sin_addr);  
	}
	return strLocalIP;
}

void	CClientSocket::makeProtocolMap()
{

	m_protocolMap[9999] = "ERROR_CODE";
	m_protocolMap[20000] = "ERROR_ON_PLAY";
	m_protocolMap[20001] = "ERROR_DEFF_PW";
	m_protocolMap[20002] = "ERROR_FULL";
	m_protocolMap[20003] = "ERROR_NO_SUCH_ROOM";

	m_protocolMap[3000] = "REQ_SERVER_CONNECT";
	m_protocolMap[3001] = "ACK_SERVER_CONNECT";
	m_protocolMap[3010] = "REQ_SERVER_DISCONNECT";
	m_protocolMap[3011] = "ACK_SERVER_DISCONNECT";
	m_protocolMap[3020] = "REQ_CLIENT_CONNECT";
	m_protocolMap[3021] = "ACK_CLIENT_CONNECT";
	m_protocolMap[3030] = "REQ_CLIENT_DISCONNECT";
	m_protocolMap[3031] = "ACK_CLIENT_DISCONNECT";

	m_protocolMap[5000] = "REQ_MainServer_Connect";
	m_protocolMap[5001] = "ACK_MainServer_Connect";
	m_protocolMap[5900] = "REQ_DISCONNECT";
	m_protocolMap[5901] = "ACK_DISCONNECT";
	m_protocolMap[5010] = "REQ_UserServer_Connect";
	m_protocolMap[5011] = "ACK_UserServer_Connect";
	m_protocolMap[5120] = "REQ_NEXT_ROOMLIST";
	m_protocolMap[5121] = "ACK_NEXT_ROOMLIST";
	m_protocolMap[5020] = "PLAYER_COME_LOBBY";
	m_protocolMap[5100] = "USER_INFORMATION";
	m_protocolMap[5111] = "LOBBY_INFO_PLAYER";
	m_protocolMap[5200] = "DROP_OUT_PLAYER";
	m_protocolMap[5201] = "DROPED_OUT_PLAYER";
	m_protocolMap[5300] = "REQ_FORCE_REMOVE";
	m_protocolMap[5301] = "ACK_FORCE_REMOVE";

	m_protocolMap[6000] = "REQ_MAKE_ROOM";
	m_protocolMap[6001] = "ACK_MAKE_ROOM";
	m_protocolMap[6020] = "REQ_ENTER_ROOM";
	m_protocolMap[6021] = "ACK_ENTER_ROOM";
	m_protocolMap[6030] = "REQ_LEAVE_ROOM";
	m_protocolMap[6031] = "ACK_LEAVE_ROOM";
	m_protocolMap[6040] = "REQ_IM_READY";
	m_protocolMap[6041] = "ACK_IM_READY";
	m_protocolMap[6050] = "REQ_WAIT_PLZ";
	m_protocolMap[6051] = "ACK_WAIT_PLZ";
	m_protocolMap[6070] = "REQ_CHARACTOR_CHANGE";
	m_protocolMap[6071] = "ACK_CHARACTOR_CHANGE";
	m_protocolMap[6060] = "ROOM_ALL_READY";
	m_protocolMap[6061] = "ROOM_WAIT_MORE";
	m_protocolMap[6062] = "ROOM_ON_PLAY";
	m_protocolMap[6200] = "ROOM_INFORMATION";
	m_protocolMap[6500] = "LEAVED_USER";

	m_protocolMap[7000] = "REQ_GAME_STARTUP	R_CHANGE";
	m_protocolMap[7001] = "ACK_GAME_STARTUP	R_CHANGE";
	m_protocolMap[7000] = "REQ_GAME_RESULT";
	m_protocolMap[9000] = "REQ_CHAT";
	m_protocolMap[9001] = "ACK_CHAT";
	m_protocolMap[9002] = "REQ_ROOM_CHAT";
	m_protocolMap[9003] = "ACK_ROOM_CHAT";

	m_protocolMap[1000] = "REQ_GAME_START";
	m_protocolMap[1001] = "ACK_GAME_START";
	m_protocolMap[1010] = "REQ_GAME_END";
	m_protocolMap[1011] = "ACK_GAME_END";
	m_protocolMap[1100] = "REQ_GAME_CHAT";
	m_protocolMap[1101] = "ACK_GAME_CHAT";
	m_protocolMap[1200] = "REQ_TURN_IN";
	m_protocolMap[1201] = "ACK_TURN_IN";
	m_protocolMap[1220] = "REQ_TURN_OUT";
	m_protocolMap[1221] = "ACK_TURN_OUT";

	m_protocolMap[1310] = "REQ_RULLET_START";
	m_protocolMap[1311] = "ACK_RULLET_START";
	m_protocolMap[1320] = "REQ_RULLET_STOP";
	m_protocolMap[1321] = "ACK_RULLET_STOP";
	m_protocolMap[1430] = "REQ_CHARACTER_EXP";
	m_protocolMap[1431] = "ACK_CHARACTER_EXP";
	m_protocolMap[1440] = "REQ_CHARACTER_LEVEL";
	m_protocolMap[1441] = "ACK_CHARACTER_LEVEL";
	m_protocolMap[1450] = "REQ_CHARACTER_MOVE";		
	m_protocolMap[1451] = "ACK_CHARACTER_MOVE";	
	m_protocolMap[1490] = "REQ_CHARACTER_CHANGE";
	m_protocolMap[1491] = "ACK_CHARACTER_CHANGE";

	m_protocolMap[1510] = "REQ_ITEM_USE";
	m_protocolMap[1511] = "ACK_ITEM_USE";
	m_protocolMap[1520] = "REQ_ITEM_GET";
	m_protocolMap[1521] = "ACK_ITEM_GET";
	m_protocolMap[1530] = "REQ_ITEM_MAGNETIC";		
	m_protocolMap[1531] = "ACK_ITEM_MAGNETIC";
	m_protocolMap[1540] = "REQ_ITEM_WATERBALL";
	m_protocolMap[1541] = "ACK_ITEM_WATERBALL";
	m_protocolMap[1550] = "REQ_ITEM_THUNDER";
	m_protocolMap[1551] = "ACK_ITEM_THUNDER";
	m_protocolMap[1600] = "REQ_TILE_SELECT";
	m_protocolMap[1601] = "ACK_TILE_SELECT";
	m_protocolMap[1610] = "REQ_TILE_UNSELECT";
	m_protocolMap[1611] = "ACK_TILE_UNSELECT";	
	m_protocolMap[1620] = "REQ_TILE_WATERBALL";	
	m_protocolMap[1621] = "ACK_TILE_WATERBALL";
	m_protocolMap[1700] = "NOTIFY_LOAD_END";

	m_protocolMap[1800] = "REQ_USER_GAMEEND";
	m_protocolMap[1801] = "REQ_GAME_END";
	m_protocolMap[1802] = "ACK_GAME_END";
	m_protocolMap[1803] = "ACK_USER_GAMEEND";
	m_protocolMap[1804] = "REQ_ROOM_INFORMATION";
	m_protocolMap[1805] = "ROOM_INFORMATION";

	m_protocolMap[1900] = "REQ_CHANGE_CHARACTER";
	m_protocolMap[1901] = "ACK_CHANGE_CHARACTER";
}