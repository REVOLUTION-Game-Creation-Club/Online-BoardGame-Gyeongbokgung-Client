#include "stdafx.h"
#include "CUIButton.h"

CUIButton::CUIButton(void)
{
	m_listener = NULL;
	kind = "button";
}

CUIButton::~CUIButton(void)
{
}

CUIButton::CUIButton(string _name)
{
	kind = "button";
	name = _name;
}

CUIButton::CUIButton(string _name, int _x, int _y, int _width, int _height)
{
	kind = "button";
	name	= _name;
	x		= _x;
	y		= _y;
	width	= _width;
	height	= _height;
}

CUIButton::CUIButton(string _name, int _x, int _y, int _width, int _height, int _texX, int _texY, char* _fileName)
{
	kind = "button";
	name	= _name;
	x		= _x;
	y		= _y;
	width	= _width;
	height	= _height;
	tex_x	= _texX;
	tex_y	= _texY;
	setFileNavi(_fileName);
}


void CUIButton::addListener(Clistener* _listener)
{
	m_listener = _listener;
}

void CUIButton::activeControl(int _state)
{
	if( _state == REV_MOUSE_DOWN )
	{
		setImageState(REV_PRESSED);
		if( m_listener != NULL )
		{
			m_listener->setEvented(name);
			m_listener->action();
		}
		else
		{
			//���Ŀ� ����ó�� ����� ��ġ��!!		
		}
	}
	else if( _state == REV_MOUSE_MOVE )
	{
		setImageState(REV_ROLLOVER);
	}
}