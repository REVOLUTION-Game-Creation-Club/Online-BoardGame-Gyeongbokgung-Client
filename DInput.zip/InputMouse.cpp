#include "InputMouse.h"

namespace rev {

	CInputMouse::CInputMouse()
	{
		m_lpDI			= 0;
		m_lpDevice		= 0;
		m_pfImmediate	= 0;
		m_pfBuffered	= 0;
		m_pDeviceObjectData = NULL;

		m_hWnd		= NULL;
	}

	CInputMouse::~CInputMouse()
	{
		destroy();
	}

	bool CInputMouse::initialize( LPDIRECTINPUT _lpDI, HWND _hWnd )
	{
		m_pDeviceObjectData = NULL;
		m_lpDI = _lpDI;
		m_mousePointStyle = MOUSE_POINT_ABS;

		m_hWnd	= _hWnd;

		return true;
	}

	bool CInputMouse::create( HWND _hWnd, int _nBufferSize, DWORD _dwFlags, DWORD _dwMode )
	{
		m_nReadDataMode = _dwMode;
		m_dwBufferSize	= (DWORD)_nBufferSize;

		m_pDeviceObjectData = new DIDEVICEOBJECTDATA[_nBufferSize];

		if( !createDirectInputDevice() )
			return false;

		if( !setDataFormat() )
			return false;

		if( !setBehavior( _hWnd, _dwFlags ) )
			return false;

		if( m_nReadDataMode == READ_DATA_BUFFERED )
		{
			//{{ modified when 06. 05. 02
			// buffered
			DIPROPDWORD dipdw;

			dipdw.diph.dwSize = sizeof( DIPROPDWORD );
			dipdw.diph.dwHeaderSize = sizeof( DIPROPHEADER );
			dipdw.diph.dwObj = 0;
			dipdw.diph.dwHow = DIPH_DEVICE;
			dipdw.dwData = 16;

			HRESULT hr;

			hr = m_lpDevice->SetProperty( DIPROP_BUFFERSIZE, &dipdw.diph );
			if( FAILED( hr ) )
			{
				return false;
			}
			//}} modified when 06. 05. 02
		}

		m_lpDevice->Acquire();

		return true;
	}

	bool CInputMouse::destroy()
	{
		if( m_lpDevice )
		{
			m_lpDevice->Unacquire();
			m_lpDevice->Release();
			m_lpDevice = NULL;
		}

		if( m_pDeviceObjectData )
		{
			delete [] m_pDeviceObjectData;
			m_pDeviceObjectData = NULL;
		}

		return true;
	}


	void CInputMouse::process()
	{
		if( m_nReadDataMode )
			readBufferedData();
		else
			readImmediateData();
	}

	void CInputMouse::active( bool _bActive )
	{
		if( _bActive )
			m_lpDevice->Acquire();
		else
			m_lpDevice->Unacquire();
	}


	bool CInputMouse::createDirectInputDevice()
	{
		HRESULT hr = m_lpDI->CreateDevice(GUID_SysMouse, &m_lpDevice, NULL); 
		if( FAILED(hr) )
		{
			// dinput object destroy
			return false;
		} 

		return true;
	}

	bool CInputMouse::setDataFormat()
	{
		HRESULT hr;

		hr = m_lpDevice->SetDataFormat( &c_dfDIMouse2 );
		if( FAILED( hr ) )
		{
			return false;
		}

		return true;
	}

	bool CInputMouse::setBehavior( HWND _hWnd, DWORD _dwFlags )
	{
		HRESULT hr;

		hr = m_lpDevice->SetCooperativeLevel( _hWnd, _dwFlags );
		if( FAILED( hr ) )
		{
			return false;
		}

		return true;
	}


	void CInputMouse::readImmediateData()
	{
		HRESULT hr;
		DIMOUSESTATE2 dims2;

		ZeroMemory( &dims2, sizeof(dims2) );
		hr = m_lpDevice->GetDeviceState( sizeof(DIMOUSESTATE2), &dims2 );
		if( FAILED(hr) ) 
		{
			hr = m_lpDevice->Acquire();
			while( hr == DIERR_INPUTLOST ) 
				hr = m_lpDevice->Acquire();

			return;
		}

		m_MousePoint.x += dims2.lX;
		m_MousePoint.y += dims2.lY;

		(*m_pfImmediate)( m_MousePoint.x, m_MousePoint.y, dims2.lZ, (char*)dims2.rgbButtons );
	}

	void CInputMouse::readBufferedData()
	{
		memset( m_pDeviceObjectData, 0, sizeof( DIDEVICEOBJECTDATA ) * m_dwBufferSize );
		DWORD dwElements = m_dwBufferSize;

		HRESULT hr;
		hr = m_lpDevice->GetDeviceData( sizeof( DIDEVICEOBJECTDATA ), m_pDeviceObjectData, &dwElements, 0 );
		if( FAILED( hr ) )
		{
			m_lpDevice->Acquire();
			return;
		}

		if( dwElements == 0 )
			return;

		bool bLBtnDown = false;
		bool bRBtnDown = false;


		//{{ �̷��� �ϸ� dinput�� ����ϴ� �ǹ̰� ����.
		POINT pt;
		GetCursorPos( &pt );
		ScreenToClient( m_hWnd, &pt );

		m_MousePoint.x = pt.x;
		m_MousePoint.y = pt.y;
		//}}

		for( DWORD i=0 ; i<dwElements ; i++ )
		{
			switch( m_pDeviceObjectData[i].dwOfs )
			{
				/*		case DIMOFS_X :
				m_MousePoint.x += m_pDeviceObjectData[i].dwData;
				if( m_MousePoint.x < pt.x )
				m_MousePoint.x = pt.x;
				break;

				case DIMOFS_Y :
				m_MousePoint.y += m_pDeviceObjectData[i].dwData;
				if( m_MousePoint.y < pt.y )
				m_MousePoint.y = pt.y;
				break;
				*/
			case DIMOFS_BUTTON0 :	// l-button
				if( m_pDeviceObjectData[i].dwData )
				{
					(*m_pfBufferedDown)( L_BUTTON, m_MousePoint.x, m_MousePoint.y );
				}
				else
				{
					(*m_pfBufferedUp)( L_BUTTON, m_MousePoint.x, m_MousePoint.y );
				}
				return;

			case DIMOFS_BUTTON1 :	// r-button
				if( m_pDeviceObjectData[i].dwData )
				{
					(*m_pfBufferedDown)( R_BUTTON, m_MousePoint.x, m_MousePoint.y );
				}
				else
				{
					(*m_pfBufferedUp)( R_BUTTON, m_MousePoint.x, m_MousePoint.y );
				}
				return;
			}
		}

		// ���������� ȣ��
		(*m_pfBuffered)( m_MousePoint.x, m_MousePoint.y );
	}

};

