#include "stdafx.h"
#include "EffectObject.h"
