#pragma once
#include "DrawControl.h"
#include "../DrawObject.h"

using namespace std;

class CUIDraw : public CDrawControl, public CDrawObject
{	
public:
	CUIDraw();
	~CUIDraw(void);
	void setValues(int _x, int _y, int _height, int _width, int _texX, int _texY, string fileName);
	void setValues( int _texX, int _texY );	

	void draw(DWORD _timeDelta);

	bool initialize(IDirect3DDevice9* const _device);
	void release();
};
