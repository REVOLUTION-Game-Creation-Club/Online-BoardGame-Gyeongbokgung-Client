 #ifndef _CQueue_H_
#define _CQueue_H_

template <class Type>
class CQueue
{
	struct Node
	{
		Type item;
		struct Node *next;
	};
	enum { Q_SIZE = 10 };

private:
	Node	*front;
	Node	*rear;
	int		items;
	const int qsize;

public:
	CQueue(int i_iQueueSize = Q_SIZE);
	~CQueue(void);
	bool	IsEmpty() const;
	bool	IsFull()	const;
	int		QueueCount() const;
	bool	EnQueue(const Type &item);
	bool	DeQueue(Type &item);
};

template <class Type>
CQueue<Type>::CQueue(int qs) : qsize(qs)
{
	front = rear = NULL;
	items = 0;
}

template <class Type>
CQueue<Type>::~CQueue(void)
{
	Node *temp;
	while(front != NULL)
	{
		temp = front;
		front = front->next;
		delete temp;
	}
}

template <class Type>
bool CQueue<Type>::IsEmpty() const
{
	return items == 0;
}

template <class Type>
bool CQueue<Type>::IsFull() const
{
	return items == qsize;
}

template <class Type>
int CQueue<Type>::QueueCount() const
{
	return items;
}

template <class Type>
bool CQueue<Type>::EnQueue(const Type & item)
{
	if(IsFull())
		return false;
	Node *add = new Node;
	if(add == NULL)
		return false;
	add->item = item;
	add->next = NULL;
	items++;
	if(front == NULL)
		front = add;
	else 
		rear->next = add;
	rear = add;
	return true;
}

template <class Type>
bool CQueue<Type>::DeQueue(Type & item)
{
	if(front == NULL)
		return false;
	item = front->item;
	items--;
	Node * temp = front;
	front = front->next;
	delete temp;
	if(items == 0)
		rear = NULL;
	return true;
}

#endif