#include "StdAfx.h"
#include "Dialogbox.h"

CDialogbox::CDialogbox(void)
{
	kind	= "dialogbox";
	m_ListSize = 0;
	m_lineSpace = 3;
	m_maxString = 20;

	m_device = NULL;
}

CDialogbox::~CDialogbox(void)
{
}

CDialogbox::CDialogbox(string _name)
:CUIDialogbox( _name)
{
	kind	= "dialogbox";
	name	= _name;
	m_ListSize = 0;	

	m_fontPos_x = -99;
	m_fontPos_y = -99;
	m_lineSpace = 3;
	m_maxString = 20;

	m_device = NULL;
}

CDialogbox::CDialogbox(string _name, int _x, int _y, int _width, int _height)
:CUIDialogbox( _name,  _x,  _y,  _width,  _height)
{
	kind	= "dialogbox";
	name	= _name;
	x		= _x;
	y		= _y;
	width	= _width;
	height	= _height;
	m_ListSize = 0;
	m_maxString = 20;


	m_fontPos_x = x;
	m_fontPos_y = y;
	m_lineSpace = 3;

	m_device = NULL;
}

CDialogbox::CDialogbox(string _name, int _x, int _y, int _width, int _height, int _texX, int _texY, char* _fileName)
:CUIDialogbox( _name,  _x,  _y,  _width,  _height,  _texX,  _texY, _fileName)
{
	kind	= "dialogbox";
	name	= _name;
	x		= _x;
	y		= _y;
	width	= _width;
	height	= _height;
	m_ListSize = 0;


	tex_x	= _texX;
	tex_y	= _texY;
	setFileNavi(_fileName);

	m_fontPos_x = x;
	m_fontPos_y = y;
	m_lineSpace = 3;
	m_maxString = 20;

	m_device = NULL;
}

void CDialogbox::setFontSize(int _size)
{
	m_fontSize = _size;	
}

void CDialogbox::insertString(string _sentence)
{
	CPrintObject* temp = new CPrintObject(x, y, &_sentence[0]);

	if( m_device != NULL )
	{
		temp->initialize(m_device);
	}

	m_printList.push_back(temp);
	m_stringList.push_back(_sentence);
	m_ListSize++;

	if( m_ListSize > m_maxString )
	{
		m_printList.erase(m_printList.begin());
		m_stringList.erase(m_stringList.begin());
		m_ListSize--;
	}
}

void CDialogbox::insertString(char* _sentence)
{
	CPrintObject* temp = new CPrintObject(x, y, _sentence);

	if( m_device != NULL )
	{
		temp->initialize(m_device);
	}

	m_printList.push_back(temp);
	m_stringList.push_back(_sentence);
	m_ListSize++;

	if( m_ListSize > m_maxString )
	{
		if( m_printList.at( 0 ) )
			delete m_printList.at( 0 );
		m_printList.erase(m_printList.begin());
		m_stringList.erase(m_stringList.begin());
		m_ListSize--;
	}
}

void CDialogbox::eraseString(int _which)
{
	m_stringList.erase(m_stringList.begin() + _which);
	m_printList.erase(m_printList.begin() + _which);
	m_ListSize--;
}

void CDialogbox::refreshString(int _where, string _sentence)
{
	m_printList[_where]->setString(&_sentence[0]);
	m_stringList[_where] = _sentence;
}

void CDialogbox::refreshString(int _where, char* _sentence)
{
	m_printList[_where]->setString(_sentence);
	m_stringList[_where] = _sentence;
}

void CDialogbox::writeString()
{
	CPrintObject* temp;
	int listSize = m_printList.size();

	if( m_fontPos_x == -99 || m_fontPos_y == -99)
	{
		m_fontPos_x = 0;
		m_fontPos_y = 0;
	}

	int view = listSize - m_viewRange;

	if( listSize - m_viewRange < 0 )
		view = 0;

	for( int i = view ; i < listSize ; i++ )
	{
		temp = m_printList[i];
		temp->setColor(m_fontColor_r, m_fontColor_g, m_fontColor_b, m_fontColor_a);
		temp->setSize(m_fontSize);
		temp->setPosition( x + m_fontPos_x, y + m_fontPos_y + ((temp->getSize() + m_lineSpace) * (i - view)));
		m_printList[i]->draw(0);
	}
}

void CDialogbox::setFontColor(float _r, float _g, float _b, float _a)
{
	m_fontColor_r = _r;
	m_fontColor_g = _g;
	m_fontColor_b = _b;
	m_fontColor_a = _a;
}

bool CDialogbox::initialize(IDirect3DDevice9* _device)
{
	m_device = _device;

	for( int i = 0; i < m_printList.size() ; i++ )
	{
		m_printList[i]->initialize(_device);
	}

	return true;
}

void CDialogbox::release()
{
	for( int i = 0; i < m_printList.size() ; i++ )
	{
		m_printList[i]->release();
		delete m_printList[i];
	}

	m_printList.clear();
}

void CDialogbox::setFontPosition(int _x, int _y)
{
	if( _x > width || _x < 0 )
	{
		_x = 0;
	}
	if( _y > height || _y < 0)
	{
		_y = 0;
	}
	m_fontPos_x =_x;
	m_fontPos_y =_y;
}

void CDialogbox::setMaxString(int _max)
{
	m_maxString = _max;

	if( m_ListSize > m_maxString )
	{
		for( int i = 0 ; i < m_ListSize - m_maxString ; i++ )
		{
			m_printList.erase(m_printList.begin());
			m_stringList.erase(m_stringList.begin());
		}		
	}

}

