#ifndef __NetworkState_h_
#define __NetworkState_h_

#include "IMessageState.h"
#include "MessageManager.h"
#include "ClientSocket.h"
#include "Packet.h"

class CNetworkState : public IMessageState
{
	//{{ bakky
	typedef	void (CNetworkState::*RecvFunc)(Packet& packet);

	map<int, RecvFunc>	m_mapRecvFunc;
	void	makeRecvFunc();
	void parsing(Packet& packet);
	//}}

private:
	CMessageManager*			m_messageManager;
	CClientSocket*				m_clientSocket;
	bool						m_isConnected;
	char*						m_clientServIP;
	bool						m_isMajor;

public:
								CNetworkState(CMessageManager* _messageManager);
	virtual						~CNetworkState();
	bool						initialize();
	void						cleanup();

	void						processPacket();
	static void					parsingPacket(Packet& _packet);
	void						broadcast(Packet& _packet);
	void						connectToUserServer();
	void 						sendMessageToClientServer(Packet& _packet);
	void 						sendMessageToMainServer(Packet& _packet);

	// ����
	void						onNotifyLoadEnd( Packet& _packet );
	void						onReqUserServerConnect(Packet& _packet);
	void						onAckUserServerConnect( Packet& _packet );
	void 						onReqServerConnect(Packet& _packet);
	void 						onReqClientConnect(Packet& _packet);
	void 						onReqServerDisconnect(Packet& _packet);
	void						onReqClientDisconnect(Packet& _packet);
	void						onReqGameStart(Packet& _packet);
	void						onReqGameEnd(Packet& _packet);
	void						onReqTurnIn(Packet& _packet);
	void						onReqTurnOut(Packet& _packet);
	void						onReqRulletStart(Packet& _packet);
	void						onReqRulletStop(Packet& _packet);
	void						onReqCharacterMove(Packet& _packet);
	void						onReqCharacterChange(Packet& _packet);
	void						onReqItemGet(Packet& _packet);
	void						onReqItemMagnetic(Packet& _packet);
	void						onReqItemWaterBall(Packet& _packet);
	void						onReqItemThunder(Packet& _packet);
	void						onReqTileWaterball(Packet& _packet);
	void						onReqGameChat(Packet& _packet);

	void						onAckServerConnect(Packet& _packet);
	void						onAckClientConnect(Packet& _packet);
	void						onAckServerDisconnect(Packet& _packet);
	void						onAckClientDisconnect(Packet& _packet);
	void						onAckGameStart(Packet& _packet);
	void						onAckGameEnd(Packet& _packet);
	void						onAckTurnIn(Packet& _packet);
	void						onAckTurnOut(Packet& _packet);
	void						onAckRulletStart(Packet& _packet);
	void						onAckRulletStop(Packet& _packet);
	void						onAckCharacterMove(Packet& _packet);
	void						onAckCharacterSync(Packet& _packet);
	void						onAckCharacterChange(Packet& _packet);
	void						onAckItemGet(Packet& _packet);
	void						onAckItemMagnetic(Packet& _packet);
	void						onAckItemWaterBall(Packet& _packet);
	void						onAckItemThunder(Packet& _packet);
	void						onAckTileWaterball(Packet& _packet);
	void						onAckGameChat(Packet& _packet);
	void						onReqTurnSkip(Packet& _packet);
	void						onAckTurnSkip(Packet& _packet);
	// ��
	void						onUserInfomation( Packet& _packet );
	void						onDropedOutPlayer( Packet& _packet );
	void						onAckLeaveRoom( Packet& _packet );
	void						onAckImReady( Packet& _packet );
	void						onAckWaitPlz( Packet& _packet );
	void						onRoomInformation( Packet& _packet );
	void						onLeaveUser( Packet& _packet );
	void						onAckCharSelChange( Packet& _packet );
//	void						onErrorCode( Packet& _packet );	
	void						onAckGameStartUp( Packet& _packet );
	void						onAckRoomChat( Packet& _packet );

	// ����
	bool						connectServer(char* _where);
	void						onAckMainServerConnect(Packet& _packet);
	void						onAckChatMessage(Packet& _packet);
	void						onAckLobbyInfoPlayers(Packet& _packet);
	void						onAckNextRoomList(Packet& _packet);
	void						onAckMakeRoom(Packet& _packet);
	void						onAckErrorCode(Packet& _packet);


	// ���� ����� ó�� ��������
	void	onReqUserGameEnd( Packet& _packet );
	void	onACkGameEnd( Packet& _packet );
	void	onAckUserGameEnd(  Packet& _packet );

	// ĳ���� ����� �˸��� ��������
	void	onAckChangeCharacter( Packet& _packet );
	void	onReqChangeCharacter( Packet& _packet );
};
#endif
