#ifndef __MagneticState_h__
#define __MagneticState_h__
#include "ICharacterState.h"
#include "Character.h"
#include "Map.h"
class CMagneticState : public ICharacterState
{
private:
	CCharacter*				m_character;
	CCharacter*				m_attackCharacter;
	POINT					m_termPoint;
	int						m_count;

	int						m_walkCount;
	int						m_tileIndex;
	TileInfo				m_nowTile;
	TileInfo				m_nextTile;

	POINT					m_centerPoint;
	POINT					m_targetPoint;

	CMap*					m_map;
	bool					m_firstItemFlag;

	BOOL m_bUseItem;
public:
	CMagneticState(CCharacter* _character);
	virtual					~CMagneticState();
	void					initialize();
	void					release();
	void					stateStart();
	void					stateEnd();
	void					draw(DWORD _timeDelta);
	void					drawWalkCharacter();
	void					finish();

	void					setAttackCharacter(CCharacter* _attackCharacter){ m_attackCharacter = _attackCharacter;}
private :
	void walkCountMinus();

	void passTile();
	void stopTile();
	void startTile();
	void endTile();

	BOOL checkCharOnTile(ITEM_KIND _selectItem);
	BOOL checkWaterOnTile();
	ITEM_KIND selectItem();
};

#endif