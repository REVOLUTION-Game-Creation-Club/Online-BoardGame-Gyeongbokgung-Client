#include "stdafx.h"
#include "LevelState.h"
#include "DrawManager.h"
#include "Map.h"
#include "../RevSound/SoundManager.h"
#include "GameManager.h"
#include "PlayState.h"

using namespace rev;

CLevelState::CLevelState(CCharacter* _character)
{
	this->m_character	= _character;
	m_count				= 0;
	m_effectCount		= 0;
}

CLevelState::~CLevelState()
{
}

void CLevelState::stateStart()
{
}

void CLevelState::stateEnd()
{
}

void CLevelState::draw(DWORD _timeDelta)
{
	UNREFERENCED_PARAMETER(_timeDelta);
	CPlayState* playState = (CPlayState*)CGameManager::getInstance()->getState(GAME_STATE_PLAY);

	// ĳ���� �Ѹ�
	if(m_count == 0)
	{
		getSoundManager()->play("������");
		drawLevelCharacter();
		m_count++;
	}
	else if(m_count < SPRITE_NUM_DELAY*SPRITE_NUM_LEVEL )
	{
		drawLevelCharacter();
		m_count++;
	}
	else if(m_count == SPRITE_NUM_DELAY*SPRITE_NUM_LEVEL )
	{
		playState->getEffect()->setVisible(true);
		CDrawManager::getInstance()->makeCharacterTopLayer(playState->getEffect()->getOrder());
		m_effectCount++;
		m_count++;
	}

	// ����Ʈ �Ѹ�
	else if(m_effectCount < SPRITE_NUM_DELAY*SPRITE_NUM_EFFECT )
	{
		drawLevelCharacter();
		drawLevelEffect();
		m_effectCount++;
	}

	// ����Ʈ �Ѹ�
	else if(m_effectCount == SPRITE_NUM_DELAY*SPRITE_NUM_EFFECT)
	{
		drawLevelCharacter();
		drawLevelEffect();
		playState->getEffect()->setVisible(false);
		m_effectCount = 0;
		m_count = 0;
		// ������ ��������Ʈ ��� �Ŀ� CHARACTER_STATE_WALK�� ��ȯ
		m_character->setCharacterState(CHARACTER_STATE_WALK);
	}
	else
	{
		drawLevelCharacter();
		drawLevelEffect();
		m_effectCount = 0;
		m_count = 0;
	}
}

void CLevelState::drawLevelCharacter()
{
	CPlayState* playState = (CPlayState*)CGameManager::getInstance()->getState(GAME_STATE_PLAY);

	POINT position;
	position.x = m_character->getCenterPoint().x - 75 - playState->getMap()->getScreenPoint().x;
	position.y = m_character->getCenterPoint().y - 125 - playState->getMap()->getScreenPoint().y;
	m_character->setPosition(position);
	m_character->setSpriteType(SPRITE_TYPE_LEVEL);
	m_character->setSpriteNo(m_count/SPRITE_NUM_DELAY%SPRITE_NUM_LEVEL);
	m_character->BitBlt();
	m_count++;
}
void CLevelState::drawLevelEffect()
{
	CPlayState* playState = (CPlayState*)CGameManager::getInstance()->getState(GAME_STATE_PLAY);
	m_character->setSize(150,150);

	POINT position;
	position.x = m_character->getCenterPoint().x - 100 - playState->getMap()->getScreenPoint().x;
	position.y = m_character->getCenterPoint().y - 150 - playState->getMap()->getScreenPoint().y;

	playState->getEffect()->setPosition(position);
	playState->getEffect()->setSpriteType(1); // ������
	playState->getEffect()->setSpriteNo(m_effectCount/SPRITE_NUM_DELAY%SPRITE_NUM_EFFECT);
}
