#include "StdAfx.h"
#include "UIImageBox.h"

CUIImageBox::CUIImageBox(void)
{
	kind = "imagebox";
}

CUIImageBox::CUIImageBox(string _name)
{
	kind = "imagebox";
	name	= _name;	
}

CUIImageBox::CUIImageBox(string _name, int _x, int _y, int _width, int _height)
{
	kind = "imagebox";
	name	= _name;
	x		= _x;
	y		= _y;
	width	= _width;
	height	= _height;
}

CUIImageBox::CUIImageBox(string _name, int _x, int _y, int _width, int _height, int _texX, int _texY, char* _fileName)
{
	kind = "imagebox";
	name	= _name;
	x		= _x;
	y		= _y;
	width	= _width;
	height	= _height;
	tex_x	= _texX;
	tex_y	= _texY;
	setFileNavi(_fileName);
}

CUIImageBox::~CUIImageBox(void)
{
}

void CUIImageBox::setImageFlag(int _flag)
{
	m_imageFlag = _flag;
}

void CUIImageBox::setImageState(int _flag)
{
	//if( _flag < m_imageFlag )
	{
		tex_x = tex_x_normal + width * _flag;
	}	
}
