#include "stdafx.h"
#include "GameManager.h"
#include "DrawManager.h"
#include "UserManager.h"
#include "UI/CUIManager.h"
#include "PlayState.h"
#include "LobbyState.h"
#include "RoomState.h"
#include "TitleState.h"
#include "LoadingState.h"
#include "ResultState.h"
#include "EndState.h"
#include "OpenningState.h"

CGameManager* CGameManager::selfInstance = 0;

CGameManager::CGameManager()
{
	m_mousePoint.x	= 0;
	m_mousePoint.y	= 0;

	m_openningState = new COpenningState(this);
	m_titleState = new CTitleState(this);
	m_lobbyState = new CLobbyState(this);
	m_roomState = new CRoomState(this);
	m_loadingState = new CLoadingState(this);
	m_playState = new CPlayState(this);
	m_resultState = new CResultState(this);
	m_endState = new CEndState(this);

	m_nowState = m_openningState;
	m_gameState = GAME_STATE_OPENNING;
	//m_nowState = m_loadingState;
	//m_gameState = GAME_STATE_LOADING;

	//m_nowState = m_playState;
	//m_gameState = GAME_STATE_PLAY;

	//m_nowState = m_endState;
	//m_gameState = GAME_STATE_END;

//	m_nowState = m_roomState;
//	m_gameState = GAME_STATE_ROOM;


	//m_nowState = m_titleState;
	//m_gameState = GAME_STATE_TITLE;
//	m_nowState = m_resultState;
//	m_gameState = GAME_STATE_RESULT;
}

CGameManager::~CGameManager()
{
	delete m_playState;
	m_playState = 0;
	delete m_lobbyState;
	m_lobbyState = 0;
	delete m_roomState;
	m_roomState = 0;
	delete m_titleState;
	m_titleState = 0; 
	delete m_loadingState;
	m_loadingState = 0;
	delete m_resultState;
	m_resultState = 0;
	delete m_endState;
	m_endState = 0;

	delete m_openningState;
	m_openningState = 0;
}

CGameManager* CGameManager::getInstance()
{
	if( selfInstance == 0 )
		selfInstance = new CGameManager();

	return selfInstance;
}

void CGameManager::release()
{
	if( selfInstance != 0 )
	{
		m_nowState->release();
		delete selfInstance;
		selfInstance = 0;
	}
}

bool CGameManager::initialize()
{	
	//m_roomState->initialize();
	//m_playState->initialize();
	m_nowState->initialize();
	return true;
}

void CGameManager::onKeyboard(WPARAM _wParam)
{
	m_nowState->onKeyboard(_wParam);
}
void CGameManager::processMouseMove()
{
	m_nowState->processMouseMove();
}
void CGameManager::onUpdate()
{
	m_nowState->onUpdate();
}

IGameState* CGameManager::getState(GAME_STATE _gameState)
{
	switch(_gameState)
	{
	case GAME_STATE_NOW:
		return m_nowState;
	case GAME_STATE_PLAY:
		return m_playState;
	case GAME_STATE_LOBBY:
		return m_lobbyState;
	case GAME_STATE_ROOM:
		return m_roomState;
	case GAME_STATE_TITLE:
		return m_titleState;
	case GAME_STATE_LOADING:
		return m_loadingState;
	case GAME_STATE_RESULT:
		return m_resultState;
	case GAME_STATE_END:
		return m_endState;

	case GAME_STATE_OPENNING :
		return m_openningState;
	default:
		return NULL;
	}
}

void CGameManager::setState(GAME_STATE _gameState)
{
	if(_gameState == GAME_STATE_NOW)
		return;
	CDrawManager::getInstance()->setStateFlag(true);

	// IGameState* prevState = m_nowState;
	
	m_gameState = _gameState;

	switch(m_gameState)
	{
	case GAME_STATE_PLAY:
		m_nowState->release();
		CUIManager::getInstance().unregisterDrawObject();
		m_playState->initialize();
		m_nowState = m_playState;
		break;
	case GAME_STATE_LOBBY:
		m_nowState->release();
		CUIManager::getInstance().unregisterDrawObject();
		m_lobbyState->initialize();
		m_nowState = m_lobbyState;
		break;
	case GAME_STATE_ROOM:
		m_nowState->release();
		CUIManager::getInstance().unregisterDrawObject();
		m_roomState->initialize();
		m_nowState = m_roomState;
		break;
	case GAME_STATE_TITLE:
		m_nowState->release();
		CUIManager::getInstance().unregisterDrawObject();
		m_titleState->initialize();
		m_nowState = m_titleState;
		break;
	case GAME_STATE_LOADING:
		m_nowState->release();
		CUIManager::getInstance().unregisterDrawObject();
		m_loadingState->initialize();
		m_nowState = m_loadingState;
		break;
	case GAME_STATE_RESULT:
		m_nowState->release();
		CUIManager::getInstance().unregisterDrawObject();
		m_resultState->initialize();
		m_nowState = m_resultState;
		break;
	case GAME_STATE_END:
		m_nowState->release();
		CUIManager::getInstance().unregisterDrawObject();
		m_endState->initialize();
		m_nowState = m_endState;
		break;

	case GAME_STATE_OPENNING :
		m_nowState->release();
		CUIManager::getInstance().unregisterDrawObject();
		m_openningState->initialize();
		m_nowState = m_openningState;
		break;

	default:
		break;
	}

	CDrawManager::getInstance()->setStateFlag(false);
}

GAME_STATE CGameManager::getGameState()
{
	return m_gameState;
}


void	CGameManager::setNoticeString( char* msg, float r, float g, float b, float a )
{
	if( this->m_playState )
	{
		CPrintObject* printObject = ((CPlayState*)m_playState)->getMessage();

		if( printObject )
		{
			printObject->setColor(r, g, b, a);
			printObject->setString( msg );
		}
	}
}