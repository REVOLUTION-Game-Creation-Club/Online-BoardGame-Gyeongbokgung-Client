#include "stdafx.h"
#include "UIDraw.h"
#include "CUIManager.h"

CUIDraw::CUIDraw() 
{
}

CUIDraw::~CUIDraw(void)
{
}

void CUIDraw::draw(DWORD _timeDelta)
{
	UNREFERENCED_PARAMETER(_timeDelta);

	int i, j;
	for( i = 0; i < (int)drawContainerList.size() ; i++ )
	{
		if( drawContainerList[i]->visible )
		{
			setValues(drawContainerList[i]->x, drawContainerList[i]->y, drawContainerList[i]->height, drawContainerList[i]->width
				,drawContainerList[i]->tex_x, drawContainerList[i]->tex_y, drawContainerList[i]->getFileNavi() );
			BitBlt();
			
			for( j = 0; j < drawContainerList[i]->getListSize() ; j++ )
			{
				CUIControl& control = CUIManager::getInstance()[drawContainerList[i]->name][j];
				if( control.visible )	
				{
					setValues(control.x, control.y, control.height, control.width,control.tex_x, control.tex_y, control.getFileNavi() );
					BitBlt();
					if( control.kind.compare("dialogbox") == 0 || control.kind.compare("textbox") == 0)
					{
						((CDialogbox*)&control)->writeString();
					}
				}
			}
		}		
	}
}

void CUIDraw::setValues(int _x, int _y, int _height, int _width, int _texX, int _texY, string fileName)
{
	setPosition(_x, _y);

	setWidth(_width);
	setHeight(_height);

	setTextureRect(_texX, _texY);

	setFileName(fileName);
}

void CUIDraw::setValues( int _texX, int _texY )
{
	setTextureRect(_texX, _texY);
}

bool CUIDraw::initialize(IDirect3DDevice9* const _device)
{
	if(m_fileName[0] == NULL)
		return false;

	m_device = _device;

	D3DXCreateSprite(m_device, &m_sprite);
	CTextureManager::getInstance()->createTexture(_device, m_fileName);

	for( int i = 0; i < (int)drawContainerList.size() ; i++ )
	{
		for( int j = 0; j < drawContainerList[i]->getListSize() ; j++ )
		{
			if( CUIManager::getInstance()[drawContainerList[i]->name][j].kind.compare("dialogbox") == 0 
				|| CUIManager::getInstance()[drawContainerList[i]->name][j].kind.compare("textbox") == 0)
			{
				((CDialogbox*)&CUIManager::getInstance()[drawContainerList[i]->name][j])->initialize(_device);
			}
		}
	}
	return true;
}

void CUIDraw::release()
{
	for( int i = 0; i < (int)drawContainerList.size() ; i++ )
	{
		for( int j = 0; j < drawContainerList[i]->getListSize() ; j++ )
		{
			if( CUIManager::getInstance()[drawContainerList[i]->name][j].kind.compare("dialogbox") == 0 
				|| CUIManager::getInstance()[drawContainerList[i]->name][j].kind.compare("textbox") == 0)
			{
				((CDialogbox*)&CUIManager::getInstance()[drawContainerList[i]->name][j])->release();
			}
		}				
	}

	if(m_fileName=="")
		return;

	//{{ bakky : texture�� release�� ���༭ delete ������.
	//CTextureManager::getInstance()->getTexture(m_fileName)->releaseTexture();
	CTextureManager::getInstance()->deleteTexture(m_fileName);
	//}}

	if(m_sprite != NULL)
	{
		m_sprite->Release();
		m_sprite = NULL;
	}
}