#include "stdafx.h"
#include "PrintObject.h"

CPrintObject::CPrintObject()
{
	m_font			= NULL;
	m_color			= D3DXCOLOR( 0.0f, 0.0f, 0.0f, 1.0f );
	setPosition(0,0);
	m_fontSize		= 0;
	setString("");
	m_visible		= true;
}

CPrintObject::CPrintObject(int _x, int _y, char* _str)
{
	m_font			= NULL;
	m_color			= D3DXCOLOR( 0.0f, 0.0f, 0.0f, 1.0f );
	setPosition(_x,_y);
	m_fontSize		= 0;
	setString(_str);
	m_visible		= true;
}

CPrintObject::CPrintObject(int _x, int _y, int _size, char* _str)
{
	m_font			= NULL;
	m_color			= D3DXCOLOR( 0.0f, 0.0f, 0.0f, 1.0f );
	setPosition(_x,_y);
	m_fontSize		= _size;
	setString(_str);
}

CPrintObject::~CPrintObject()
{
	release();
}
#include <Dxerr.h>
bool CPrintObject::initialize(IDirect3DDevice9* _device)
{
	HDC hDC = GetDC( NULL );
	int nLogPixelsY = GetDeviceCaps(hDC, LOGPIXELSY);
	TCHAR strFont[LF_FACESIZE];

	ReleaseDC( NULL, hDC );

	int nHeight = -m_fontSize * nLogPixelsY / 72;	

	HRESULT hr = 
	D3DXCreateFont( _device,				// D3D device
		nHeight,							// Height
		0,									// Width
		FW_NORMAL,							// Weight
		1,									// MipLevels, 0 = autogen mipmaps
		FALSE,								// Italic
		DEFAULT_CHARSET,					// CharSet
		OUT_DEFAULT_PRECIS,					// OutputPrecision
		DEFAULT_QUALITY,					// Quality
		DEFAULT_PITCH | FF_DONTCARE,		// PitchAndFamily
		"����+��å10",							// pFaceName
		&m_font);							// ppFont

	if( FAILED( hr ) )
	{
		hr = 
		D3DXCreateFont( _device,				// D3D device
			nHeight,							// Height
			0,									// Width
			FW_NORMAL,							// Weight
			1,									// MipLevels, 0 = autogen mipmaps
			FALSE,								// Italic
			DEFAULT_CHARSET,					// CharSet
			OUT_DEFAULT_PRECIS,					// OutputPrecision
			DEFAULT_QUALITY,					// Quality
			DEFAULT_PITCH | FF_DONTCARE,		// PitchAndFamily
			NULL,							// pFaceName
			&m_font);							// ppFont
	}

	return true;
}

void CPrintObject::release()
{
	if(m_font != NULL)
	{
		m_font->Release();
		m_font = NULL;
	}
}

void CPrintObject::setPosition(int _x, int _y)
{
	SetRect( &m_rect, _x, _y, _x, _y );
}

void CPrintObject::draw(DWORD _timeDelta)
{
	UNREFERENCED_PARAMETER(_timeDelta);
	if(m_visible == false)
		return;
	if(m_font != NULL)
		m_font->DrawText( NULL,m_string, -1, &m_rect, DT_NOCLIP, m_color);
}
