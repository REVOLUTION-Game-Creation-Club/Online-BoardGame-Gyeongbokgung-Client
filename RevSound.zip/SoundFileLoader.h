#ifndef __SOUND_FILE_LOADER_H__
#define __SOUND_FILE_LOADER_H__

#include <string>

#ifdef _UNICODE
typedef std::wstring	tstring;
#else
typedef std::string		tstring;
#endif

namespace rev
{

class CSoundFileLoader
{
protected :
	tstring		m_strName;	// file path

public :

	virtual ~CSoundFileLoader()	{}

	virtual void	initialize() = 0;
	virtual bool	close()	= 0;

	virtual bool	open( TCHAR* szFileName ) = 0;
	virtual	bool	read( BYTE*	pDestBuffer, DWORD dwSizeToRead, DWORD* pdwSizeRead ) = 0;
	virtual DWORD	getSize() = 0;
	virtual bool	reset() = 0;
	virtual WAVEFORMATEX* getFormat()	 = 0;
	virtual bool	isEof() = 0;
	virtual void	destroy() = 0;

	tstring&	getName()	{	return m_strName;	}
};

}
#endif	//__SOUND_FILE_LOADER_H__