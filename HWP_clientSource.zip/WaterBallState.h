#ifndef __WaterBallState_h__
#define __WaterBallState_h__
#include "ICharacterState.h"
#include "Character.h"

class CWaterBallState : public ICharacterState
{
private:
	CCharacter*				m_character;
	int						m_count;
public:
							CWaterBallState(CCharacter* _character);
	virtual					~CWaterBallState();
	void					stateStart();
	void					stateEnd();
	void					draw(DWORD _timeDelta);
};

#endif