#ifndef __RestState_h__
#define __RestState_h__
#include "ICharacterState.h"
#include "Character.h"

class CRestState : public ICharacterState
{
private:
	CCharacter*				m_character;
	int						m_count;
public:
	CRestState(CCharacter* _character);
	virtual					~CRestState();
	void					stateStart();
	void					stateEnd();
	void					draw(DWORD _timeDelta);
	void					drawRestCharacter();
};

#endif