#include "stdafx.h"
#include "NotExistState.h"

CNotExistState::CNotExistState(CCharacter* _character)
{
	this->m_character = _character;
}

CNotExistState::~CNotExistState()
{
}

void CNotExistState::draw(DWORD _timeDelta)
{
}