#include "stdafx.h"
#include "Texture.h"

CTexture::CTexture(IDirect3DDevice9* _device)
{
	m_device = _device;
	m_texture= NULL;
}

CTexture::~CTexture()
{

}

void CTexture::createTexture(string _fileName)
{
	D3DXCreateTextureFromFileEx(m_device, _fileName.c_str(), D3DX_DEFAULT, D3DX_DEFAULT, 1, 0, D3DFMT_A8R8G8B8,
		D3DPOOL_DEFAULT, D3DX_DEFAULT, D3DX_DEFAULT, D3DCOLOR_ARGB( 0xFF,0,255,200), NULL,NULL, &m_texture);
}

void CTexture::releaseTexture()
{
	if(m_texture != NULL)
	{
		m_texture->Release();
		m_texture = NULL;
	}
}