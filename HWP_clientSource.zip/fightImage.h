#ifndef __FightImage__h_
#define __FightImage__h_
#include "SpriteObject.h"
#include "Character.h"

class CFightImage : public CSpriteObject
{
private:
	bool	m_isWin;
	CHARACTER_KIND		m_kind1;
	CHARACTER_KIND		m_kind2;

public:
	CFightImage();
	void draw(DWORD _timeDelta);
	void setKind(CHARACTER_KIND _kind1,CHARACTER_KIND _kind2);
	void setWin(bool _isWin){m_isWin = _isWin;}
};

#endif