#include "stdafx.h"
#include "LocalState.h"
#include "ui/CUIManager.h"
#include "Character.h"
#include "DrawManager.h"
#include "UserManager.h"
#include "GameManager.h"
#include "PlayState.h"

CLocalState::CLocalState(CMessageManager* _messageManager)
{
	this->m_messageManager = _messageManager;
}
CLocalState::~CLocalState()
{

}
bool CLocalState::initialize()
{
	return true;
}
void CLocalState::cleanup()
{

}
void CLocalState::processPacket()
{
}

void CLocalState::parsingPacket(Packet& _packet)
{
	CLocalState* localState = (CLocalState*)CMessageManager::getInstance()->getState(MESSAGE_STATE_LOCAL);

	switch(_packet.id())
	{
	case REQ_GAME_START:
		localState->onAckGameStart(_packet);
		break;
	case REQ_GAME_END:
		localState->onAckGameEnd(_packet);
		break;
	case REQ_TURN_IN:
		localState->onAckTurnIn(_packet);
		break;
	case REQ_TURN_OUT:
		localState->onAckTurnOut(_packet);
		break;
	case REQ_RULLET_STOP:
		localState->onAckRulletStop(_packet);
		break;
	case REQ_CHARACTER_MOVE:
		localState->onAckCharacterMove(_packet);
		break;
	case REQ_CHARACTER_CHANGE:
		localState->onAckCharacterChange(_packet);
		break;
	case REQ_ITEM_MAGNETIC:
		localState->onAckItemMagnetic(_packet);
		break;
	case REQ_ITEM_WATERBALL:
		localState->onAckItemWaterBall(_packet);
		break;
	case REQ_ITEM_THUNDER:
		localState->onAckItemThunder(_packet);
		break;
	case REQ_TILE_WATERBALL:
		localState->onAckTileWaterball(_packet);
		break;
	case REQ_GAME_CHAT:
		localState->onAckGameChat(_packet);
		break;

	default:
		break;
	}
}
void CLocalState::broadcast(Packet& _packet)
{

}
void CLocalState::sendMessageToMainServer(Packet& _packet)
{
}

void CLocalState::sendMessageToClientServer(Packet& _packet)
{
	parsingPacket(_packet);
}

void CLocalState::onAckGameStart(Packet& _packet)
{
	UNREFERENCED_PARAMETER(_packet);

	CUIManager::getInstance()["container1"].getDialogBox("level").refreshString(0, "0");
	CUIManager::getInstance()["container1"].getDialogBox("exp").refreshString(0, "0");

	Packet packet(REQ_TURN_IN);
	packet << CUserManager::getInstance()->getMyUserId();
	sendMessageToClientServer(packet);

	//{{ sound
	getSoundManager()->play( "map", true );
	//}}
}

void CLocalState::onAckGameEnd(Packet& _packet)
{
	UNREFERENCED_PARAMETER(_packet);

	//{{ sound
	getSoundManager()->stop( "map" );
	//}}
}

void CLocalState::onAckTurnIn(Packet& _packet)
{
	int userId = 0;
	_packet >> userId;
	CCharacter* character = CUserManager::getInstance()->getNowTurnUser()->getSelectCharacter();
	CDrawManager::getInstance()->makeCharacterTopLayer(character->getOrder());
	CPlayState* playState = (CPlayState*)(CPlayState*)CGameManager::getInstance()->getState(GAME_STATE_PLAY);

	playState->getMap()->setScreenPointAtCharacter(character);
	
	// �귿�� �ʱ�ȭ
	playState->getRullet()->timeStop();
	playState->getRullet()->rulletStop(0);

	char userName[128];
	strcpy_s(userName,CUserManager::getInstance()->getNowTurnUser()->getName());
	CUIManager::getInstance()["container1"].getDialogBox("username").refreshString(0, userName);
	char level[128],exp[128];
	sprintf_s(level,"%d",character->getLevel());
	CUIManager::getInstance()["container1"].getDialogBox("level").refreshString(0,level);
	sprintf_s(exp,"%d",character->getLevel());
	CUIManager::getInstance()["container1"].getDialogBox("exp").refreshString(0, exp);
	

	int face = character->getKind();
	CUIManager::getInstance()["container1"]["characterface"].setImageState(face);

	int itemKind = character->getItemSlot();
	CUIManager::getInstance()["container1"]["itemslot"].setImageState(itemKind);


	int completeNum = CUserManager::getInstance()->getNowTurnUser()->getCompleteNum();
	int characterNum = CUserManager::getInstance()->getNowTurnUser()->getCharacterNum();

	//char message1[128];
	//sprintf_s(message1,"%d / %d",completeNum,characterNum);
	//playState->getCompleteNum()->setString(message1);


	char message2[128];
	sprintf_s(message2,"%s���� �����Դϴ�.",CUserManager::getInstance()->getNowTurnUser()->getName());
	playState->getMessage()->setString(message2);



	playState->getRullet()->timeStart();
	character->setCharacterState(CHARACTER_STATE_WAIT);
}

void CLocalState::onAckTurnOut(Packet& _packet)
{
	int userId = 0;
	_packet >> userId;

	CPlayState* playState = (CPlayState*)(CPlayState*)CGameManager::getInstance()->getState(GAME_STATE_PLAY);

//	playState->getTurnObject()->passTurn();
	int nowTurnUser = CUserManager::getInstance()->turnOut();

	CCharacter* character = CUserManager::getInstance()->getNowTurnUser()->getSelectCharacter();
	int characterKind = character->getKind();
	CUIManager::getInstance()["container1"]["characterface"].setImageState(characterKind);

	int itemKind = CUserManager::getInstance()->getNowTurnUser()->getSelectCharacter()->getItemSlot();
	CUIManager::getInstance()["container1"]["itemslot"].setImageState(itemKind);

	Packet packet(REQ_TURN_IN);
	packet << CUserManager::getInstance()->getMyUserId();
	sendMessageToClientServer(packet);
}

void CLocalState::onAckRulletStop(Packet& _packet)
{
	int num = 0;
	_packet >> num;
	CPlayState* playState = (CPlayState*)CGameManager::getInstance()->getState(GAME_STATE_PLAY);

	playState->getRullet()->timeStop();
	playState->getRullet()->rulletStop(num);

	Packet packet(REQ_CHARACTER_MOVE);
	packet << num;
	sendMessageToClientServer(packet);
	getSoundManager()->stopEffectSound();
}

void CLocalState::onAckCharacterMove(Packet& _packet)
{
	int num = 0;
	_packet >> num;

	CCharacter* character = CUserManager::getInstance()->getNowTurnUser()->getSelectCharacter();

	switch(character->getKind())
	{
	case CHARACTER_KIND_BOY:
		break;
	case CHARACTER_KIND_GIRL:
		if(num > 0)
			num++;
		break;
	case CHARACTER_KIND_GIANT:
		if(num == 0)
			num = 1;
		else if(num > 0)
			num--;
		break;
	}
	if(character->isFrog() == true)
	{
		num = num*(-1);
		character->setFrog(false);
	}
	if(character->isInline() == true)
	{
		num = num+2;
		character->setInline(false);
	}
	character->setWalkCount(num);

	CPlayState* playState = (CPlayState*)CGameManager::getInstance()->getState(GAME_STATE_PLAY);

	if(CUserManager::getInstance()->isMyTurn())
		character->setShorPathCountZero();

	if(playState->getRullet()->isBingo() == true)
	{
		if(character->addExperience(3) == true)
		{
			character->setCharacterState(CHARACTER_STATE_LEVEL);
		}
		else
		{
			character->setCharacterState(CHARACTER_STATE_EXP);
		}
	}
	else
	{
		character->setCharacterState(CHARACTER_STATE_WALK);
	}
}

void CLocalState::onAckCharacterChange(Packet& _packet)
{
	UNREFERENCED_PARAMETER(_packet);

	CUserManager::getInstance()->getNowTurnUser()->changeSelectCharacter();

	int face = CUserManager::getInstance()->getNowTurnUser()->getSelectCharacter()->getKind();
	CUIManager::getInstance()["container1"]["characterface"].setImageState(face);

	int itemKind = CUserManager::getInstance()->getNowTurnUser()->getSelectCharacter()->getItemSlot();
	CUIManager::getInstance()["container1"]["itemslot"].setImageState(itemKind);

	int userId = CUserManager::getInstance()->getNowUserId();

	CPlayState* playState = (CPlayState*)CGameManager::getInstance()->getState(GAME_STATE_PLAY);

//	playState->getTurnObject()->characterChange(userId);

	CCharacter* character = CUserManager::getInstance()->getNowTurnUser()->getSelectCharacter();
	if(character->getCharacterState() == CHARACTER_STATE_NOTEXIST)
	{
		character->setCharacterState(CHARACTER_STATE_WAIT);
	}
	CDrawManager::getInstance()->makeCharacterTopLayer(character->getOrder());
	playState->getMap()->setScreenPointAtCharacter(character);
}

void CLocalState::onAckItemMagnetic(Packet& _packet)
{
	UNREFERENCED_PARAMETER(_packet);
	CCharacter* character = CUserManager::getInstance()->getNowTurnUser()->getSelectCharacter();
	CUserManager::getInstance()->firstCharacterMagnetic();
	character->setItemSlot(ITEM_NO);
}
void CLocalState::onAckItemWaterBall(Packet& _packet)
{
	UNREFERENCED_PARAMETER(_packet);
	CCharacter* character = CUserManager::getInstance()->getNowTurnUser()->getSelectCharacter();
	character->setWaterOnce(true);
	character->setCharacterState(CHARACTER_STATE_WATERBALL);
	character->setItemSlot(ITEM_NO);
}
void CLocalState::onAckItemThunder(Packet& _packet)
{
	UNREFERENCED_PARAMETER(_packet);
	CCharacter* character = CUserManager::getInstance()->getNowTurnUser()->getSelectCharacter();

	character->setTurnOutFlag(true);
	character->setCharacterState(CHARACTER_STATE_THUNDER);
	character->setItemSlot(ITEM_NO);
}

void CLocalState::onAckTileWaterball(Packet& _packet)
{
	CPlayState* playState = (CPlayState*)CGameManager::getInstance()->getState(GAME_STATE_PLAY);
	CCharacter* character = CUserManager::getInstance()->getNowTurnUser()->getSelectCharacter();

	int i = 0;
	_packet >> i;

	TileInfo tile = playState->getMap()->getTile(i);
	tile.m_waterball = 1;
	playState->getMap()->setTile(tile,i);
	character->setWaterSuffer(false);
}

void CLocalState::onAckGameChat(Packet& _packet)
{
	char id[8], chatMessage[50];
	_packet >> id >> chatMessage;

	CUIDialogbox& chatlist = CUIManager::getInstance()["container2"].getDialogBox("chatlist");
	chatlist.insertString(chatMessage);
}