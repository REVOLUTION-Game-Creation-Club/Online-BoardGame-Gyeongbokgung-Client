#include "StdAfx.h"
#include "SoundManager.h"
#include "SoundFileLoader.h"
#include "Sound.h"
#include "WaveFileLoader.h"
#include "SoundFileManager.h"
#include "OggFileLoader.h"
#include "WaveFileLoader.h"
#include "EffectSound.h"
#include "StreamSound.h"

namespace rev
{

CSoundManager* CSoundManager::m_pInstance = 0;

CSoundManager::CSoundManager(void)
{
	m_lpSound			= NULL;
	m_lpPrimaryBuffer	= NULL;

	m_hThread	= NULL;
	m_bThread	= false;

	m_pBgm		= NULL;

	ZeroMemory( &m_criticalSection, sizeof( CRITICAL_SECTION ) );

	// mute
	m_bMuteBackgroundMusic	= false;
	m_bMuteEffectSound		= false;

	// volume
	m_fVolumeBackgroundMusic	= 1.0f;
	m_fVolumeEffectSound		= 1.0f;

	// pan
	m_fPanBackgroundMusic	= 0.0f;
	m_fPanEffectSound		= 0.0f;

	m_soundFileManager = new CSoundFileManager();
}

CSoundManager::~CSoundManager(void)
{
	delete m_soundFileManager;
}


void	
CSoundManager::initialize( HWND hWnd )
{
	if( FAILED( createDirectSound( hWnd ) ) )
		return;

	CSound::setDirectSound( m_lpSound );

	InitializeCriticalSection( &m_criticalSection );
 
	DWORD dwThreadId;
	m_bThread = true;
	m_hThread = CreateThread( 0, 0, TimerProc, this, 0, &dwThreadId );
}

	

void	
CSoundManager::release()
{
	if( m_pInstance )
	{
		EnterCriticalSection( &m_criticalSection );
		m_bThread = false;
		LeaveCriticalSection( &m_criticalSection );

		WaitForSingleObject( m_hThread, INFINITE );

		CloseHandle( m_hThread );

		releaseSound();

		releaseDirectSound();

		DeleteCriticalSection( &m_criticalSection );
	}

	delete m_pInstance;
	m_pInstance = NULL;
}

HRESULT
CSoundManager::createDirectSound( HWND hWnd )
{
	// direct sound ��ü ����
	HRESULT hr;

	hr = DirectSoundCreate8( NULL, &m_lpSound, NULL );
	if( FAILED( hr ) )
	{
		debugDXError( hr );

		return hr;
	}

	hr = m_lpSound->SetCooperativeLevel( hWnd, DSSCL_PRIORITY );
	if( FAILED( hr ) )
	{
		debugDXError( hr );
		return hr;
	}

	DSBUFFERDESC	desc;
	ZeroMemory( &desc, sizeof( DSBUFFERDESC ) );
	desc.dwSize			= sizeof( DSBUFFERDESC );
	desc.dwFlags		= DSBCAPS_PRIMARYBUFFER | DSBCAPS_CTRL3D;

	hr = m_lpSound->CreateSoundBuffer( &desc, &m_lpPrimaryBuffer, NULL );
	if( FAILED( hr ) )
	{
		debugDXError( hr );
		return hr;
	}

	return DS_OK;
}

HRESULT
CSoundManager::releaseDirectSound()
{
	if( m_lpPrimaryBuffer )
	{
		m_lpPrimaryBuffer->Release();
		m_lpPrimaryBuffer	= NULL;
	}

	if( m_lpSound )
	{
		m_lpSound->Release();
		m_lpSound	= NULL;
	}

	return DS_OK;
}

bool	
CSoundManager::play( TCHAR* _szFileName, bool bLoop )
{
	if( !m_lpSound )
		return false;

	// �����̸��� effect sound �̸��� ���Ͽ� ���� ���� ������ play
	for( unsigned int i=0 ; i<m_vecEffectSound.size() ; i++ )
	{
		//if( !m_vecEffectSound.at( i )->getName().compare( _szFileName ) )
		if( tstring::npos != m_vecEffectSound.at( i )->getName().find( _szFileName ) )
		{
			m_vecEffectSound.at( i )->play( bLoop );

			if( m_bMuteEffectSound )
			{
				float fVolume = m_fVolumeEffectSound;
				// BGM�� ��ϵ� ��� sound�� volume ����
				setVolumeEffectSound( 0.0f );
				m_fVolumeEffectSound = fVolume;
			}
			else
			{
				setVolumeEffectSound( m_fVolumeEffectSound );
				setPanEffectSound( m_fPanEffectSound );
			}

			break;
		}
	}

	// bgm
	tstring* pBgmPath = NULL;
	if( pBgmPath = m_soundFileManager->findBgm( tstring( _szFileName ) ) )
	{
		loadBackgroundMusic( (TCHAR*)pBgmPath->c_str() );
		m_pBgm->play( bLoop );

		if( m_bMuteBackgroundMusic )
		{
			float	fVolume = m_fVolumeBackgroundMusic;
			// BGM�� ��ϵ� ��� sound�� volume ����
			setVolumeBackgroundMusic( 0.0f );
			m_fVolumeBackgroundMusic = fVolume;
		}
		else
		{
			setVolumeBackgroundMusic( m_fVolumeBackgroundMusic );
			setPanBackgroundMusic( m_fPanBackgroundMusic );
		}

	}

	return true;
}

DWORD WINAPI
CSoundManager::TimerProc( void* lpParam )
{
	CSoundManager*	soundManager = (CSoundManager*)lpParam;
	VectorSound*	vecEffectSound		= &soundManager->m_vecEffectSound;

	while( 1 )
	{
		Sleep( 20 );

		EnterCriticalSection( &soundManager->m_criticalSection );

		if( !soundManager->m_bThread )
			break;

		//{{ effect sound update, ������ sound ����
		for( unsigned int i=0 ; i<vecEffectSound->size() ; i++ )
		{
			vecEffectSound->at( i )->update(); //���� ������...���� 
		}
		//}}

		if( soundManager->m_pBgm )
		{
			// BGM�� ��� ����� �Ǹ� ���� BGM�� ����Ѵ�
			if( soundManager->m_pBgm->update() == false )
			{
				if( soundManager->m_pBgm->isLoop() )
					soundManager->nextBgmPlay( soundManager->m_pBgm->isLoop() );
				else
					soundManager->deleteBgm();
			}
		}

		LeaveCriticalSection( &soundManager->m_criticalSection );
	}

	ExitThread( 0 );

	return 0;
}


void	
CSoundManager::releaseSound()
{

	for( unsigned int i=0 ; i<m_vecEffectSound.size() ; i++ )
	{
		m_vecEffectSound.at( i )->destroy();
		delete m_vecEffectSound.at( i );
	}

	m_vecEffectSound.clear();

	if( m_pBgm )
	{
		delete m_pBgm;
		m_pBgm = NULL;
	}
}

void	
CSoundManager::load( TCHAR* _szFileName )
{
	m_soundFileManager->initialize();

	m_soundFileManager->loadSoundList( _szFileName );

	EnterCriticalSection( &m_criticalSection );
	// effect sound load
	while( 1 )
	{
		tstring* strFileName = m_soundFileManager->nextEffect();
		if( !strFileName )
			break;

		loadEffectSound( (TCHAR*)strFileName->c_str() );
	}

	// bgm load
	if( m_pBgm )
	{
		deleteBgm();
	}
	LeaveCriticalSection( &m_criticalSection );

	tstring*	strBgm = m_soundFileManager->nextBgm();
	if( !strBgm )
		return;

	loadBackgroundMusic( (TCHAR*)strBgm->c_str() );
}

void	
CSoundManager::nextBgmPlay( bool _bLoop )
{
	tstring*	strBgm = m_soundFileManager->nextBgm();
	if( !strBgm )
		return;

	loadBackgroundMusic( (TCHAR*)strBgm->c_str() );
	play( (TCHAR*)strBgm->c_str(), _bLoop );
}

void	
CSoundManager::stop( TCHAR* _szFileName )
{
	if( !m_lpSound )
		return;

	EnterCriticalSection( &m_criticalSection );
	for( unsigned int i=0 ; i<m_vecEffectSound.size() ; i++ )
	{
		//if( !m_vecEffectSound.at( i )->getName().compare( _szFileName ) )
		if( tstring::npos != m_vecEffectSound.at( i )->getName().find( _szFileName ) )
		{
			m_vecEffectSound.at( i )->stop();
			break;
		}
	}

	// bgm
	if( m_pBgm && ( tstring::npos != m_pBgm->getName().find( _szFileName ) ) )
	{
		m_pBgm->stop();
		deleteBgm();
	}	
	LeaveCriticalSection( &m_criticalSection );
}

CSoundManager*	
CSoundManager::getInstance()
{
	if( !m_pInstance )
		m_pInstance = new CSoundManager;

	return m_pInstance;
}

void	
CSoundManager::loadBackgroundMusic( TCHAR* _szFileName )
{
	EnterCriticalSection( &m_criticalSection );
	if( m_pBgm )
	{
		delete m_pBgm;
	}

	CSoundFileLoader* pSoundFile = NULL;
	// wave file
	// ogg file �߰� ����
	tstring strFileName( _szFileName );
	if( strFileName.find( TEXT(".wav") ) != tstring::npos )
	{
		pSoundFile  = new CWaveFileLoader;
	}
	else if( strFileName.find( TEXT(".ogg") ) != tstring::npos )
	{
		pSoundFile  = new COggFileLoader;
	}
	else
		return;

	pSoundFile->open( (TCHAR*)_szFileName );
	if( !pSoundFile )
	{
		debug( "sound file open failed\n" );
		return;
	}

	m_pBgm = new CStreamSound( _szFileName );
	m_pBgm->initialize();
	m_pBgm->load( pSoundFile );
	LeaveCriticalSection( &m_criticalSection );
}

void	
CSoundManager::loadEffectSound( TCHAR* _szFileName )
{
	// sound buffer�� �ٷ� ��´�.
	CSoundFileLoader* pSoundFile  = new CWaveFileLoader;

	pSoundFile->open( (TCHAR*)_szFileName );
	if( !pSoundFile )
	{
		debug( "sound file open failed\n" );
		return;
	}

	CSound* pSound = new CEffectSound( _szFileName );
	pSound->initialize();
	pSound->load( pSoundFile );

	// vector�� ���
	m_vecEffectSound.push_back( pSound );

	delete pSoundFile;
}

// volume	0.0f ~ 1.0f
float	
CSoundManager::getVolumeBackgroundMusic()
{
	return m_fVolumeBackgroundMusic;
}

void	
CSoundManager::setVolumeBackgroundMusic( float _fVolume )
{
	long volume = (int)CSound::linearToLogVol( _fVolume );

	if( m_pBgm != NULL && m_pBgm->isLoaded() )
		m_pBgm->setVolume( volume );

	// set data
	m_fVolumeBackgroundMusic = _fVolume;
}

float	
CSoundManager::getVolumeEffectSound()
{
	return m_fVolumeEffectSound;
}

void	
CSoundManager::setVolumeEffectSound( float _fVolume )
{
	long volume = (int)CSound::linearToLogVol( _fVolume );

	EnterCriticalSection( &m_criticalSection );
	for( unsigned int i=0 ; i<m_vecEffectSound.size() ; i++ )
	{
		m_vecEffectSound.at( i )->setVolume( volume );
	}
	LeaveCriticalSection( &m_criticalSection );

	// set data
	m_fVolumeEffectSound = _fVolume;
}

// pan	-1.0f ~ 1.0f
float	
CSoundManager::getPanBackgroundMusic()
{
	return m_fPanBackgroundMusic;
}

void	
CSoundManager::setPanBackgroundMusic( float _fPan )
{
	long pan = long( _fPan * 10000 );

	if( m_pBgm != NULL && m_pBgm->isLoaded() )
		m_pBgm->setPan( pan );

	// set data
	m_fPanBackgroundMusic = _fPan;
}

float	
CSoundManager::getPanEffectSound()
{
	return m_fPanEffectSound;
}

void	
CSoundManager::setPanEffectSound( float _fPan )
{
	long pan = long( _fPan * 10000 );

	EnterCriticalSection( &m_criticalSection );
	for( unsigned int i=0 ; i<m_vecEffectSound.size() ; i++ )
	{
		m_vecEffectSound.at( i )->setPan( pan );
	}

	LeaveCriticalSection( &m_criticalSection );

	// set data
	m_fPanEffectSound = _fPan;
}

// stop
void
CSoundManager::stopBackgroundMusic()
{
	if( m_pBgm && m_pBgm->isLoaded() )
		m_pBgm->stop();

}

void	
CSoundManager::stopEffectSound()
{
	EnterCriticalSection( &m_criticalSection );
	// BGM�� ��ϵ� ��� sound�� volume ����
	for( unsigned int i=0 ; i<m_vecEffectSound.size() ; i++ )
	{
		m_vecEffectSound.at( i )->stop();
	}
	LeaveCriticalSection( &m_criticalSection );
}

// mute
void
CSoundManager::muteBackgroundMusic()
{
	if( isMuteBackgroundMusic() )
	{
		m_bMuteBackgroundMusic = false;

		setVolumeBackgroundMusic( m_fVolumeBackgroundMusic );
		return;
	}

	m_bMuteBackgroundMusic = true;

	float	fVolume = m_fVolumeBackgroundMusic;
	// BGM�� ��ϵ� ��� sound�� volume ����
	setVolumeBackgroundMusic( 0.0f );
	m_fVolumeBackgroundMusic = fVolume;
}

void	
CSoundManager::muteEffectSound()
{
	if( isMuteEffectSound() )
	{
		m_bMuteEffectSound = false;

		setVolumeBackgroundMusic( m_fVolumeEffectSound );
		return;
	}

	m_bMuteEffectSound = true;

	float fVolume = m_fVolumeEffectSound;
	// BGM�� ��ϵ� ��� sound�� volume ����
	setVolumeEffectSound( 0.0f );
	m_fVolumeEffectSound = fVolume;
}

bool
CSoundManager::isMuteBackgroundMusic()
{
	return m_bMuteBackgroundMusic;
}

bool	
CSoundManager::isMuteEffectSound()
{
	return m_bMuteEffectSound;
}

void	
CSoundManager::setBgmGroup( unsigned int _nGroup )
{
	m_soundFileManager->setBgmGroup( _nGroup );	
}

void	
CSoundManager::deleteBgm()
{
	delete m_pBgm;
	m_pBgm = NULL;
}
}

