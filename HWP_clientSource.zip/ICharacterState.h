#ifndef __ICharacterState__h_
#define __ICharacterState__h_

class Packet;
class ICharacterState{
public:
	virtual void	stateStart() = 0;
	virtual void	stateEnd() = 0;
	virtual void	draw(DWORD _timeDelta) = 0;
	virtual ~ICharacterState(){};
};
#endif