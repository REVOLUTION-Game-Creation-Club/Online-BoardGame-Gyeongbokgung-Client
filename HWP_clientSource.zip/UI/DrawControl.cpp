#include "stdafx.h"
#include "DrawControl.h"
#include "UIContainer.h"

CDrawControl::CDrawControl(void)
{
}

CDrawControl::~CDrawControl(void)
{
	drawContainerList.clear();
}

void CDrawControl::insertList(CUIControl& _control)
{
	if( _control.kind.compare("container") == 0)
	{
		drawContainerList.push_back((CUIContainer*)&_control);
	}
}