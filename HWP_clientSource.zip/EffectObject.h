#ifndef __EffectObject__h_
#define __EffectObject__h_
#include "DrawObject.h"

class CEffectObject : public CDrawObject{

};

#endif