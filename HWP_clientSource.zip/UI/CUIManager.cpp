#include "stdafx.h"
#include "CUIManager.h"
#include "../UserManager.h"
#include "../DrawManager.h"
#include "../GameManager.h"
#include "UIDefine.h"

CUIManager* CUIManager::selfInstance = 0;

CUIManager& CUIManager::getInstance()
{
	if( selfInstance == 0 )
	{
		selfInstance = new CUIManager();		
	}

	return *selfInstance;
}

void CUIManager::release()
{
	if( selfInstance != 0 )
	{		
		delete selfInstance;
		selfInstance = 0;
	}
}

bool CUIManager::initialize()
{		
	return true;
}

void CUIManager::unregisterDrawObject()
{
	m_drawLayer.clear();
	m_containerList.clear();
	m_Layer.clear();
}

CUIManager::CUIManager(void)
{
	m_activeTextBox = NULL;
	m_mouseState = REV_MOUSE_RELEASE;

	m_facConrols = new Cfactory();
}

CUIManager::~CUIManager(void)
{
	delete m_facConrols;

	int i , size;
	size = m_Layer.size();

	for( i = 0 ; i < size ; ++i )
	{
		delete m_Layer[i];
		delete m_drawLayer[i];
	}
}

//{{ bakky : �޸� �����ڵ� �߰�
void CUIManager::destroyAllContainer()
{
	int i , size;
	size = m_Layer.size();

	for( i = 0 ; i < size ; ++i )
	{
		delete m_Layer[i];
		delete m_drawLayer[i];
	}

	m_Layer.clear();
	m_drawLayer.clear();
}
//}}

void CUIManager::on_update()
{
}


void CUIManager::onMouseMove(int _x, int _y )		//���콺�� �������� UI�� �ѱ涧
{
	int i = m_Layer.size();
	for( i = m_Layer.size() - 1 ; i >= 0 ; i-- )
	{
		if( m_Layer[i]->visible )
		{
			if( m_Layer[i]->x <= _x && 
				m_Layer[i]->x + m_Layer[i]->width >= _x &&
				m_Layer[i]->y <= _y && 
				m_Layer[i]->y + m_Layer[i]->height >= _y)
			{	
				m_Layer[i]->activeControl(_x, _y, REV_MOUSE_MOVE);

				if( m_mouseState == REV_MOUSE_DOWN )
				{
					m_Layer[i]->dragContainer(_x, _y);
				}

				return;	//������ �ִ� ��Ʈ�ѵ��� ���ÿ� ���� �Ǵ� ���� ����. �ϳ��� �����Ű�� ����.

			}
			else
			{
				m_Layer[i]->deactivate();
			}
						
		}
	}
}

void CUIManager::onMouseRelese(int _x, int _y )		//���콺 ��ư�� �ö��� ��
{
	m_mouseState = REV_MOUSE_RELEASE;	
}

void CUIManager::onMousePress(int _x, int _y )		//���콺�� ��ư�� �������� ��
{
	m_mouseState = REV_MOUSE_DOWN;
	int i = m_Layer.size();
	for( i = m_Layer.size() - 1 ; i >= 0 ; i-- )
	{
		if( m_Layer[i]->visible )
		{
			if( m_Layer[i]->x <= _x && m_Layer[i]->x + m_Layer[i]->width >= _x 
			&& m_Layer[i]->y <= _y && m_Layer[i]->y + m_Layer[i]->height >= _y)
			{
				m_Layer[i]->setMouseClickPos(_x, _y);
				m_activeControl = m_Layer[i]->activeControl(_x, _y, REV_MOUSE_DOWN);

				//����� �������� �κ�
				// �����̰� �̴ϸʶ����� �ּ�ó��
				//if( !m_Layer[i]->getFixed() )
				//	CUIManager::getInstance().makeTopLayer( m_Layer[i]->name );
								

				return;	//������ �ִ� ��Ʈ�ѵ��� ���ÿ� ���� �Ǵ� ���� ����. �ϳ��� �����Ű�� ����.				
			}
			else
			{
				m_Layer[i]->deactivate();
			}
		}
	}
}

void CUIManager::onKeyDown()
{
	if( m_activeTextBox != NULL )
	{
		m_activeTextBox->activeControl(REV_MOUSE_DOWN);
	}	
}

void CUIManager::on_Enter_KeyDown()
{
	if( m_activeTextBox != NULL )
	{
		m_activeTextBox->pressReturn();
	}
	else
	{		
		
	}	
}

void CUIManager::on_Space_KeyDown()
{

}

void CUIManager::on_Crtl_KeyDown()
{

}

void CUIManager::on_Alt_KeyDown()
{

}

void CUIManager::on_Shift_KeyDown()
{

}

void CUIManager::on_Char_KeyDown(char* _key)
{

}


void CUIManager::makeTopLayer(string _name)
{
	for( int i = 0; i < m_Layer.size() ; i++ )
	{
		if( m_Layer[i]->name.compare(_name) == 0 )
		{

			if(m_drawLayer[i]->getOrder() != 0 )
			{
				CDrawManager::getInstance()->makeInterfaceTopLayer(m_drawLayer[i]->getOrder());
			}

			m_Layer.push_back(m_Layer[i]);
			m_Layer.erase(m_Layer.begin() + i);
			m_drawLayer.push_back(m_drawLayer[i]);
			m_drawLayer.erase(m_drawLayer.begin() + i);	
	
			return;
		}
	}
}

void CUIManager::makeContainer(string _name)				//��Ʈ���� ������ ���� �����̳� ����
{
	CUIContainer* temp = new CUIContainer(_name);

	m_containerList[temp->name] = temp;
	m_Layer.push_back(temp);

	CUIDraw* uiDraw = new CUIDraw();
	uiDraw->insertList(*temp);
	m_drawLayer.push_back(uiDraw);
}

void CUIManager::makeContainer(string _name, int _x, int _y, int _width, int _height)	//�����̳ʸ� �����ϸ鼭 init
{
	CUIContainer* temp = new CUIContainer(_name);
	temp->setValue(_x, _y, _width, _height);

	m_containerList[temp->name] = temp;
	m_Layer.push_back(temp);

	CUIDraw* uiDraw = new CUIDraw();
	uiDraw->insertList(*temp);
	m_drawLayer.push_back(uiDraw);
}

void CUIManager::makeContainer(string _name, int _x, int _y, int _width, int _height, int _texX, int _texY, char* _fileName)	//�����̳ʸ� �����ϸ鼭 init
{
	CUIContainer* temp = new CUIContainer(_name);
	temp->setValue(_x, _y, _width, _height, _texX, _texY, _fileName);

	m_containerList[temp->name] = temp;
	m_Layer.push_back(temp);

	CUIDraw* uiDraw = new CUIDraw();
	uiDraw->insertList(*temp);
	m_drawLayer.push_back(uiDraw);
}

void CUIManager::setActiveTextbox(CTextBox* _control) 
{
	m_activeTextBox = _control; 
	getIME()->ClearBufstr(); 
}

//����� �������� �κ�
CUIDraw* CUIManager::getUIDraw(int _where)
{	
	return m_drawLayer[_where];
}

CUIContainer& CUIManager::operator[] (string _name)	//�����̳��� �Ӽ��� �����ϱ� ���� operator
{
	return *m_containerList[_name];
}

CUIContainer& CUIManager::operator [] (int _where)
{
	return *m_Layer[_where];
}
