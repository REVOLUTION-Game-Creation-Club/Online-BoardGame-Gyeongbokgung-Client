#ifndef __RoomState_h__
#define __RoomState_h__
#include "IGameState.h"
#include "MessageManager.h"
#include "ui/Clistener.h"

#include <vector>


#define	MAX_ROOM_USER	4

using namespace std;

class CGameManager;
class CPrintObject;

typedef struct _tagRoomUserInfo
{
	char	id[ USER_ID_LENGTH ];
	int		nPoint;
	bool	bReady;
	bool	bMe;
	bool	bMaster;
	int		character[ MAX_CHARACTER_SELECT_COUNT ];
	int		row;

	_tagRoomUserInfo() {
		nPoint	= 0;
		row		= 0;
		bReady	= false;
		bMe		= false;
		bMaster	= false;

		memset( id, 0, sizeof( char ) * USER_ID_LENGTH );
		memset( character, 0, sizeof( int ) * MAX_CHARACTER_SELECT_COUNT );
	}
}ROOMUSERINFO, * LPROOMUSERINFO;


typedef vector<LPROOMUSERINFO>	VectorRoomUserInfo;

enum CHAR_INDEX { NONE, BOY, GIRL, GIANT };
enum CHAR_SLOT { FIRST, SECOND };

class CRoomState : public IGameState, Clistener
{
private:
	CGameManager*				m_gameManager;
	
	// room information
	int			m_nRoomNumber;
	char		m_szRoomName[ROOM_ID_LENGTH];

	//VectorRoomUserInfo	m_vecRoomUserInfo;
	ROOMUSERINFO	m_roomUserInfo[ MAX_ROOM_USER ];

	LPROOMUSERINFO	m_pMyInfo;

	int		m_nSelectCharInfo;		// ĳ���� ����â�� ������ �ε��� ����
	int		m_nSelectColumn;

	bool	isCharSelectButtonPressed( char* szButtonName );

	// ĳ���� ��ȣ�� ������ ���� �ο���
	// 0:����, 1:����, 2:����, 3:����
	enum CHAR_SELECT_INDEX { NO, BOY, GIRL, GAINT };


	LPROOMUSERINFO	findRoomUserInfo( char* id );

	int numPlayer() {
		int count = 0;
		for( int i=0 ; i<MAX_ROOM_USER ; i++ )
			if( strlen( m_roomUserInfo[i].id ) )
				count++;

		return count;
	}

	BOOL hasSecond()	{ 
		return ( numPlayer() <= 2 );
	}

	CPrintObject*	m_printID[MAX_ROOM_USER];
	CPrintObject*	m_printRoomName;

	int	m_nCountConnectedClient;

	BOOL	m_bStarted;	// ������ ���۵Ǿ����� �ƴ� �÷���. �̰��� �̿��ؼ� �Է��� ���´�

public:
								CRoomState(CGameManager* _gameManager);
	virtual						~CRoomState();

	void	resetData();	// data �ʱ�ȭ
	bool	initialize();
	void	release();

	void	onUpdate();
	void	onKeyboard(WPARAM _wParam);
	void	processMouseMove();
	void	onMouseLClick(){}

	void	onButtonExit();
	void	onButtonReady();
	void	OnButtonChar1();
	void	OnButtonChar2();
	void	OnButtonChar3();
	void	OnButtonCharSelect( int row, int column );

	void	UpdateUI();

	void	addUser( char* id, int nUserPoint );
	void	removeUser( char* removeid, char* masterid );
	void	changeReady( char* id, bool bReady );
	void	changeChar( char* id, int char1, int char2 );

	void	setRoomInformation( int nRoomNumber, LPROOMUSERINFO pUserInfo, char* szRoomName );

	void	setupStartGame( CClientSocket* pClientSocket, char* masterIP );

	void	chat( char* id, char* msg );

	BOOL	connectedClient();

	void	disconnect();

	// action listener
	void	action();
	void	textChanged();
	void	pressReturn();

	int	getRoomNumber()	{ return m_nRoomNumber; }

	void makeUI();
	void processNetwork();
};

#endif