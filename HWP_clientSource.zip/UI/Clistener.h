#pragma once
#include <string>

using namespace std;

class Clistener
{	
private:
	string m_eventedControl;
	string m_changedControl;
public:
	Clistener(void);
	virtual ~Clistener(void);

	void setEvented(string _evented);
	void setChanged(string _changed);

	string getEvented();
	string getChanged();

	virtual void action() = 0;
	virtual void textChanged() = 0;
	virtual void pressReturn() = 0;
};

