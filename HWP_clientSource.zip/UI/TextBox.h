#pragma once
#include "Dialogbox.h"

class CTextBox : public CDialogbox
{
protected:
	CTextBox(void);	
public:
	CTextBox(string _name);
	CTextBox(string _name, int _x, int _y, int _width, int _height);
	CTextBox(string _name, int _x, int _y, int _width, int _height, int _texX, int _texY, char* _fileName);

	void changeString(string _sentence);
	void changeString(char* _sentence);
	char* getString();

	void addListener(Clistener *_listener);
	void activeControl(int _state);
	void pressReturn();
	void deactivate();

	~CTextBox(void);
};
