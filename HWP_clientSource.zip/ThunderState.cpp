#include "stdafx.h"
#include "ThunderState.h"
#include "UserManager.h"
#include "Map.h"
#include "GameManager.h"
#include "PlayState.h"
#include "Packet.h"
#include "MessageManager.h"

CThunderState::CThunderState(CCharacter* _character)
{
	this->m_character	= _character;
	m_count				= 0;
	m_pSwapChar = NULL;
}

CThunderState::~CThunderState()
{

}

void CThunderState::stateStart()
{
}

void CThunderState::stateEnd()
{
}

void CThunderState::draw(DWORD _timeDelta)
{
	UNREFERENCED_PARAMETER(_timeDelta);

	//CPlayState* playState = (CPlayState*)CGameManager::getInstance()->getState(GAME_STATE_PLAY);

	//if(m_count < SPRITE_NUM_DELAY*SPRITE_NUM_THUNDER)
	//{
	//	m_character->setSize(150,768);

	//	POINT position;
	//	position.x = m_character->getCenterPoint().x - 100 - playState->getMap()->getScreenPoint().x;
	//	position.y = m_character->getCenterPoint().y - 618 - playState->getMap()->getScreenPoint().y;
	//	m_character->setPosition(position);

	//	int num = m_count/SPRITE_NUM_DELAY%SPRITE_NUM_THUNDER;
	//	RECT rect;
	//	rect.left = 1148+(150*num);
	//	rect.right = rect.left+150;
	//	rect.top = 2048 - 768;
	//	rect.bottom = 2048;

	//	m_character->setTextureRect(rect);
	//	m_character->BitBlt();

	//	m_count++;
	//}
	//else
	//{
	//	CUserManager::getInstance()->swapCharacterPosition();
	//	m_character->setTurnOutFlag(true);
	//	m_character->setCharacterState(CHARACTER_STATE_REST);
	//	m_count = 0;
	//}
	if(m_count == 0)
	{
		POINT pt = m_character->getSize();
		m_sizeX = pt.x;
		m_sizeY = pt.y;

		m_rectOrig = m_character->getTextureRect();

		getSoundManager()->play("õ�չ���");
		m_count++;
		drawThunderCharacter();
	}
	else if(m_count < SPRITE_NUM_DELAY*SPRITE_NUM_THUNDER )
	{
		m_count++;
		drawThunderCharacter();
	}
	else if(m_count == SPRITE_NUM_DELAY*SPRITE_NUM_THUNDER )
	{
		drawThunderCharacter();
		// ���� �ִϸ��̼� �Ŀ� TURN_OUT �޼����� ������.
		if(m_character->isThunderFlag() == true)
		{
			m_character->setThunderFlag(false);
			//m_character->setTurnOutFlag(true);
			m_character->setCharacterState(CHARACTER_STATE_REST);
		}
		m_count = 0;

		m_character->setSize(m_sizeX, m_sizeY);

		m_character->setTextureRect(m_rectOrig);

		if( m_pSwapChar )
		{
			// �ڸ� �̵�....
			// Ÿ�� �ε���...
			// Ÿ�� ���̵�...
			// ������ �� �Ա�...

			int tempTileIndex;
			int tempTileID;
			POINT tempCenterPoint;
			POINT tempTargetPoint;

			tempTileIndex = m_character->getTileIndex();
			tempTileID = m_character->getTileId();
			tempCenterPoint = m_character->getCenterPoint();
			tempTargetPoint = m_character->getTargetPoint();

			m_character->setTileIndex( m_pSwapChar->getTileIndex() );
			m_character->setTileId( m_pSwapChar->getTileId() );
			m_character->setCenterPoint( m_pSwapChar->getCenterPoint() );
			m_character->setTargetPoint( m_pSwapChar->getTargetPoint() );

			m_pSwapChar->setTileIndex( tempTileIndex );
			m_pSwapChar->setTileId( tempTileID);
			m_pSwapChar->setCenterPoint( tempCenterPoint );
			m_pSwapChar->setTargetPoint( tempTargetPoint );
		}

		m_pSwapChar = NULL;
	}
}

void CThunderState::drawThunderCharacter()
{
	CPlayState* playState = (CPlayState*)CGameManager::getInstance()->getState(GAME_STATE_PLAY);

	m_character->setSize(150,768);

	POINT position;
	position.x = m_character->getCenterPoint().x - 75 - playState->getMap()->getScreenPoint().x;
	position.y = m_character->getCenterPoint().y - 693 - playState->getMap()->getScreenPoint().y;
	m_character->setPosition(position);

	int num = m_count/SPRITE_NUM_DELAY%SPRITE_NUM_THUNDER;

	RECT rect;
	rect.left = 1148+(150*num);
	rect.right = rect.left+150;
	rect.top = 2048 - 768;
	rect.bottom = 2048;
	m_character->setTextureRect(rect);
	m_character->BitBlt();
}

void CThunderState::setSwapChar( CCharacter* pSwapChar )
{
	m_pSwapChar = pSwapChar;
}