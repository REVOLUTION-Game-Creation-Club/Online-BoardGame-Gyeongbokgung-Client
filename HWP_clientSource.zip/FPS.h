#ifndef __FPS_h__
#define __FPS_h__

#include "PrintObject.h"
#include <stdio.h>

class CFPS: public CPrintObject{
private:
	DWORD				m_frameCount;
	float				m_timeElapsed;
	float				m_FPS;
public:
	CFPS()
	{
		m_frameCount		= 0;
		m_timeElapsed		= 0.0f;
		m_FPS				= 0.0f;
		setString("");
	}

	virtual ~CFPS(){}

	void draw(DWORD _timeDelta)
	{
		
		m_frameCount++;
		m_timeElapsed += (float)(_timeDelta/1000.0f);

		if(m_timeElapsed >= 0.5f)
		{
			char str[128];

			m_FPS = (float)m_frameCount / m_timeElapsed;

			sprintf_s(str, "%f", m_FPS);
			str[8] = '\0'; // mark end of string
			
			setString(str);

			m_timeElapsed = 0.0f;
			m_frameCount    = 0;
		}

		if(m_font != NULL)
			m_font->DrawText( NULL,m_string, -1, &m_rect, DT_NOCLIP, m_color);
	}
};

#endif