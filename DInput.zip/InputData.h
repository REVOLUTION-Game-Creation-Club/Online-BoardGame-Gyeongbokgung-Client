#ifndef __INPUT_DATA_H__
#define __INPUT_DATA_H__


#define DIRECTINPUT_VERSION	0x0800

#include <windows.h>
#include <dinput.h>

namespace rev
{
	

	//--------------------------------------------------------------------------------------//
	// version
	#define LPDIRECTINPUT			LPDIRECTINPUT8
	#define	LPDIRECTINPUTDEVICE		LPDIRECTINPUTDEVICE8
	//--------------------------------------------------------------------------------------//

	//--------------------------------------------------------------------------------------//
	// keyboard, mouse flags
	enum DINPUT_FLAGS { FLAG_EXCLUSIVE_FOREGROUND = DISCL_EXCLUSIVE | DISCL_FOREGROUND, 
						FLAG_NONEXCLUSIVE_BACKGROUND = DISCL_NONEXCLUSIVE | DISCL_BACKGROUND,
						FLAG_NONEXCLUSIVE_FOREGROUND = DISCL_NONEXCLUSIVE | DISCL_FOREGROUND 
					  };
	//--------------------------------------------------------------------------------------//

	//--------------------------------------------------------------------------------------//
	// read data mode
	enum READ_DATA_STYLE { READ_DATA_IMMEDIATE, READ_DATA_BUFFERED };
	//--------------------------------------------------------------------------------------//


	//--------------------------------------------------------------------------------------//
	// mouse point style
	enum MOUSE_POINT_STYLE { MOUSE_POINT_RELATIVE /*��� ��ǥ(�� frame point���� ��)*/, 
							 MOUSE_POINT_ABS /*���� ��ǥ*/};
	//--------------------------------------------------------------------------------------//


	//--------------------------------------------------------------------------------------//
	// Data Style
	// char _pBuffer[256];
	typedef void( *CallBackImmediateKeyboard)( char* _pBufffer );

	// _dwKey : key code, _dwState : up(0)/down(1)
	typedef void( *CallBackBufferedKeyboard	)( DWORD _dwKey, DWORD _dwState );

	// _x, _y, _z :
	// char _pBtn[8] : _pBtn[0] : l-btn, _pBtn[1] : r-btn etc. : sdk document ����
	typedef void( *CallBackImmediateMouse	)( long _x, long _y, long _z, char* _pBtn );

	// _dwIndex : DIMOFS_X, DIMOFS_Y, DIMOFS_BUTTON0(l-btn), DIMOFS_BUTTON1(r-btn)
	// _dwData : _dwIndex�� �ش��ϴ� ����Ÿ( ��� ��ǥ )
	//typedef void( *CallBackBufferedMouse	)( int _x, int _y, bool _bLBtnDown, bool _bRBtnDown );

	enum MOUSE_BUTTON { L_BUTTON, R_BUTTON };
	typedef void( *CallBackBufferedMouseMove)( int _x, int _y );
	typedef void( *CallBackBufferedMouseUpDown)( MOUSE_BUTTON _btn, int _x, int _y );
	//--------------------------------------------------------------------------------------//
};

#endif //__INPUT_DATA_H__