#ifndef __OPENNING_STATE_H__
#define __OPENNING_STATE_H__

#include "igamestate.h"
#include "MCIWnd.h"

class CGameManager;

class COpenningState : public IGameState
{
private :
	CGameManager*				m_gameManager;
	CMCIWnd	m_mciWnd;

public:
	COpenningState(CGameManager* _gameManager);
	~COpenningState(void);

	bool	initialize();
	void	release();

	void	onKeyboard(WPARAM _wParam);
	void	processMouseMove()	{}
	void	onUpdate()	{}

	void	onStop();
};

#endif //__OPENNING_STATE_H__