#include "stdafx.h"
#include "FightImage.h"

CFightImage::CFightImage() : CSpriteObject(0,0,1024,1024,"image/fightImage.bmp")
{
	m_isWin = false;
	m_kind1 = CHARACTER_KIND_NO;
	m_kind1 = CHARACTER_KIND_NO;
}

void CFightImage::setKind(CHARACTER_KIND _kind1,CHARACTER_KIND _kind2)
{
	m_kind1 = _kind1;
	m_kind2 = _kind2;
}
void CFightImage::draw(DWORD _timeDelta)
{
	if(m_visible == false)
		return;

	// vs 
	BitBlt(488, 382, 104,104, 0, 512);

	if(m_isWin)
	{
		// ĳ���� ����
		setPosition(200,300);
		setSize(255,157);
		setSpriteType(m_kind1);
		setSpriteNo(0);
		BitBlt();

		// ĳ���� ������
		setPosition(600,300);
		setSize(255,157);
		setSpriteType(m_kind2);
		setSpriteNo(1);
		BitBlt();

		// win
		BitBlt(327, 470, 73,40, 352, 471);
		// lose
		BitBlt(727, 470, 130,90, 425, 471);
	}
	else
	{
		// ĳ���� ����
		setPosition(200,300);
		setSize(255,157);
		setSpriteType(m_kind1);
		setSpriteNo(0);
		BitBlt();

		// ĳ���� ������
		setPosition(600,300);
		setSize(255,157);
		setSpriteType(m_kind2);
		setSpriteNo(1);
		BitBlt();

		// lose
		BitBlt(327, 470, 130,90, 425, 471);
		// win
		BitBlt(727, 470, 73,40, 352, 471);
	}
}
