#include "StdAfx.h"
#include "OggFileLoader.h"


namespace rev
{

COggFileLoader::COggFileLoader(void)
{
	initialize();
}

COggFileLoader::~COggFileLoader(void)
{
	close();
}



void	
COggFileLoader::initialize()
{
	m_pBufferPtr = 0;
	m_pBuffer = 0;
	m_nBufferSize = 0;
	m_nNumSamples = 0;
	m_pVorbisInfo = 0;
	memset(&m_WaveFormatEx, 0, sizeof(WAVEFORMATEX));
	memset(&m_VorbisFile, 0, sizeof(OggVorbis_File));
	m_bEOF = false;
	m_bOpen = false;

	m_file = NULL;

	//m_pStreamSrc = 0;
}

bool	
COggFileLoader::close()
{
	if( !m_bOpen )
		return false;

	fclose( m_file );

	// close out the vorbis file bitstream
	ov_clear( &m_VorbisFile );

	initialize();

	return true;
}

bool	
COggFileLoader::open( TCHAR* szFileName )
{
	if( m_bOpen )
	{
		debug( "�̹� ������ �ִ�\n" );
		return false;
	}

	m_strName = szFileName;

	//fopen_s( &m_file, szFileName, "rb" );
	//m_file = fopen( szFileName, "rb" );

	errno_t err;

#ifndef _UNICODE
	err = fopen_s( &m_file, szFileName, "rb" );
#else
	err = _wfopen_s( &m_file, szFileName, TEXT("rb") );
#endif

	if( err )
	{
		debug( "ogg file open failed\n" );
		return false;
	}

	//fseek(m_file, 0, SEEK_SET);
	//TCHAR buf[32];
	//fread( buf, 30, 1, m_file );

	int resultOpen = ov_open( m_file, &m_VorbisFile, NULL, 0 );
	if( resultOpen < 0 )
	{
		debug( "ogg file open failed(ov_open)\n" );
		fclose( m_file );
		return false;
	}
	
	if( !GetStreamInfo() )
	{
		debug( "ogg file open failed(GetStreamInfo)\n" );
		fclose( m_file );
		return false;
	}

	m_bOpen = true;

	return true;
}

bool 
COggFileLoader::GetStreamInfo()
{
	// Get vorbis file information
	m_pVorbisInfo = ov_info(&m_VorbisFile,-1);

	// Get the number of PCM samples in this file
	m_nNumSamples = (long)ov_pcm_total(&m_VorbisFile,-1);

	// Display other info

	// set up the WaveFormatEx structure
	m_WaveFormatEx.wFormatTag = WAVE_FORMAT_PCM;
	m_WaveFormatEx.nChannels = m_pVorbisInfo->channels;
	m_WaveFormatEx.nSamplesPerSec = m_pVorbisInfo->rate;
	m_WaveFormatEx.wBitsPerSample = 16;
	m_WaveFormatEx.nBlockAlign = m_WaveFormatEx.nChannels * m_WaveFormatEx.wBitsPerSample / 8;
	m_WaveFormatEx.nAvgBytesPerSec = m_WaveFormatEx.nSamplesPerSec * m_WaveFormatEx.nBlockAlign;
	m_WaveFormatEx.cbSize = 0;

	return true;
}

bool	
COggFileLoader::read( BYTE*	pDestBuffer, DWORD dwSizeToRead, DWORD* pdwSizeRead )
{
	if(!m_bOpen)
		return false;

	char* pCurBuffer = (char*)pDestBuffer;
	DWORD nBytesRead = 0;
	int iSection = 0;
	while((nBytesRead < dwSizeToRead) && !m_bEOF)
	{
		DWORD iRet = ov_read(&m_VorbisFile, pCurBuffer, dwSizeToRead - nBytesRead, 0, 2, 1, &iSection);
		if (iRet == 0 || iSection != 0) 
		{
			m_bEOF = true;
		} 
		else if (iRet < 0) 
		{
			return false;
		}
		nBytesRead += iRet;
		pCurBuffer += iRet;
	}

	*pdwSizeRead = nBytesRead;

	return true;
}

DWORD	
COggFileLoader::getSize()
{
	return m_nNumSamples * m_WaveFormatEx.nChannels * m_WaveFormatEx.wBitsPerSample / 8;
}

bool	
COggFileLoader::reset()
{
	if(!m_bOpen)
		return false;

	// Seek to beginning of file to begin reading it again
	m_bEOF = false;
	ov_pcm_seek(&m_VorbisFile, 0);

	return true;
}

WAVEFORMATEX* 
COggFileLoader::getFormat()
{
	return &m_WaveFormatEx;
}

bool	
COggFileLoader::isEof()
{
	return m_bEOF;
}

void	
COggFileLoader::destroy()
{
	close();
}
//
//// Memory callback function declarations
//size_t 
//COggFileLoader::readFuncMem(void* ptr, size_t size, size_t nmemb, void* datasource)
//{
//	return 0;
//
//}
//
//int    
//COggFileLoader::seekFuncMem(void* datasource, ogg_int64_t offset, int whence)
//{
//	return 0;
//
//}
//
//int    
//COggFileLoader::closeFuncMem(void* datasource)
//{
//
//	return 0;
//}
//
//long   
//COggFileLoader::tellFuncMem(void* datasource)
//{
//	return 0;
//
//}
//
//// Stream callback function declarations
//size_t 
//COggFileLoader::readFuncFile(void* ptr, size_t size, size_t nmemb, void* datasource)
//{
//
//	return 0;
//}
//
//int    
//COggFileLoader::seekFuncFile(void* datasource, ogg_int64_t offset, int whence)
//{
//	return 0;
//
//}
//
//int    
//COggFileLoader::closeFuncFile(void* datasource)
//{
//	return 0;
//
//}
//
//long   
//COggFileLoader::tellFuncFile(void* datasource)
//{
//
//	return 0;
//}

} // namespace rev