#ifndef __Item__h_
#define __Item__h_

enum ITEM_KIND{ ITEM_NO = 0, ITEM_JINSENG = 1, ITEM_MAGNETIC = 2, ITEM_THUNDER = 3, ITEM_WATERBALL = 4, 
				 ITEM_FROG = 5,ITEM_INLINE = 6, ITEM_RANDOM = 7};

#endif