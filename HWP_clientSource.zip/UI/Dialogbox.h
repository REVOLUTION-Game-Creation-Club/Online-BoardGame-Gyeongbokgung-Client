#include "stdafx.h"
#include "CUIDialogbox.h"
#include "../PrintObject.h"
#include <vector>

class CDialogbox : public CUIDialogbox , public CPrintObject
{
protected:
	vector<CPrintObject*> m_printList;
	CDialogbox(void);

	int m_fontSize;

	IDirect3DDevice9* m_device;
public:
	CDialogbox(string _name);
	CDialogbox(string _name, int _x, int _y, int _width, int _height);
	CDialogbox(string _name, int _x, int _y, int _width, int _height, int _texX, int _texY, char* _fileName);	

	void insertString(string _sentence);
	void insertString(char* _sentence);
	void eraseString(int _which);
	void refreshString(int _where, string _sentence);
	void refreshString(int _where, char* _sentence);

	void setMaxString(int _max);

	void setFontPosition(int _x, int _y);
	void setFontColor(float _r, float _g, float _b, float _a);
	void setFontSize(int _size);

	void writeString();	

	bool initialize(IDirect3DDevice9* const _device);	
	void release();

	virtual ~CDialogbox(void);
};
