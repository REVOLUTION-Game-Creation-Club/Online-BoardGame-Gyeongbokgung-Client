#ifndef __SOUND_H__
#define __SOUND_H__

#include <string>

#ifdef _UNICODE
typedef std::wstring	tstring;
#else
typedef std::string		tstring;
#endif

using namespace std;

namespace rev
{

class CSoundFileLoader;

class CSound
{
public:
	CSound()	{}
	CSound( TCHAR* _szFileName );
	virtual ~CSound(void);

	virtual bool	initialize();
	virtual bool	destroy();

	virtual bool	isStream() const	{ return false; }
	virtual bool	isPlaying() const	{ return false; }

	bool	isLoop()		{ return m_bLoop;	}
	virtual bool	play( bool _bLoop = false )	= 0;
	virtual bool	stop();
	virtual bool	pause();
	virtual bool	resume();

	virtual bool	setVolume( long _volume );
	virtual bool	setPan( long _pan );

	virtual void	load( CSoundFileLoader* pSoundFileLoader );

	bool			isLoaded()	{	return m_lpSoundBuffer ? true : false;	}


	// ���� ���ۿ� ���� �����͸� ���� �ִ´�.
	//{{ thread ���� �ֱ������� ȣ���� �Ѵ�.
	//{{ ������ ���� ����, stream ������ update
	virtual bool	update() = 0;
	//}}

	tstring&	getName()	{	return m_strFileName;	}

	//{{ static method
	static void		setDirectSound( LPDIRECTSOUND8 lpDirectSound )	{	m_lpDirectSound = lpDirectSound;	}
	static int		linearToLogVol( float _level );
	static float	logToLinearVol( int _level );
	//}}

protected :
	static LPDIRECTSOUND8	m_lpDirectSound;
	

	tstring					m_strFileName;		// file path

	LPDIRECTSOUNDBUFFER8	m_lpSoundBuffer;	// ���� ����
	DSBCAPS					m_caps;

	WAVEFORMATEX			m_waveFormat;		// wave file information

	bool	createSoundBuffer( DWORD dwBufferSize );
	bool	loadSoundDataToSoundBuffer( CSoundFileLoader* pSoundFileLoader );

	BYTE	getSilenceData();

	bool	m_bLoop;
};

#include <math.h>

inline int 
CSound::linearToLogVol( float _level )
{
	const float MIN_VAL	= 0.0f;
	const float MAX_VAL	= 1.0f;

	if( _level <= MIN_VAL )
		return DSBVOLUME_MIN;
	else if( _level >= MAX_VAL )
		return 0;

	return (int)( -2000.0f * log10( 1.0f / _level ) );
}

inline float 
CSound::logToLinearVol( int _level )
{
	// Clamp the value
	if(_level <= -9600)
		return 0.0f;
	else if(_level >= 0)
		return 1.0f;

	return pow(10, float(_level + 2000) / 2000.0f) / 10.0f;
}

}
#endif //__SOUND_H__