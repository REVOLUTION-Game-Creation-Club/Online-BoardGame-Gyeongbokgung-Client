#pragma once

#include "SoundFileLoader.h"

namespace rev
{

class CWaveFileLoader : public CSoundFileLoader
{
public:
	CWaveFileLoader(void);
	CWaveFileLoader( TCHAR* szFileName );

	virtual ~CWaveFileLoader(void);

public :
	void	initialize();
	bool	close();

	bool	open( TCHAR* szFileName );
	bool	open( BYTE* pData, DWORD dwDataSize );
	bool	read( BYTE*	pDestBuffer, DWORD dwSizeToRead, DWORD* pdwSizeRead );
	DWORD	getSize();
	bool	reset();
	WAVEFORMATEX* getFormat();
	bool	isEof();
	void	destroy();

protected :

	bool	openMMIO();
	bool	readMMIO();

	WAVEFORMATEX	m_destFormat;
	HMMIO			m_hmmio;
	MMCKINFO		m_ck;
	MMCKINFO		m_ckRiff;
	DWORD			m_dwSize;
	bool			m_bEof;


	WAVEFORMATEX*	m_pwfx;
};

inline DWORD	
CWaveFileLoader::getSize()
{
	return m_dwSize;
}

inline WAVEFORMATEX* 
CWaveFileLoader::getFormat()
{
	return &m_destFormat;
}

inline bool	
CWaveFileLoader::isEof()
{
	return m_bEof;
}


}