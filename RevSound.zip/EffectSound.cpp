#include "stdafx.h"

#include "EffectSound.h"
#include "SoundManager.h"
#include "SoundFileLoader.h"

namespace rev
{

CEffectSound::CEffectSound( TCHAR* _szFileName ) 
: CSound( _szFileName )
{

}

CEffectSound::~CEffectSound()
{
	destroy();
}

bool	
CEffectSound::initialize()
{
	CSound::initialize();

	return true;
}

bool	
CEffectSound::destroy()
{
	size_t size = m_vecDuplicatedSoundBuffer.size();

	for( unsigned int i=0 ; i<m_vecDuplicatedSoundBuffer.size() ; i++ )
	{
		LPDIRECTSOUNDBUFFER8 pSoundBuffer = m_vecDuplicatedSoundBuffer.at( i );
		m_vecDuplicatedSoundBuffer.at( i )->Release();
	}
	m_vecDuplicatedSoundBuffer.clear();

	CSound::destroy();

	return true;
}

bool
CEffectSound::play( bool _bLoop )
{
	m_bLoop = _bLoop;
	LPDIRECTSOUNDBUFFER8 lpSound;
	HRESULT hr = m_lpDirectSound->DuplicateSoundBuffer( (LPDIRECTSOUNDBUFFER)m_lpSoundBuffer, (LPDIRECTSOUNDBUFFER*)&lpSound );
	if( FAILED( hr ) )
	{
		debugDXError( hr );
		return false;
	}

	lpSound->Play( 0, 0, _bLoop ?  DSBPLAY_LOOPING : 0 );

	m_vecDuplicatedSoundBuffer.push_back( lpSound );		

	return true;
}

void	
CEffectSound::removeStopSound()
{
	DWORD	dwStatus;

	size_t size = m_vecDuplicatedSoundBuffer.size();

	for( unsigned int i=0 ; i<m_vecDuplicatedSoundBuffer.size() ; i++ )
	{
		LPDIRECTSOUNDBUFFER8 pSoundBuffer = m_vecDuplicatedSoundBuffer.at( i );
		m_vecDuplicatedSoundBuffer.at( i )->GetStatus( &dwStatus );
	
		if( !(dwStatus & DSBSTATUS_PLAYING) )
		{
			m_vecDuplicatedSoundBuffer.at( i )->Release();
			m_vecDuplicatedSoundBuffer.erase( m_vecDuplicatedSoundBuffer.begin() + i );
		}
	}

	//TCHAR buf[64]={0};
	//wsprintf( buf, "%s ���� ���� ����: %d\n", this->getName().c_str(), m_vecDuplicatedSoundBuffer.size() );
	//debug( buf );
}

void	
CEffectSound::load( CSoundFileLoader* pSoundFileLoader )
{
	if( !pSoundFileLoader )
		return;

	CSound::load( pSoundFileLoader );

	createSoundBuffer( pSoundFileLoader->getSize() );
	loadSoundDataToSoundBuffer( pSoundFileLoader );
}

bool	
CEffectSound::stop()
{
	size_t size = m_vecDuplicatedSoundBuffer.size();

	for( unsigned int i=0 ; i<m_vecDuplicatedSoundBuffer.size() ; i++ )
	{
		LPDIRECTSOUNDBUFFER8 pSoundBuffer = m_vecDuplicatedSoundBuffer.at( i );
		if( m_vecDuplicatedSoundBuffer.at( i ) )
		{
			m_vecDuplicatedSoundBuffer.at( i )->Stop();
			m_vecDuplicatedSoundBuffer.at( i )->SetCurrentPosition( 0 );
		}
	}

	return true;
}

bool	
CEffectSound::pause()
{

	return true;
}

bool	
CEffectSound::resume()
{

	return true;
}

bool
CEffectSound::setVolume( long _volume )
{
	size_t size = m_vecDuplicatedSoundBuffer.size();

	for( unsigned int i=0 ; i<m_vecDuplicatedSoundBuffer.size() ; i++ )
	{
		LPDIRECTSOUNDBUFFER8 pSoundBuffer = m_vecDuplicatedSoundBuffer.at( i );
		m_vecDuplicatedSoundBuffer.at( i )->SetVolume( _volume );
	}

	return true;
}

bool	
CEffectSound::setPan( long _pan )
{
	size_t size = m_vecDuplicatedSoundBuffer.size();

	for( unsigned int i=0 ; i<m_vecDuplicatedSoundBuffer.size() ; i++ )
	{
		LPDIRECTSOUNDBUFFER8 pSoundBuffer = m_vecDuplicatedSoundBuffer.at( i );
		m_vecDuplicatedSoundBuffer.at( i )->SetPan( _pan );
	}

	return true;
}

}