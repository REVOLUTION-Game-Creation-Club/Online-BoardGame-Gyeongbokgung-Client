#ifndef __INPUT_MOUSE_H__
#define __INPUT_MOUSE_H__

#include "InputData.h"

namespace rev {

	typedef struct _MousePoint 	{
		int x, y;

		_MousePoint() {
			x = y = 0;
		}
	}MOUSEPOINT;

	class CInputMouse
	{
	private :
		LPDIRECTINPUT			m_lpDI;
		LPDIRECTINPUTDEVICE		m_lpDevice;

		CallBackImmediateMouse		m_pfImmediate;
		CallBackBufferedMouseMove	m_pfBuffered;
		CallBackBufferedMouseUpDown	m_pfBufferedDown;
		CallBackBufferedMouseUpDown	m_pfBufferedUp;

		HWND	m_hWnd;

	protected :
		int					m_nReadDataMode;	// 0 - immediate, 1 - buffered
		MOUSE_POINT_STYLE	m_mousePointStyle;

		MOUSEPOINT				m_MousePoint;
		DWORD					m_dwBufferSize;
		LPDIDEVICEOBJECTDATA	m_pDeviceObjectData;

		bool createDirectInputDevice();
		bool setDataFormat();
		bool setBehavior( HWND _hWnd, DWORD _dwFlags );

		void readImmediateData();
		void readBufferedData();

	public :
		CInputMouse();
		virtual ~CInputMouse();

		bool initialize( LPDIRECTINPUT _lpDI, HWND _hWnd );
		void setImmediateFunc( CallBackImmediateMouse _pfImmediate )	{ m_pfImmediate = _pfImmediate;	}
		//void setBufferedFunc( CallBackBufferedMouse _pfBuffered )		{ m_pfBuffered	= _pfBuffered;	}

		void setCallBackBufferedMouseMove( CallBackBufferedMouseMove _pf)		{	m_pfBuffered =  _pf ;	}
		void setCallBackBufferedMouseDown( CallBackBufferedMouseUpDown  _pf )	{	m_pfBufferedDown =  _pf;}
		void setCallBackBufferedMouseUp( CallBackBufferedMouseUpDown  _pf )		{	m_pfBufferedUp =  _pf ; }

		bool create( HWND _hWnd, int _nBufferSize, DWORD _dwFlags, DWORD _dwMode );
		bool destroy();
		void process();
		void active( bool bActive );

		//
		void setMousePoint( int _x, int _y );
		void getMousePoint( int& _x, int& _y );

		// 
		void setPointStyle( MOUSE_POINT_STYLE _style );
		MOUSE_POINT_STYLE getPointStyle() const;
	};


	//
	inline void CInputMouse::setMousePoint( int _x, int _y )
	{
		m_MousePoint.x = _x;
		m_MousePoint.y = _y;
	}

	inline void CInputMouse::getMousePoint( int& _x, int& _y )
	{
		_x = m_MousePoint.x;
		_y = m_MousePoint.y;
	}

	// 
	inline void CInputMouse::setPointStyle( MOUSE_POINT_STYLE _style )
	{
		m_mousePointStyle = _style;
	}

	inline MOUSE_POINT_STYLE CInputMouse::getPointStyle() const
	{
		return m_mousePointStyle;
	}
};
#endif	//__INPUT_MOUSE_H__
