#include "stdafx.h"
#include "DrawManager.h"
#include "UI/CUIManager.h"
#include "MessageManager.h"
#include "MainFrame.h"
#include "../resource.h"
#include "PlayState.h"
#include "GameManager.h"

using namespace MainFrame;

CDrawManager* CDrawManager::selfInstance = 0;

CDrawManager::CDrawManager()
{
	m_stateFlag = false;
	m_pMouse = NULL;
	m_pCastle = NULL;
}

CDrawManager::~CDrawManager()
{
	if( m_pMouse )
	{
		m_pMouse->release();
		delete m_pMouse;
		m_pMouse = NULL;
	}

	if( m_pCastle )
	{
		m_pCastle->release();
		delete m_pCastle;
		m_pCastle = NULL;
	}
}

CDrawManager* CDrawManager::getInstance()
{
	if( selfInstance == 0 )
		selfInstance = new CDrawManager();

	return selfInstance;
}

void CDrawManager::release()
{
	if( selfInstance != NULL )
	{
		for( int i = 0 ;i < (int)m_mapList.size() ; i++ )
			m_mapList[i]->release();
		for( int i = 0 ;i < (int)m_characterList.size() ; i++ )
			m_characterList[i]->release();
		for( int i = 0 ;i < (int)m_interfaceList.size() ; i++ )
			m_interfaceList[i]->release();

		m_device->Release();

		delete selfInstance;
		selfInstance = NULL;
	}
}
bool CDrawManager::createD3DWindow(HINSTANCE _hInstance)
{
#ifdef _DEBUG
	InitD3D(_hInstance, WINDOW_WIDTH, WINDOW_HEIGHT, true, D3DDEVTYPE_HAL, &m_device);
#else
	InitD3D(_hInstance, WINDOW_WIDTH, WINDOW_HEIGHT, false, D3DDEVTYPE_HAL, &m_device);
#endif
	return true;
}

void CDrawManager::initialize()
{
	
}

bool CDrawManager::InitD3D( HINSTANCE hInstance, int width, int height, bool windowed, D3DDEVTYPE deviceType, 
						   IDirect3DDevice9** device)
{
	WNDCLASS wc;

	wc.style         = CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc   = (WNDPROC)MainFrame::WndProc;
	wc.cbClsExtra    = 0;
	wc.cbWndExtra    = 0;
	wc.hInstance     = hInstance;
	//wc.hIcon         = LoadIcon(0, IDI_APPLICATION);
	wc.hIcon		= (HICON)LoadImage( hInstance, MAKEINTRESOURCE(IDI_ICON), IMAGE_ICON, 0, 0, LR_LOADFROMFILE );
	wc.hCursor       = LoadCursor(0, IDC_ARROW);
	wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
	wc.lpszMenuName  = 0;
	wc.lpszClassName = "�ؿ��";

	if( !RegisterClass(&wc) ) 
	{
		::MessageBox(0, "RegisterClass() - FAILED", 0, 0);
		return false;
	}

	m_hwnd = ::CreateWindow("�ؿ��", "�ؿ��", WS_POPUP , 0, 0, width, height, 0, 0, hInstance, 0); 

	if( !m_hwnd )
	{
		::MessageBox(0, "CreateWindow() - FAILED", 0, 0);
		return false;
	}

	::ShowWindow(m_hwnd, SW_SHOW);
	::UpdateWindow(m_hwnd);

	// Init D3D: 
	HRESULT hr = 0;

	// Step 1: Create the IDirect3D9 object.
	IDirect3D9* d3d9 = 0;
	d3d9 = Direct3DCreate9(D3D_SDK_VERSION);

	if( !d3d9 )
	{
		::MessageBox(0, "Direct3DCreate9() - FAILED", 0, 0);
		return false;
	}

	// Step 2: Check for hardware vp.
	D3DCAPS9 caps;
	d3d9->GetDeviceCaps(D3DADAPTER_DEFAULT, deviceType, &caps);

	int vp = 0;
	if( caps.DevCaps & D3DDEVCAPS_HWTRANSFORMANDLIGHT )
		vp = D3DCREATE_HARDWARE_VERTEXPROCESSING;
	else
		vp = D3DCREATE_SOFTWARE_VERTEXPROCESSING;

	// Step 3: Fill out the D3DPRESENT_PARAMETERS structure.
	D3DPRESENT_PARAMETERS d3dpp;
	d3dpp.BackBufferWidth            = width;
	d3dpp.BackBufferHeight           = height;
	d3dpp.BackBufferFormat           = D3DFMT_A8R8G8B8;
	d3dpp.BackBufferCount            = 1;
	d3dpp.MultiSampleType            = D3DMULTISAMPLE_NONE;
	d3dpp.MultiSampleQuality         = 0;
	d3dpp.SwapEffect                 = D3DSWAPEFFECT_FLIP;
	d3dpp.hDeviceWindow              = m_hwnd;
	d3dpp.Windowed                   = windowed;
	d3dpp.EnableAutoDepthStencil     = false; 
	d3dpp.AutoDepthStencilFormat     = D3DFMT_D24S8;
	d3dpp.Flags                      = 0;
	d3dpp.FullScreen_RefreshRateInHz = D3DPRESENT_RATE_DEFAULT;
//	d3dpp.PresentationInterval       = D3DPRESENT_INTERVAL_IMMEDIATE;
	d3dpp.PresentationInterval       = D3DPRESENT_INTERVAL_DEFAULT;
	// Step 4: Create the device.
	hr = d3d9->CreateDevice( D3DADAPTER_DEFAULT, deviceType, m_hwnd, vp, &d3dpp, device);

	if( FAILED(hr) )
	{
		// try again using a 16-bit depth buffer
		d3dpp.AutoDepthStencilFormat = D3DFMT_D16;

		hr = d3d9->CreateDevice(D3DADAPTER_DEFAULT, deviceType, m_hwnd, vp, &d3dpp, device);

		if( FAILED(hr) )
		{
			d3d9->Release(); // done with d3d9 object
			::MessageBox(0, "CreateDevice() - FAILED", 0, 0);
			return false;
		}
	}

	d3d9->Release(); // done with d3d9 object

	return true;
}
bool CDrawManager::display(DWORD _timeDelta)
{
	if(m_stateFlag == true)
		return true;
	CGameManager::getInstance()->onUpdate();

	if( m_device != NULL)
	{
		//{{ bakky
		// z-buffer�� ���� �־ Clear()����..�׷��� �ּ� ó��
		m_device->Clear(0, 0, D3DCLEAR_TARGET/* | D3DCLEAR_ZBUFFER*/, 0xffffffff, 1.0f, 0);
		m_device->BeginScene();
		draw(_timeDelta);
		m_device->EndScene();
		m_device->Present(0, 0, 0, 0);
	}

	return true;
}

bool CDrawManager::draw(DWORD _timeDelta)
{
	
	for( int i = 0; i < (int)m_mapList.size() ; i++ )
		m_mapList[i]->draw(_timeDelta);
	
	for( int i = 0; i < (int)m_characterList.size() ; i++ )
		m_characterList[i]->draw(_timeDelta);

	if( m_pCastle )
	{
		CMap* pMap = ((CPlayState*)CGameManager::getInstance()->getState( GAME_STATE_PLAY ))->getMap();
		POINT ptScreen = pMap->getScreenPoint();

		int x = 604 - ptScreen.x;
		int y = 423 - ptScreen.y;
		
		m_pCastle->setTextureRect( 0, 0 );
		m_pCastle->setPosition( x, y );

		m_pCastle->draw( _timeDelta );
	}

	for( int i = 0; i < (int)m_interfaceList.size() ; i++ )
		m_interfaceList[i]->draw(_timeDelta);

	//{{ bakky
	if( CGameManager::getInstance()->getGameState() != GAME_STATE_LOADING )
		m_pMouse->draw(_timeDelta);
	//}}

	return true;
}

int CDrawManager::insertObject(DRAW_OBJECT_TYPE _type, IDrawObject* _obj)
{
	_obj->initialize(m_device);

	switch(_type)
	{
	case DRAW_OBJECT_MAP:
		m_mapList.push_back(_obj);
		((CDrawObject*)_obj)->setOrder(m_mapList.size() -1 );
		return m_mapList.size() - 1;	//������Ʈ�� �߰��� ��ġ�� �˷��ݴϴ�.
	case DRAW_OBJECT_CHARACTER:
		m_characterList.push_back(_obj);
		((CDrawObject*)_obj)->setOrder(m_characterList.size() -1 );
		return m_characterList.size() - 1;	//������Ʈ�� �߰��� ��ġ�� �˷��ݴϴ�.
	case DRAW_OBJECT_INTERFACE:
		m_interfaceList.push_back(_obj);
		((CDrawObject*)_obj)->setOrder(m_interfaceList.size() -1 );
		return m_interfaceList.size() - 1;	//������Ʈ�� �߰��� ��ġ�� �˷��ݴϴ�.
	}

	return 0;
}

void CDrawManager::eraseObject(DRAW_OBJECT_TYPE _type, int _where)
{
	switch(_type)
	{
	case DRAW_OBJECT_MAP:
		m_mapList[_where]->release();
		//m_mapList.erase(m_mapList.begin() + _where);
		return;
	case DRAW_OBJECT_CHARACTER:
		m_characterList[_where]->release();
		//m_characterList.erase(m_characterList.begin() + _where);
		return;
	case DRAW_OBJECT_INTERFACE:
		m_interfaceList[_where]->release();
		//m_interfaceList.erase(m_interfaceList.begin() + _where);
		return;
	}
}
void CDrawManager::eraseList()
{
	m_mapList.clear();
	m_characterList.clear();
	m_interfaceList.clear();
}

//IDrawObject* CDrawManager::operator[] (int _where)
//{
//	return m_objList[_where];
//}
void CDrawManager::makeCharacterTopLayer(int _where)
{
	int listSize = m_characterList.size();

	if( _where < listSize || _where > -1)
	{
		m_characterList.push_back(m_characterList[_where]);
		m_characterList.erase(m_characterList.begin() + _where);

		for( int i = 0; i < listSize ; i++ )
		{
			((IDrawObject*)m_characterList[i])->setOrder(i);
		}

		return;		
	}
}

void CDrawManager::makeInterfaceTopLayer(int _where)
{
	int listSize = m_interfaceList.size();

	if( _where < listSize || _where > -1)
	{
		m_interfaceList.push_back(m_interfaceList[_where]);
		m_interfaceList.erase(m_interfaceList.begin() + _where);

		for( int i = 0; i < listSize ; i++ )
		{
			((IDrawObject*)m_interfaceList[i])->setOrder(i);
		}
		
		return;		
	}
}

void CDrawManager::createMouse()
{
	m_pMouse = new CDrawObject( 0, 0, 32, 32, "image\\cursor.png" );
	m_pMouse->initialize( this->m_device );
}

void CDrawManager::setMousePoint( int x, int y )
{
	m_pMouse->setPosition( x, y );
}


void	CDrawManager::createCastle()
{
	m_pCastle = new CDrawObject(0, 0, 512, 512, "image\\castle.bmp" );
	m_pCastle->initialize( this->m_device);
}

void	CDrawManager::releaseCastle()
{
	if( m_pCastle )
	{
		m_pCastle->release();
		delete m_pCastle;
		m_pCastle = NULL;
	}
}