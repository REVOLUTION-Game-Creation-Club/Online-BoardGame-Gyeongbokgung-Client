#include "stdafx.h"
#include "Cfactory.h"

Cfactory::Cfactory(void)
{
}

Cfactory::~Cfactory(void)
{
}

CUIControl* Cfactory::createControl(string _type, string _name)
{
	if( _type.compare("button") == 0)
	{
		return new CUIButton(_name);
	}
	if( _type.compare("dialogbox") == 0)
	{
		return new CDialogbox(_name);
	}
	if( _type.compare("textbox") == 0)
	{
		return new CTextBox(_name);
	}
	if( _type.compare("imagebox") == 0 )
	{
		return new CUIImageBox(_name);
	}

	return NULL;
}

CUIControl* Cfactory::createControl(string _type, string _name, int _x, int _y, int _width, int _height)
{
	CUIControl* temp = NULL;

	if( _type.compare("button") == 0)
	{
		temp = new CUIButton(_name, _x, _y, _width, _height);
	}
	if( _type.compare("dialogbox") == 0)
	{
		temp = new CDialogbox(_name, _x, _y, _width, _height);
	}
	if( _type.compare("textbox") == 0)
	{
		temp = new CTextBox(_name, _x, _y, _width, _height);
	}
	if( _type.compare("imagebox") == 0 )
	{
		temp = new CUIImageBox(_name, _x, _y, _width, _height);
	}

	
	return temp;
}