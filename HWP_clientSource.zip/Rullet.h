
#ifndef __Rullet_h_
#define __Rullet_h_

#include <math.h>
#include "SpriteObject.h"
#include "PrintObject.h"
#include "timer.h"
#include "../RevSound/SoundManager.h"

class CRullet: public CSpriteObject
{
private:
	int				m_selectedNumber;												// ���õ� ��ȣ
	int	 			m_computeNumber;												// ���� ��
	bool			m_timeStart;													// ���� �����ΰ�?
	bool			m_rulletStart;
	DWORD			m_elapsedTime;
public:
	CRullet(int _x, int _y);
	virtual ~CRullet();

	int		getComputeNumber(){ return m_computeNumber;}
	void	setComputeNumber(int _num){ m_computeNumber = _num; }
	
	int		getSelectedNumber(){ return	m_selectedNumber;	}						// ���õ� ��ȣ�� ��´�.
	void	setSelectedNumber(int _num){ m_selectedNumber = _num; }
	bool	isBingo(){return m_computeNumber == m_selectedNumber ? true : false;}

	void    draw(DWORD _timeDelta);

	void	rulletStart();
	bool	rulletStop(int _num);
	void	setRulletStart(bool _rulletStart){m_rulletStart = _rulletStart;}

	void	timeStart();
	void	timeStop();
	void	timeout();
};

#endif